VNGE RigFlow support - test patch v3 for VNGE v45.1 (HS2 / AI StudioNeoV2)
============================================================================

v3 replaces v2 and your suggested fix. It is based on your review: thank you, the
diagnosis was correct.

What is different from your fix
-------------------------------
The Enable overload problem is fixed in the shared CallPrivate helper of
extplugins.py instead of a RigFlow-only helper. VNGE keeps one reflection helper
for all plugin integrations, and other plugins get the same fix.

  When GetMethod(name) is ambiguous, CallPrivate now looks for a unique method
  by name and argument count, and invokes it. Only if that is not unique does it
  fall back to the old lookup by argument types.

So Enable(False, False, None) selects the 3 parameter overload. The RigFlow code
itself is the same as v2, and it keeps using CallPrivate. _CallRigFlowPrivate
is not needed. vnactor.py and vnactor.ini are the same as v2.

The only difference from v2 is in CallPrivate in extplugins.py.

One difference from your helper: it invokes with Array[Object], CallPrivate
invokes with a tuple. A tuple containing None was tested on the games below, but
never against RigFlow. This is the main reason we ask you to run your tests again.

Install
-------
1. Back up these files in BepInEx\plugins\Console\Lib:
     extplugins.py, vnactor.py, vnactor.ini
2. Copy the 3 files from this patch over them. Do not keep your fixed extplugins.py.
3. Delete pandarinka_rigflow_vnactor.py (and its .pyc, if any), if still there.
4. In this patch, vnactor.ini already has ExportChara_PandarinkaRigFlow=1 in
   [neov2]. The default in the official release will be 0.
   NOTE: vnactor_setting.json (next to vnactor.py) overrides vnactor.ini for
   the keys it contains. If the option shows as off, turn it on in the VNGE
   settings (or delete that json once).

These files are taken from the current VNGE development version, with one
compatibility shim in vnactor.py so they run on v45.1: the VNRig path functions
fall back to no-ops when the vnrig_core of v45.1 does not have them. They also
contain support for some other plugins added after v45.1 (AssetSS, CustomFluids,
SculptStudio). These are off by default and do not affect RigFlow.

Please test
-----------
A. Run your automated suite again against this extplugins.py. The important part
   is an existing rig: Enable(False, False, None) must no longer print
   "expected object, got NoneType", and the pose must be restored.

B. In the real Studio, which your suite did not cover:
 1. Startup: no errors in the console when VNGE / SSS opens (SSS reloads vnactor).
 2. Actor WITH a RigFlow rig: save an SSS state, change the rig pose, load the
    state -> the pose comes back.
 3. Switching between an SSS state with a rig and one without -> the rig is
    removed / restored.
 4. VNAnime (clip v2) keyframes with the RigFlow key -> discrete switch works.
 5. Scene save -> reload scene -> SSS states still apply. Saving SSS right after
    loading a state must not fail (the internal _post key must not get saved).
 6. With the Toolkit removed/disabled: the rest of the actor status still loads.
 7. Error messages to look for in the console:
      "VNGE VNActor error: can't get/set/rollback PandarinkaToolkit RigFlow data ..."
      "import_status Fail to update 'pl_pandarinka_rigflow...'"
    plus Python tracebacks.

What we tested
--------------
The changed CallPrivate ran on HS2, KK, HS StudioNeo and PlayHome, in the real
games, without RigFlow. We do not have the plugin.
 - Generic .NET cases, including ArrayList.Sort(0, 3, None), which has the same
   shape as Enable(False, False, None). The old code gives your exact error on it.
 - Same parameter count overloads still use the lookup by types, as before.
 - Real overloaded plugin calls with real data: NodesConstraints save/load on KK,
   Timeline save/load on HS2.

Known risks
-----------
 - CallPrivateStatic (Serialize, Deserialize, RigFlowTimeline.Refresh) looks up
   methods by name only and has no overload fallback. It works today, but adding an
   overload of one of these methods would break it. Please tell us if you plan to.
 - In a VNAnime clip, the RigFlow key sorts BEFORE the FK/IK keys (it is the first
   key of the sequence). Animating RigFlow and FK/IK in the same clip conflicts
   anyway, but please tell us if a RigFlow keyframe switch looks wrong.

Questions
---------
 - vnactor.ini and the error text say Toolkit 3.9.5+. You tested 3.9.6.5 and said
   both Enable overloads are in the published 3.9.6. What is the real minimum
   version?
 - Thanks for confirming the import can stay synchronous. We will keep it that way.
