# External Plugin Functions 
# Module for calling functions from native plugins in "/Plugins" folder
# v4.0
#
# Changelog:
# 1.1
# - static method "exists" in ExtPlugin - crossplatform
# 2.0 (VNGE 11.0)
# - NEO: HSStudioNEOAddon, HSStudioNEOExtSave
# - PH: PHSAddon
# - KK: KKPE (beta support
# 2.1
# - NEO: HSStudioNEOExtSave - functions ExtDataGet, ExtDataSet (get/set full plugin data in string)
# - All: GetPrivate function - grant access to private fields
# 2.2
# - NEO: HSStudioNEOAddon - Add some function to support play MMD
# - KK: KKVMDPlayPlugin - a plugin to support play MMD
# 2.3 (VNGE 11.7)
# - NEO: HSPENeo plugin (works with HSPE 2.8.0+)
# 2.4 (VNGE 11.8)
# - CharaStudio: KKPE plugin support
# Warning: this work only with internal beta KKPE version! Don't use it for now!
# 2.5 (VNGE 12.0)
# - CharaStudio: Screencap plugin support
# 2.6 (VNGE 12.5)
# - All: has_plugin support function
# 2.7 (VNGE 13.9)
# - NeoV2 (AI): AIPE plugin support
# 2.8 (VNGE 14.1)
# - All: calculating plugin folder (easy switch between Bep4 and Bep5)
# 2.9 (VNGE 15.0)
# - Support for NodeConstraints plugin
# 3.0 (VNGE 16.0)
# - Support AIVMDPlugin
# - Support DHH_AI
# 3.1
# - changed logic for Exists check. Allow load plugins from subfolders in Bep5.
# 3.2 (VNGE 16.8)
# - Update AIVMDPlugin to support AIVMDPlayer too
# - Support AI_FKIK
# - Add: CallPrivateStatic function
# 3.3 (VNGE 16.9)
# - ExtensibleSaveFormat and AI_ExtensibleSaveFormat mod (for AI and KK). Support for OnSceneLoad, Import, Save events
# - HSExtSave mod (for HS). Support for OnSceneLoad, Import, Save events
# 3.4 (VNGE 17.5)
# - AI_ExtensibleSaveFormat also load HS2_ExtensibleSaveFormat
# - AI_ExtensibleSaveFormat's Helper function for save/load extend data 
# 3.5 (VNGE 17.7)
# - support HS2PE
# 3.6
# - support HS2VmdPlayPlugin
# - some new function for KKVmdPlayPlugin
# - ExtensibleSaveFormat's Helper function for save/load extend data
# 3.7 (VNGE 18.0)
# - support ILLAPI (KKAPI, HS2API etc.)
# 3.8 (VNGE 18.2) (countd360)
# - support NodesConstraints 1.2.0 again
# - support HS2VmdPlayPlugin 0.3.x
# 3.9
# - refactored ExtensibleSaveFormat to one class
# - support HS2_FKIK
# 3.10
# - fix NodesConstraints 1.2.0 support bug
# 3.11 (Keitaro)
# - Screencap adapted to HS2/AI
# - more functions in Screencap class (used in autocharamoments)
# 4.0 (Keitaro)
# - HSPE, KKPE moved to AIPE code
# - Screencap moved back to KK Screencap only. HS2/AI uses another structure, so it can't be applied
# - AIPE support Get/Set only BlendShapes XML / converted Objects
# 4.1 (countd360)
# - support ABMX for PH, KK, AI and HS2 (need dll)
# 4.2 (Keitaro)
# - support PH_ExtensibleSaveFormat (for BepisPlugins 16.2.0.2 and above)
# - support PHAPI (at least to make buttons in Studio)
# 4.3 (Keitaro)
# - support Timeline plugin
# 4.4 (hentai-san)
# - Support DHH (1.15.10)
# - Support Graphics (0.3.3.36)
# 4.7 (Keitaro)
# - Support latest Graphics (0.4.0) with new Preset load/save logic
# 4.8 (Countd360)
# - Support XXPE data for Prop
# - HS2: support for StudioCharaEditor/BoobSetting
# 5.0 (Keitaro)
# - support fot Sideloader ID resolving
# 5.1 (Countd360)
# - KK/AI/HS2: Support MoreAccessories
# - HS2: Update StudioCharaEditor to use Sideloader ID resolving
# 5.2 (Countd360)
# - HS2: Update StudioCharaEditor support
# 5.3 (Keitaro)
# - BepInEx support
# 5.4 (Countd360)
# - KKS: ABMX/ILLAPI/Sideloader/ExtensibleSaveFormat support KKS
# - ALL: add a open file dialog function to ILLAPI
# 5.4.1 (Keitaro)
# - small upd text in open file dialog
# 5.4.2 (Keitaro, Zanith)
# - HS1: support for ExtraItemAnimations
# 5.5
# - KKS: KKSPE and KKS_VmdPlayPlugin support
# 5.7
# - KK: bug fix for ILLAPI not correctly detected in KK
# 5.7.1
# - KK: bug fix for ABMX/Sideload not correctly detected in KK
# 5.8
# - KK: update sideloader plugin to support zipmod motion better
# 5.9
# - ALL: add BepInEx function to list all plugins and check for plugin
# 6.0
# - AI/HS2: update more accessory support class, not support KK/KKS!?
# - HS2: add chara editor support class
# - KK/KKS: add skin effect support class
# - HS2: add overlay support class (in process)
# 6.1
# - KK: Fix bug for videoplayer support
# 6.2
# - KK/KKS/AI/HS2: get dic key update infomation of imported scene from NodesConstraints 
# 6.3
# - Timeline: support timeline data
# 6.4
# - KK/KKS: updated AdditionalSkinEffects to support more effect
# 6.4.1
# - Timeline: Add a toggle UI function
# 6.5
# - AdvIK: add Adv.IK Solver and breath support for KK/KKS/AI/HS2
# - Overlay: add api support for KK/KKS
# 6.6
# - InvisibleBody data support for KK/KKS/AI/HS2
# - UncensorSelect data support for KK/KKS/AI/HS2
# - BetterPentration data support for KK/KKS/AI/HS2
# - MaterialEditor API support for KK/KKS/AI/HS2
# - some new API in NC and Timeline
# - new utility function SetPrivate
# 6.7
# - HS: Add unified mmd api for HSStudioNEOAddon
# - PH: Add unified mmd api for PHSAddon
# 6.8
# - HS: fix Timeline ext for HS
# - HS2: ExtraJointCorrection plugin support
# - API: AnimationCurveEditor wrapper API
# - API: ILLAPI Utilities_OpenFileDialog support multi file selection
# 6.9
# - HS2: Graphics add some PostProcessingSetting func, not work
# - HS, PH: CharaAnime support
# - Timeline: some new API and bug fix
# - HS2: support HooahGlobalConfig now
# 7.0 (Countd360)
# - KK/KKS/AI/HS2: rewrite ScreencapPlugin, support old and new plugin versions
#   TakeUIScreenshot/TakeRenderScreenshot can save png to a custom file path
#   falls back to direct camera capture when the Graphics plugin hijacks
#   Screencap's internals with its temporal screenshot tool
#

# Use "dotPeek" to decompile native plugin dlls to understand how they work.
# Download link: https://www.jetbrains.com/decompiler/download/

# Adding your own class/function:
#   - Create a class extended from ExtPlugin 
#   - Use plugin name as class name for minimal confusion
#   - Create functions to call native plugin functions
#   - Do not create code that affects other functions if possible

from System.Reflection import BindingFlags
import traceback
import clr
import os
from vngameengine import get_engine_id, HSNeoOCIChar

pluginsDetection = {}

class ExtPlugin(): # v1.0
    def __init__(self, name = None):
        self.isDetected = False
        self.name = name
        #print "ExtPlugin:", name
        self.initFlag()

    @staticmethod
    def calc_plugin_dir():
        from UnityEngine import Application
        from os import path
        rootfolder = path.realpath(path.join(Application.dataPath, '..'))

        # os.path.splitext(__file__)[0] + '.ini'
        pydirname = path.dirname(__file__)
        pluginpath = path.realpath(path.join(pydirname, '..', '..'))
        return path.relpath(pluginpath, rootfolder)

    @staticmethod
    def exists(name):
        # usually check IPA folder
        # plgdir = os.path.join(os.getcwd(), "Plugins/")
        #
        # if get_engine_id() == "charastudio":
        #     # in CharaStudio check BepInEx folder
        #     plgdir = os.path.join(os.getcwd(), "BepInEx/")
        #
        # if get_engine_id() == "neov2":
        #     # in StudioNeoV2 check BepInEx/plugins folder
        #     plgdir = os.path.join(os.getcwd(), "BepInEx/Plugins/")

        # ------------ old check - using DLL file path ---------------------
        # plgdir = ExtPlugin.calc_plugin_dir()
        # return os.path.isfile(plgdir + "/" + name + ".dll")

        # new check
        global pluginsDetection
        if name in pluginsDetection:
            #print "Cached explugin check for ", name
            pass
        else:
            try:
                clr.AddReference(name)
                pluginsDetection[name] = True
            except Exception as e:
                pluginsDetection[name] = False

        return pluginsDetection[name]
    # init flags
    def initFlag(self):
        #plgdir = os.path.join(os.getcwd(), "Plugins/")
        if ExtPlugin.exists(self.name):
            self.isDetected = True
            clr.AddReference(self.name)
            #print(self.name + ".dll detected.")
        else:
            self.isDetected = False
            print(self.name + ".dll not found.")

# ::::::::::: StudioNeo ::::::::::: 
class ExtraItemAnimations(ExtPlugin):
    def __init__(self):
        ExtPlugin.__init__(self, "ExtraItemAnimations")

    def GetCurrentAnimation(self, item):
        if self.isDetected == True:
            try:
                from ExtraItemAnimations import AnimationTools
                try:
                    return AnimationTools.GetCurrentAnimationName(item)
                except SystemError as e:
                    print("Failed to get anim from AnimationTools")
                    print(str(e))
                    pass
            except SystemError as e:
                print("Failed to import ExtraItemAnimationsPlugin")
                print(str(e))
                pass
        else:
            print("Failed to init ExtraItemAnimations")
            pass


    def PlayAnimation(self, item, animation_name):
        if self.isDetected == True:
            try:
                from ExtraItemAnimations import AnimationTools
                try:
                    AnimationTools.PlayAnimation(item, animation_name)
                except SystemError as e:
                    print("Failed to play anim on AnimationTools")
                    print(str(e))
                    pass
            except SystemError as e:
                print("Failed to import ExtraItemAnimationsPlugin")
                print(str(e))
                pass

# --- HSStudioNeoAddon --- 
class HSStudioNEOAddon(ExtPlugin):
    def __init__(self):
        #super(HSStudioNEOAddon, self).__init__("HSStudioNEOAddon") #can't get it to work
        ExtPlugin.__init__(self, "HSStudioNEOAddon")
        if self.isDetected:
            from HSStudioNEOAddon import BaseMgr, HSVMDAnimationMgr
            self.vmdMgr = BaseMgr[HSVMDAnimationMgr].Instance
            self.cameraMgr = self.vmdMgr.CameraMgr
            self.audioMgr = self.vmdMgr.SoundMgr

    # Activate simulataneous FK/IK (char: HSNeoOCIChar, OCIChar)
    def activateFKIK(self, char):
        from Studio import OCIChar
        if self.isDetected == True and not char == None:
            from HSStudioNEOAddon import FKIKAssist
            if isinstance(char, HSNeoOCIChar):
                FKIKAssist.FKIKAssistMgr.ActivateFKIK(char.objctrl)
            elif isinstance(char, OCIChar): #might be redundant, not sure
                FKIKAssist.FKIKAssistMgr.ActivateFKIK(char)

    # MMD play ALL
    def MMDPlayAll(self):
        if self.isDetected:
            self.vmdMgr.PlayAll()
            
    # MMD Pause ALL
    def MMDPauseAll(self):
        if self.isDetected:
            self.vmdMgr.PauseAll()

    # MMD play ALL
    def MMDStopAll(self):
        if self.isDetected:
            self.vmdMgr.StopAll()
    
    # MMD set anime position
    def MMDSetAnimPositionAll(self, time):
        if self.isDetected:
            self.vmdMgr.PlayAll()
            self.vmdMgr.PauseAll()
            for vc in self.vmdMgr.controllers:
                vc.SetAnimPosition(time)
            self.vmdMgr.SoundMgr.AnimePosition = time
                
    # MMD get controller for char
    def MMDGetCharVmdController(self, char):
        from Studio import OCIChar
        if self.isDetected and char:
            if isinstance(char, HSNeoOCIChar):
                tgtOCIChar = char.objctrl
            elif isinstance(char, OCIChar): #might be redundant, not sure
                tgtOCIChar = char
            else:
                return None
            for vc in self.vmdMgr.controllers:
                if vc.studioChara == tgtOCIChar:
                    return vc
        return None
        
    # MMD export setting for char
    def MMDExportCharVmdSetting(self, char):
        vc = self.MMDGetCharVmdController(char)
        if vc and vc.VMDAnimEnabled:
            exset = {}
            exset["VMDAnimEnabled"] = "1"
            exset["lastLoadedVMD"] = vc.lastLoadedVMD if vc.lastLoadedVMD else ""
            exset["speed"] = str(vc.speed)
            exset["Loop"] = "1" if vc.Loop else "0"
            exset["centerBasePos"] = "(%.3f, %.3f, %.3f)"%(vc.centerBasePos.x, vc.centerBasePos.y, vc.centerBasePos.z)
            return exset
        else:
            return None
            
    # MMD import setting for char
    def MMDImportCharVmdSetting(self, char, imSet):
        vc = self.MMDGetCharVmdController(char)
        if vc == None:
            return
        # TODO: load settings

    # MMD get controller infomation
    def MMDGetAllVmdController(self):
        if not self.isDetected:
            return None
        vcs = []
        for vc in self.vmdMgr.controllers:
            vcs.append(vc)
        return tuple(vcs)

    def MMDGetVmdInfo(self, ctrl):
        info = {}
        clip = ctrl.animationForVMD.clip
        info["Loaded"] = clip != None
        info["ChaControl"] = ctrl.charInfo
        info["FilePath"] = ctrl.lastLoadedVMD
        info["Length"] = 0 if clip == None else clip.length
        info["Frames"] = 0 if clip == None else int(clip.length * 30.0)
        return info

    def MMDGetCameraInfo(self):
        if not self.isDetected:
            return None
        info = {}
        info["Loaded"] = False
        if self.cameraMgr.cameraVMDFilePath:
            info["Loaded"] = True
            info["Enabled"] = self.cameraMgr.CameraEnabled
            info["FilePath"] = self.cameraMgr.cameraVMDFilePath
            info["Length"] = self.cameraMgr.AnimeLength
        return info

    def MMDGetSoundInfo(self):
        if not self.isDetected:
            return None
        info = {}
        info["Loaded"] = False
        if self.audioMgr.currentAudioClip != None and self.audioMgr.audioFilePath:
            info["Loaded"] = True
            info["FilePath"] = self.audioMgr.audioFilePath
            info["Length"] = self.audioMgr.SoundLength
        return info

    # control and sync
    def MMDPlayVmd(self, ctrl):
        ctrl.Play()

    def MMDPauseVmd(self, ctrl):
        ctrl.Pause()

    def MMDStopVmd(self, ctrl):
        ctrl.Stop()

    def MMDSyncVmd(self, ctrl, time):
        ctrl.SetAnimPosition(time)

    def MMDPlayCamera(self):
        if self.isDetected:
            self.cameraMgr.Play()

    def MMDPauseCamera(self):
        if self.isDetected:
            self.cameraMgr.Pause()

    def MMDStopCamera(self):
        if self.isDetected:
            self.cameraMgr.Stop()

    def MMDSyncCamera(self, time):
        if self.isDetected:
            self.cameraMgr.AnimePosition = time

    def MMDPlaySound(self):
        if self.isDetected:
            self.audioMgr.PlaySound()

    def MMDPauseSound(self):
        if self.isDetected:
            self.audioMgr.PauseSound()

    def MMDStopSound(self):
        if self.isDetected:
            self.audioMgr.StopSound()

    def MMDSyncSound(self, time):
        if self.isDetected:
            self.audioMgr.AnimePosition = time



# --- HSStudioNEOExtSave ---
class HSStudioNEOExtSave(ExtPlugin):
    def __init__(self):
        #super(HSStudioNEOExtSave, self).__init__("HSStudioNEOExtSave") #can't get it to work
        ExtPlugin.__init__(self, "HSStudioNEOExtSave")
        
    # Save ext data
    def SaveExtData(self, filePath):
        from HSStudioNEOExtSave import StudioNEOExtendSaveMgr
        StudioNEOExtendSaveMgr.Instance.SaveExtData(filePath)
        
    # Load ext data
    def LoadExtData(self, filePath):
        from HSStudioNEOExtSave import StudioNEOExtendSaveMgr
        StudioNEOExtendSaveMgr.Instance.LoadExtData(filePath)
        StudioNEOExtendSaveMgr.Instance.LoadExtDataRaw(filePath)

    def ExtDataGet(self):
        clr.AddReference("System.Xml")

        from HSStudioNEOExtSave import StudioNEOExtendSaveMgr
        #handlers = StudioNEOExtendSaveMgr.Instance.GetField("handlers", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy)
        handlers = GetPrivate(StudioNEOExtendSaveMgr.Instance, "handlers")

        from System.Xml import XmlDocument

        if len(handlers) > 0:
            xmlDocument = XmlDocument()
            newChild = xmlDocument.CreateXmlDeclaration("1.0", "utf-8", None)
            xmlDocument.AppendChild(newChild)
            xmlElement = xmlDocument.CreateElement("ExtSave")
            xmlDocument.AppendChild(xmlElement)
            for handler in handlers:
                try:
                    handler.OnSave(xmlElement)
                except Exception as e:
                    print("Error in ExtSave handler save: " + str(e))

            #return xmlDocument.ToString()
            from System.IO import StringWriter
            #from System.Xml import XmlTextWriter

            stringWriter = StringWriter()
            xmlDocument.Save(stringWriter)
            return stringWriter.ToString()

        return ""

    def ExtDataSet(self, datastring):
        clr.AddReference("System.Xml")

        from HSStudioNEOExtSave import StudioNEOExtendSaveMgr
        # handlers = StudioNEOExtendSaveMgr.Instance.GetField("handlers", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy)
        handlers = GetPrivate(StudioNEOExtendSaveMgr.Instance, "handlers")

        from System.Xml import XmlDocument

        if len(handlers) > 0:
            xmlDocument = XmlDocument()
            xmlDocument.LoadXml(datastring)
            documentElement = xmlDocument.DocumentElement
            for handler in handlers:
                try:
                    handler.OnLoad(documentElement)
                except Exception as e:
                    print("Error in ExtSave handler load: " + str(e))

# ::::::::::: PlayHome Studio :::::::::::
class PHSAddon(ExtPlugin):
    def __init__(self):
        ExtPlugin.__init__(self, "PHSAddon")
        # support class instance from plugin
        if self.isDetected:
            from PHSAddon import BaseMgr, HSVMDAnimationMgr, MMD_VmdCameraLoad, ExtMP3
            self.vmdMgr = BaseMgr[HSVMDAnimationMgr].Instance
            self.cameraMgr = BaseMgr[MMD_VmdCameraLoad].Instance
            self.audioMgr = ExtMP3.MP3Player

    # Activate simulataneous FK/IK (char: HSNeoOCIChar, OCIChar)
    def activateFKIK(self, char):
        from Studio import OCIChar
        if self.isDetected == True and not char == None:
            from PHSAddon import FKIKAssist
            if isinstance(char, HSNeoOCIChar):
                try:
                    FKIKAssist.FKIKAssistMgr.ActivateFKIK(char.objctrl)
                except SystemError as e:
                    #print(str(e))
                    pass
            elif isinstance(char, OCIChar): #might be redundant, not sure
                try:
                    FKIKAssist.FKIKAssistMgr.ActivateFKIK(char)
                except SystemError as e:
                    #print(str(e))
                    pass
    
    # MMD play ALL
    def MMDPlayAll(self):
        if self.isDetected:
            self.vmdMgr.PlayAll()
            self.audioMgr.Play()
            
    # MMD Pause ALL
    def MMDPauseAll(self):
        if self.isDetected:
            self.vmdMgr.PauseAll()
            self.audioMgr.Pause()

    # MMD play ALL
    def MMDStopAll(self):
        if self.isDetected:
            self.vmdMgr.StopAll()
            self.audioMgr.Stop()
    
    # MMD set anime position
    def MMDSetAnimPositionAll(self, time):
        if self.isDetected:
            self.vmdMgr.PlayAll()
            self.vmdMgr.PauseAll()
            for vc in self.vmdMgr.controllers:
                vc.SetAnimPosition(time)
            #self.audioMgr.Seek(time)
            from System import Single
            #p = Array[Single]([time])
            CallPrivateStatic(self.audioMgr, "Seek", [Single(time)])
                
    # MMD get controller for char
    def MMDGetCharVmdController(self, char):
        from Studio import OCIChar
        if self.isDetected and char:
            if isinstance(char, HSNeoOCIChar):
                tgtOCIChar = char.objctrl
            elif isinstance(char, OCIChar): #might be redundant, not sure
                tgtOCIChar = char
            else:
                return None
            for vc in self.vmdMgr.controllers:
                if vc.studioChara == tgtOCIChar:
                    return vc
        return None
        
    # MMD export setting for char
    def MMDExportCharVmdSetting(self, char):
        vc = self.MMDGetCharVmdController(char)
        if vc and vc.VMDAnimEnabled:
            exset = {}
            exset["VMDAnimEnabled"] = "1"
            exset["lastLoadedVMD"] = vc.lastLoadedVMD if vc.lastLoadedVMD else ""
            exset["lastLipPath"] = vc.lastLipPath if vc.lastLipPath else ""
            exset["isLipSync"] = "1" if vc.isLipSync else "0"
            exset["speed"] = str(vc.speed)
            exset["Loop"] = "1" if vc.Loop else "0"
            exset["centerBasePos"] = "(%.3f, %.3f, %.3f)"%(vc.centerBasePos.x, vc.centerBasePos.y, vc.centerBasePos.z)
            exset["hipPositionAdjust"] = "(%.3f, %.3f, %.3f)"%(vc.hipPositionAdjust.x, vc.hipPositionAdjust.y, vc.hipPositionAdjust.z)
            return exset
        else:
            return None
            
    # MMD import setting for char
    def MMDImportCharVmdSetting(self, char, imSet):
        vc = self.MMDGetCharVmdController(char)
        if vc == None:
            return
        if imSet.has_key("isLipSync"):
            vc.SetLipSyn(imSet["isLipSync"] == "1")
        # is the other settings necessary?        

    # MMD get controller infomation
    def MMDGetAllVmdController(self):
        if not self.isDetected:
            return None
        vcs = []
        for vc in self.vmdMgr.controllers:
            vcs.append(vc)
        return tuple(vcs)

    def MMDGetVmdInfo(self, ctrl):
        info = {}
        clip = ctrl.animationForVMD.clip
        info["Loaded"] = clip != None
        info["ChaControl"] = ctrl.charInfo
        info["FilePath"] = ctrl.lastLoadedVMD
        info["Length"] = 0 if clip == None else clip.length
        info["Frames"] = 0 if clip == None else int(clip.length * 30.0)
        return info

    def MMDGetCameraInfo(self):
        if not self.isDetected:
            return None
        info = {}
        info["Loaded"] = False
        if self.cameraMgr.lastCamFile != None:
            info["Enabled"] = self.cameraMgr.camEnabled
            info["FilePath"] = self.cameraMgr.lastCamFile
            camframes = GetPrivate(self.cameraMgr, "Cam_m")
            if camframes and len(camframes):
                info["Loaded"] = True
                info["Length"] = float(camframes[-1].frame) / 30.0
            else:
                info["Loaded"] = False
                info["Length"] = 0
        return info

    def MMDGetSoundInfo(self):
        if not self.isDetected:
            return None
        info = {}
        info["Loaded"] = False
        if self.audioMgr.audioSrc != None and self.audioMgr.audioSrc.clip != None and self.audioMgr.lastAudioFile != None:
            info["Loaded"] = True
            info["FilePath"] = self.audioMgr.lastAudioFile
            info["Length"] = self.audioMgr.audioSrc.clip.length
        return info

    # control and sync
    def MMDPlayVmd(self, ctrl):
        ctrl.Play()

    def MMDPauseVmd(self, ctrl):
        ctrl.Pause()

    def MMDStopVmd(self, ctrl):
        ctrl.Stop()

    def MMDSyncVmd(self, ctrl, time):
        ctrl.SetAnimPosition(time)

    def MMDPlayCamera(self):
        if self.isDetected:
            pass

    def MMDPauseCamera(self):
        if self.isDetected:
            pass

    def MMDStopCamera(self):
        if self.isDetected:
            pass

    def MMDSyncCamera(self, time):
        if self.isDetected:
            pass

    def MMDPlaySound(self):
        if self.isDetected:
            self.audioMgr.Play()

    def MMDPauseSound(self):
        if self.isDetected:
            self.audioMgr.Pause()

    def MMDStopSound(self):
        if self.isDetected:
            self.audioMgr.Stop()

    def MMDSyncSound(self, time):
        if self.isDetected:
            self.audioMgr.audioSrc.time = time

# ::::::::::: StudioNeoV2 (AI/HS2) :::::::::::
class AIPE(ExtPlugin):
    def __init__(self):
        #Here we initialize (load code of plugin) depends on it's filename.
        #This allow you use same code for multiple Studios
        #If we not found - try next
        if ExtPlugin.exists("AIPE"):
            ExtPlugin.__init__(self, "AIPE")
        elif ExtPlugin.exists("HS2PE"):
            ExtPlugin.__init__(self, "HS2PE")
        elif ExtPlugin.exists("KKPE"):
            ExtPlugin.__init__(self, "KKPE")
        elif ExtPlugin.exists("KKSPE"):
            ExtPlugin.__init__(self, "KKSPE")
        elif ExtPlugin.exists("HSPENeo"):
            ExtPlugin.__init__(self, "HSPENeo")
        else:
            self.isDetected = False

    def GetCharaSettingsText(self, ocichar):
        clr.AddReference("System.Xml")

        from System.IO import StringWriter
        from System.Xml import XmlTextWriter

        # here we import necessary class from plugin - almost same as in C#
        from HSPE import PoseController

        poseController = self.GetPoseController(ocichar)
        if poseController is None:
            # no PoseController component on this object (eg. effect props), skip silently
            return ""

        stringWriter = StringWriter()
        xmlTextWriter = XmlTextWriter(stringWriter)

        xmlTextWriter.WriteStartElement("characterInfo")
        # here we work with OCIChar. OCIChar passed to function - this is chara control object
        # we SaveXML - it data in XML in xmlTextWriter
        poseController.SaveXml(xmlTextWriter)
        xmlTextWriter.WriteEndElement()

        # here we return result as string
        # vnactor expect you will provide result in some of standart datatypes:
        # lists, arrays, int, string, float, Vector3D etc.
        # NOT in XML structures!
        # so good way is to convert it
        return stringWriter.ToString()

    # setting chara data
    # on_load_end, if given, is called as on_load_end(changed) once the plugin's
    # ScheduleLoad coroutine actually finishes (it runs a few frames later, not
    # synchronously with this call)
    def SetCharaSettingsText(self,ocichar, text, on_load_end=None):
        clr.AddReference("System.Xml")

        from System.Xml import XmlDocument

        from HSPE import PoseController

        poseController = self.GetPoseController(ocichar)
        if poseController is None:
            # no PoseController component on this object (eg. effect props), skip silently
            return

        xmlDocument = XmlDocument()
        xmlDocument.LoadXml(text)
        node = xmlDocument.FirstChild

        if on_load_end != None:
            from System import Action
            poseController.ScheduleLoad(node, Action[bool](on_load_end))
        else:
            poseController.ScheduleLoad(node, None)

    def GetPoseController(self, ociobj):
        from HSPE import PoseController
        from Studio import OCIItem, OCIChar
        if hasattr(ociobj, "objctrl"):
            ociobj = ociobj.objctrl
        if isinstance(ociobj, OCIChar):
            return ociobj.charInfo.gameObject.GetComponent(PoseController)
        elif isinstance(ociobj, OCIItem):
            return ociobj.objectItem.GetComponent(PoseController)
        else:
            return None

    def GetModules(self,ocichar):
        poseController = self.GetPoseController(ocichar)
        if poseController:
            return GetPrivate(poseController, "_modules")
        else:
            return []

    def GetBlendShapesEditor(self,ocichar):
        from HSPE.AMModules import BlendShapesEditor
        modules = self.GetModules(ocichar)
        for mod in modules:
            if type(mod) == BlendShapesEditor:
                return mod
        return None

    def GetBonesEditor(self,ocichar):
        from HSPE.AMModules import BonesEditor
        modules = self.GetModules(ocichar)
        for mod in modules:
            if type(mod) == BonesEditor:
                return mod
        return None

    # True if BonesEditor currently has a manual bone correction (from Advanced
    # Mode / a loaded advancedObjects XML) sitting on a bone that is also an
    # active FK bone right now. This is exactly the condition that makes
    # BonesEditor.ResetAll() spin forever (until it OOMs) the next time
    # SetCharaSettingsText/LoadXml runs on this character - see ResetBoneRot's
    # guard, which silently skips clearing a dirty bone while it's FK-active.
    # Reads private fields via reflection, so on any failure (e.g. a future
    # HSPlugins version renaming them) this returns True to stay on the safe side.
    def HasDirtyActiveFKBone(self,ocichar):
        try:
            bonesEditor = self.GetBonesEditor(ocichar)
            if bonesEditor is None:
                return False
            target = GetPrivate(bonesEditor, "_target")
            if not target.fkEnabled:
                return False
            dirtyBones = GetPrivate(bonesEditor, "_dirtyBones")
            for kvp in dirtyBones:
                go = kvp.Key
                if go is None:
                    continue
                info = target.GetBoneInfo(go)
                if info is not None and info.active:
                    return True
            return False
        except Exception:
            return True

    def GetBlendShapesXML(self,ocichar):
        clr.AddReference("System.Xml")

        from System.IO import StringWriter
        from System.Xml import XmlTextWriter

        editor = self.GetBlendShapesEditor(ocichar)
        if editor is None:
            # no BlendShapesEditor module on this object, skip silently
            return ""

        stringWriter = StringWriter()
        xmlTextWriter = XmlTextWriter(stringWriter)

        xmlTextWriter.WriteStartElement("blendShapes")
        editor.SaveXml(xmlTextWriter)
        xmlTextWriter.WriteEndElement()

        return stringWriter.ToString()

    def GetBlendShapesObj(self,ocichar):
        clr.AddReference("System.Xml")

        from System.IO import StringWriter
        from System.Xml import XmlTextWriter, XmlDocument

        settingData = self.GetBlendShapesXML(ocichar)

        fullObj = {}
        try:

            # load contents of setting data
            xDoc = XmlDocument()
            xDoc.LoadXml(settingData)


            # find each setting and adjust
            xRoot = xDoc.FirstChild
            for nc in xRoot.FirstChild.ChildNodes:
                if nc.Name == "skinnedMesh":
                    obj = {}
                    for blsh in nc.ChildNodes:
                        ind = str(blsh.GetAttribute("index"))
                        w = float(blsh.GetAttribute("weight"))
                        obj[ind] = w
                    fullObj[str(nc.GetAttribute("name"))] = obj


                else:
                    print("XXPEBlendShapes Warning: unknown setting node '%s'"%nc.Name)
        except:
            pass
        return fullObj


    def SetBlendShapesXML(self,ocichar,text):
        clr.AddReference("System.Xml")

        #from System.IO import StringWriter
        from System.Xml import XmlDocument

        editor = self.GetBlendShapesEditor(ocichar)
        if editor is None:
            # no BlendShapesEditor module on this object, skip silently
            return

        xmlDocument = XmlDocument()
        xmlDocument.LoadXml(text)
        node = xmlDocument.FirstChild

        editor.LoadXml(node)

    def SetBlendShapesObj(self,ocichar,fullObj):
        clr.AddReference("System.Xml")

        from System.IO import StringWriter
        from System.Xml import XmlTextWriter

        stringWriter = StringWriter()
        xmlTextWriter = XmlTextWriter(stringWriter)

        xmlTextWriter.WriteStartElement("blendShapes")
        #self.GetBlendShapesEditor(ocichar).SaveXml(xmlTextWriter)
        xmlTextWriter.WriteStartElement("skinnedMeshes")
        for smeshes in fullObj:
            xmlTextWriter.WriteStartElement("skinnedMesh")
            xmlTextWriter.WriteAttributeString("name", str(smeshes))
            for smesh in fullObj[smeshes]:
                xmlTextWriter.WriteStartElement("blendShape")
                xmlTextWriter.WriteAttributeString("index", str(smesh))
                xmlTextWriter.WriteAttributeString("weight", str(fullObj[smeshes][smesh]))
                xmlTextWriter.WriteEndElement()
            xmlTextWriter.WriteEndElement()

        xmlTextWriter.WriteEndElement()
        xmlTextWriter.WriteEndElement()

        #print stringWriter.ToString()
        text = stringWriter.ToString()
        #pass
        self.SetBlendShapesXML(ocichar,text)

# ::::::::::: CharaStudio ::::::::::: 
class KKPE(AIPE): # the same as AIPE class
    pass
    # def __init__(self):
    #     #super(HSStudioNEOAddon, self).__init__("HSStudioNEOAddon") #can't get it to work
    #     #pass
    #     #ExtPlugin.__init__(self, "KKPE")
    #     super(AIPE, self).__init__()

class HSPENeo(AIPE): # the same as AIPE class
    #pass
    def __init__(self):
        ExtPlugin.__init__(self, "HSPENeo")

class ScreencapPlugin(ExtPlugin):
    # Screencap plugin from BepisPlugins (https://github.com/IllusionMods/BepisPlugins)
    # The plugin dll name depends on the game:
    #   KK: Screencap, KKS: KKS_Screencap, AI: AI_Screencap, HS2: HS2_Screencap
    # All variants use namespace "Screencap" and class "ScreenshotManager", but there
    # are three API generations in the wild:
    #   "new"  : refactored version (r21+), public static CaptureUI/CaptureRender
    #   "kk"   : old KK/KKS/EC core, public instance Capture() returns Texture2D
    #   "aihs2": old AI/HS2 core, public instance Capture() returns RenderTexture
    SCREENCAP_DLL_NAMES = ("Screencap", "KKS_Screencap", "AI_Screencap", "HS2_Screencap")

    def __init__(self):
        self.apiMode = None
        self.capturePatched = None
        for dllname in ScreencapPlugin.SCREENCAP_DLL_NAMES:
            if ExtPlugin.exists(dllname):
                ExtPlugin.__init__(self, dllname)
                return
        self.name = None
        self.isDetected = False
        print("Screencap plugin dll not found.")

    # ---------- internal helpers ----------
    def _manager(self):
        from Screencap import ScreenshotManager
        return ScreenshotManager

    def _apimode(self):
        # lazy detection of the plugin API generation
        if self.apiMode is None:
            clrType = clr.GetClrType(self._manager())
            try:
                hasCaptureUI = clrType.GetMethod("CaptureUI") is not None
            except Exception:
                # GetMethod(name) throws AmbiguousMatchException instead of
                # returning null if the type has more than one overload of
                # CaptureUI (e.g. a no-arg one plus a filename-taking one) -
                # either way it means the "new" API is present
                hasCaptureUI = True
            if hasCaptureUI:
                self.apiMode = "new"
            elif clrType.GetProperty("ResolutionX") is not None:
                self.apiMode = "kk"
            else:
                self.apiMode = "aihs2"
        return self.apiMode

    def _find_instance(self):
        mgr = self._manager()
        try:
            inst = GetPrivateStatic(mgr, "Instance")
            if inst:
                # truthiness (not "is not None") matters here: a destroyed
                # Unity object is still a non-None wrapper reference, but
                # Unity overloads bool()/== to make it compare falsy
                return inst
        except:
            pass
        # old AI/HS2 versions have no Instance member, find the component instead
        from UnityEngine import Object
        return Object.FindObjectOfType(clr.GetClrType(mgr))

    def _alphamode(self, transparent):
        try:
            from Screencap import AlphaMode
        except ImportError:
            from alphaShot import AlphaMode
        if not transparent:
            return getattr(AlphaMode, "None")
        if hasattr(AlphaMode, "rgAlpha"):
            return AlphaMode.rgAlpha  # KK/KKS/EC
        return AlphaMode.composite  # AI/HS2 new version

    def _default_filename(self, captype):
        from System import DateTime
        from System.IO import Directory
        capdir = os.path.join(os.getcwd(), "UserData", "cap")
        if not Directory.Exists(capdir):
            Directory.CreateDirectory(capdir)
        stamp = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss-fff")
        return os.path.join(capdir, "VNGE-%s-%s.png" % (captype, stamp))

    def _prepare_filename(self, filename, captype):
        from System.IO import Directory
        if filename is None:
            return self._default_filename(captype)
        filename = os.path.abspath(filename)
        pardir = os.path.dirname(filename)
        if pardir != "" and not Directory.Exists(pardir):
            Directory.CreateDirectory(pardir)
        return filename

    def _texture2d_to_png(self, tex, filename):
        from System.IO import File
        try:
            from UnityEngine import ImageConversion
            pngBytes = ImageConversion.EncodeToPNG(tex)
        except ImportError:
            pngBytes = tex.EncodeToPNG()
        File.WriteAllBytes(filename, pngBytes)

    def _rt_to_texture2d(self, rt):
        # read a RenderTexture back into a Texture2D and release the temporary RT
        from UnityEngine import RenderTexture, Texture2D, TextureFormat, Rect
        prevActive = RenderTexture.active
        try:
            RenderTexture.active = rt
            tex = Texture2D(rt.width, rt.height, TextureFormat.ARGB32, False)
            tex.ReadPixels(Rect(0, 0, rt.width, rt.height), 0, 0)
            tex.Apply()
        finally:
            RenderTexture.active = prevActive
            RenderTexture.ReleaseTemporary(rt)
        return tex

    def _screencap_hijacked(self):
        # The Graphics plugin (Hanmen) can replace Screencap's CaptureScreen
        # with its TemporalScreenshotTool via a harmony prefix. That capture
        # only produces a valid image inside the plugin's own hotkey coroutine,
        # calling it from script code returns stale render texture garbage.
        # Detect the patch so we can use our own camera capture instead.
        if self.capturePatched is None:
            self.capturePatched = False
            try:
                clr.AddReference("0Harmony")
                from HarmonyLib import Harmony
                flags = (BindingFlags.Instance | BindingFlags.Static |
                         BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy)
                m = clr.GetClrType(self._manager()).GetMethod("CaptureScreen", flags)
                if m is not None:
                    pinfo = Harmony.GetPatchInfo(m)
                    if pinfo is not None and pinfo.Prefixes is not None and pinfo.Prefixes.Count > 0:
                        self.capturePatched = True
            except:
                pass
        if not self.capturePatched:
            return False
        # the patch only takes effect when the Graphics screenshot override
        # toggle is on, read it fresh every time as the user can change it
        try:
            from Graphics import Graphics as GraphicsPlugin
            return bool(GraphicsPlugin.ScreenshotOverride.Value)
        except:
            return True

    def _composite_material(self):
        # transparency composite material from the Screencap plugin
        mgr = self._manager()
        try:
            return CallPrivateStatic(mgr, "get_MatComposite", [])  # new version
        except:
            pass
        try:
            inst = self._find_instance()
            if inst is not None:
                return GetPrivate(inst, "_matComposite")  # old AI/HS2 version
        except:
            pass
        return None

    def _render_camera_to_rt(self, cam, width, height, alpha):
        from UnityEngine import RenderTexture, RenderTextureFormat, CameraClearFlags, Color
        rt = RenderTexture.GetTemporary(width, height, 32, RenderTextureFormat.ARGB32)
        oldCf = cam.clearFlags
        oldBg = cam.backgroundColor
        oldTt = cam.targetTexture
        if alpha:
            cam.clearFlags = CameraClearFlags.SolidColor
            cam.backgroundColor = Color(0, 0, 0, 0)
        cam.targetTexture = rt
        try:
            cam.Render()
        finally:
            cam.clearFlags = oldCf
            cam.backgroundColor = oldBg
            cam.targetTexture = oldTt
        return rt

    def _capture_via_camera(self, width, height, downscaling, transparent):
        # own capture used when the plugin capture path is unusable
        # (see _screencap_hijacked) or returned nothing; renders the main
        # camera directly, so plugin extras like temporal supersampling of
        # the Graphics plugin are not applied
        from UnityEngine import Camera, RenderTexture, RenderTextureFormat, Texture2D
        from UnityEngine import Graphics as UnityGraphics
        cam = Camera.main
        if cam is None:
            return None
        sw = width * downscaling
        sh = height * downscaling
        result = self._render_camera_to_rt(cam, sw, sh, False)
        if transparent:
            # post processing usually destroys the alpha channel,
            # disable it for the mask render pass like the plugin does
            ppl = None
            try:
                clr.AddReference("Unity.Postprocessing.Runtime")
                from UnityEngine.Rendering.PostProcessing import PostProcessLayer
                ppl = cam.GetComponent(clr.GetClrType(PostProcessLayer))
            except:
                ppl = None
            if ppl is not None and ppl.enabled:
                ppl.enabled = False
            else:
                ppl = None
            try:
                mask = self._render_camera_to_rt(cam, sw, sh, True)
            finally:
                if ppl is not None:
                    ppl.enabled = True
            mat = self._composite_material()
            if mat is not None:
                comp = RenderTexture.GetTemporary(sw, sh, 0, RenderTextureFormat.ARGB32)
                UnityGraphics.Blit(Texture2D.blackTexture, comp)
                mat.SetTexture("_Overlay", mask)
                UnityGraphics.Blit(result, comp, mat)
                RenderTexture.ReleaseTemporary(mask)
                RenderTexture.ReleaseTemporary(result)
                result = comp
            else:
                # no composite shader available, use the plain alpha render
                RenderTexture.ReleaseTemporary(result)
                result = mask
        if downscaling > 1:
            small = RenderTexture.GetTemporary(width, height, 0, RenderTextureFormat.ARGB32)
            UnityGraphics.Blit(result, small)
            RenderTexture.ReleaseTemporary(result)
            result = small
        return self._rt_to_texture2d(result)

    def _capture_texture2d(self, transparent):
        # capture a rendered (no UI) screenshot, returns Texture2D or None
        # transparent: True/False to force transparency, None = use plugin config
        mgr = self._manager()
        mode = self._apimode()
        if mode == "new":
            width = mgr.ResolutionX.Value
            height = mgr.ResolutionY.Value
            downscaling = mgr.DownscalingRate.Value
            if transparent is None:
                try:
                    transparent = int(mgr.CaptureAlphaMode.Value) != 0
                except:
                    transparent = False
            if not self._screencap_hijacked():
                mgr.FirePreCapture()
                try:
                    rt = mgr.CaptureRender(width, height, downscaling, self._alphamode(transparent))
                finally:
                    mgr.FirePostCapture()
                if rt is not None:
                    return self._rt_to_texture2d(rt)
            return self._capture_via_camera(width, height, downscaling, transparent)
        elif mode == "kk":
            width = mgr.ResolutionX.Value
            height = mgr.ResolutionY.Value
            downscaling = mgr.DownscalingRate.Value
            if transparent is None:
                try:
                    transparent = bool(mgr.CaptureAlpha.Value)
                except:
                    transparent = False
            if not self._screencap_hijacked():
                # Capture fires OnPreCapture/OnPostCapture internally
                tex = mgr.Instance.Capture(width, height, downscaling, transparent)
                if tex is not None:
                    return tex
            return self._capture_via_camera(width, height, downscaling, transparent)
        else:  # aihs2
            inst = self._find_instance()
            if inst is None:
                return None
            try:
                width = GetPrivateProperty(inst, "CaptureWidth").Value
                height = GetPrivateProperty(inst, "CaptureHeight").Value
            except:
                from UnityEngine import Screen
                width = Screen.width
                height = Screen.height
            try:
                downscaling = GetPrivateStatic(mgr, "Downscaling").Value
            except:
                downscaling = 1
            if transparent is None:
                try:
                    transparent = bool(GetPrivateProperty(inst, "Alpha").Value)
                except:
                    transparent = False
            if not self._screencap_hijacked():
                # Capture fires OnPreCapture/OnPostCapture internally
                rt = inst.Capture(width, height, downscaling, transparent)
                if rt is not None:
                    return self._rt_to_texture2d(rt)
            return self._capture_via_camera(width, height, downscaling, transparent)

    # ---------- public API ----------
    def TakeUIScreenshot(self, filename=None):
        # "Take UI screenshot": capture the screen as seen, interface included
        # filename: full path of the png to write, None = UserData/cap/VNGE-UI-<time>.png
        # NOTE: the file is written by Unity at the end of the current frame, not immediately
        # returns the target file path or None on error
        if not self.isDetected:
            return None
        try:
            filename = self._prepare_filename(filename, "UI")
            mgr = self._manager()
            if self._apimode() == "new":
                mgr.CaptureUI(filename)
            else:
                # old versions have no path parameter in the plugin, but the plugin
                # itself only wraps the Unity screenshot call, so do the same here
                try:
                    upscale = GetPrivateStatic(mgr, "UIShotUpscale").Value
                except:
                    upscale = 1
                try:
                    from UnityEngine import ScreenCapture
                    ScreenCapture.CaptureScreenshot(filename, upscale)
                except ImportError:
                    from UnityEngine import Application
                    Application.CaptureScreenshot(filename, upscale)
            return filename
        except Exception as e:
            print("ScreencapPlugin: TakeUIScreenshot failed: %s" % str(e))
            traceback.print_exc()
            return None

    def TakeRenderScreenshot(self, filename=None, transparent=None):
        # "Take rendered screenshot": no interface, uses plugin render settings
        # (resolution and upsampling come from the plugin config)
        # filename: full path of the png to write, None = UserData/cap/VNGE-Render-<time>.png
        # transparent: True/False to force transparency, None = use plugin config
        # returns the written file path or None on error
        if not self.isDetected:
            return None
        tex = None
        try:
            filename = self._prepare_filename(filename, "Render")
            tex = self._capture_texture2d(transparent)
            if tex is None:
                print("ScreencapPlugin: render capture returned no texture")
                return None
            self._texture2d_to_png(tex, filename)
            return filename
        except Exception as e:
            print("ScreencapPlugin: TakeRenderScreenshot failed: %s" % str(e))
            traceback.print_exc()
            return None
        finally:
            if tex is not None:
                from UnityEngine import Object
                Object.Destroy(tex)

    # ---------- old API kept for compatibility ----------
    def TakeCharScreenshot(self):
        return self.TakeRenderScreenshot()

    def TakeScreenshot(self):
        return self.TakeUIScreenshot()

    def GetUniqueFilename(self):
        return self._default_filename("Render")

    def GetScrenshotTexture(self, transparency):
        # returns a Texture2D of a rendered screenshot, caller must Destroy() it
        if not self.isDetected:
            return None
        try:
            return self._capture_texture2d(transparency)
        except Exception as e:
            print("ScreencapPlugin: GetScrenshotTexture failed: %s" % str(e))
            traceback.print_exc()
            return None

class KKVMDPlayPlugin(ExtPlugin):
    def __init__(self):
        if ExtPlugin.exists("KKVMDPlayPlugin"):
            ExtPlugin.__init__(self, "KKVMDPlayPlugin")
        elif ExtPlugin.exists("KKS_VMDPlayPlugin"):
            ExtPlugin.__init__(self, "KKS_VMDPlayPlugin")
        else:
            self.isDetected = False
        
        # support class instance from plugin
        if self.isDetected:
            from KKVMDPlayPlugin import VMDAnimationMgr
            self.vmdMgr = VMDAnimationMgr.Instance
            self.cameraMgr = self.vmdMgr.CameraMgr
            self.audioMgr = self.vmdMgr.SoundMgr

    # MMD play ALL
    def MMDPlayAll(self):
        if self.isDetected:
            self.vmdMgr.PlayAll()
            
    # MMD Pause ALL
    def MMDPauseAll(self):
        if self.isDetected:
            self.vmdMgr.PauseAll()

    # MMD play ALL
    def MMDStopAll(self):
        if self.isDetected:
            self.vmdMgr.StopAll()
    
    # MMD set anime position
    def MMDSetAnimPositionAll(self, time):
        if self.isDetected:
            self.vmdMgr.PlayAll()
            self.vmdMgr.PauseAll()
            for vc in self.vmdMgr.controllers:
                vc.SetAnimPosition(time)
            self.cameraMgr.AnimePosition = time
            self.audioMgr.AnimePosition = time
                
    # MMD get controller for char
    def MMDGetCharVmdController(self, char):
        from Studio import OCIChar
        if self.isDetected and char:
            if isinstance(char, HSNeoOCIChar):
                tgtChara = char.objctrl.charInfo
            elif isinstance(char, OCIChar): #might be redundant, not sure
                tgtChara = char.charInfo
            else:
                return None
            for vc in self.vmdMgr.controllers:
                if vc.chara == tgtChara:
                    return vc
        return None
        
    # MMD export setting for char
    def MMDExportCharVmdSetting(self, char):
        vc = self.MMDGetCharVmdController(char)
        if vc and vc.VMDAnimEnabled:
            exset = {}
            exset["VMDAnimEnabled"] = "1"
            exset["lastLoadedVMD"] = vc.lastLoadedVMD if vc.lastLoadedVMD else ""
            #exset["isLipSync"] = "1" if vc.isLipSync else "0"
            #exset["speed"] = str(vc.speed)
            #exset["Loop"] = "1" if vc.Loop else "0"
            return exset
        else:
            return None
            
    # MMD import setting for char
    def MMDImportCharVmdSetting(self, char, imSet):
        vc = self.MMDGetCharVmdController(char)
        if vc == None:
            return
        if imSet.has_key("isLipSync"):
            vc.SetLipSyn(imSet["isLipSync"] == "1")
        # is the other settings necessary?     

    # MMD get controller infomation
    def MMDGetAllVmdController(self):
        if not self.isDetected:
            return None
        vcs = []
        for vc in self.vmdMgr.controllers:
            vcs.append(vc)
        return tuple(vcs)

    def MMDGetVmdInfo(self, ctrl):
        info = {}
        try:
            # version 0.1.x
            clip = ctrl.animationForVMD.clip
            info["Loaded"] = clip != None
            info["ChaControl"] = ctrl.chara
            info["FilePath"] = ctrl.lastLoadedVMD
            info["Length"] = 0 if clip == None else ctrl.animationForVMD.clip.length
            info["Frames"] = 0 if clip == None else int(ctrl.animationForVMD.clip.length * 30.0)
            #info["BoneNameMap"] = ctrl.boneNameMap
            #info["BoneAdjustMap"] = ctrl.boneAdjust
        except:
            # version 0.3.x
            state = ctrl.GetModelAnimationState()
            info["Loaded"] = state != None
            info["ChaControl"] = ctrl.chara
            info["FilePath"] = ctrl.lastLoadedVMD
            info["Length"] = 0 if state == None else state.length
            info["Frames"] = 0 if state == None else int(state.length * 30.0)
            #info["BoneNameMap"] = ctrl.boneNameMap
            #info["BoneAdjustMap"] = ctrl.boneAdjust
        return info

    def MMDGetCameraInfo(self):
        if not self.isDetected:
            return None
        info = {}
        info["Loaded"] = False
        if self.cameraMgr.AnimeLength > 0 and self.cameraMgr.cameraVMDFilePath != None:
            info["Loaded"] = True
            info["Enabled"] = self.cameraMgr.CameraEnabled
            info["FilePath"] = self.cameraMgr.cameraVMDFilePath
            info["Length"] = self.cameraMgr.AnimeLength
        return info

    def MMDGetSoundInfo(self):
        if not self.isDetected:
            return None
        info = {}
        info["Loaded"] = False
        if self.audioMgr.currentAudioClip != None:
            info["Loaded"] = True
            info["FilePath"] = self.audioMgr.audioFilePath
            info["Length"] = self.audioMgr.SoundLength
        return info

    # control and sync
    def MMDPlayVmd(self, ctrl):
        ctrl.Play()

    def MMDPauseVmd(self, ctrl):
        ctrl.Pause()

    def MMDStopVmd(self, ctrl):
        ctrl.Stop()

    def MMDSyncVmd(self, ctrl, time):
        ctrl.SetAnimPosition(time)

    def MMDPlayCamera(self):
        if self.isDetected:
            self.cameraMgr.Play()

    def MMDPauseCamera(self):
        if self.isDetected:
            self.cameraMgr.Pause()

    def MMDStopCamera(self):
        if self.isDetected:
            self.cameraMgr.Stop()

    def MMDSyncCamera(self, time):
        if self.isDetected:
            self.cameraMgr.AnimePosition = time

    def MMDPlaySound(self):
        if self.isDetected:
            self.audioMgr.PlaySound()

    def MMDPauseSound(self):
        if self.isDetected:
            self.audioMgr.PauseSound()

    def MMDStopSound(self):
        if self.isDetected:
            self.audioMgr.StopSound()

    def MMDSyncSound(self, time):
        if self.isDetected:
            self.audioMgr.AnimePosition = time

class AIVMDPlugin(ExtPlugin):
    def __init__(self):
        self.isDetected = False
        self.name = ""
        # try load AIVMDPlugin from maki3d, as manager1
        if ExtPlugin.exists("AIVMDPlugin"):
            self.isDetected1 = True
            self.name = "AIVMDPlugin"
            clr.AddReference("AIVMDPlugin")
            from AIVMDPlugin import VMDMotionManager
            self.vmdMgr1 = VMDMotionManager.Instance
            self.audioMgr1 = self.vmdMgr1.AudioManager
            self.cameraMgr1 = self.vmdMgr1.CameraManager
        else:
            self.isDetected1 = False
        # try load AIVMDPlayer from craft6, as manager2
        if ExtPlugin.exists("AIVMDPlayer"):
            self.isDetected2 = True
            self.name = "AIVMDPlugin"
            clr.AddReference("AIVMDPlayer")
            from AIVMDPlayer import VMDAnimationMgr
            self.vmdMgr2 = VMDAnimationMgr.Instance
            self.audioMgr2 = self.vmdMgr2.SoundMgr
            self.cameraMgr2 = self.vmdMgr2.CameraMgr
        else:
            self.isDetected2 = False
        # if found any one
        self.isDetected = self.isDetected1 or self.isDetected2

    # MMD play ALL
    def MMDPlayAll(self):
        if self.isDetected1:
            self.vmdMgr1.playAll()
        if self.isDetected2:
            self.vmdMgr2.PlayAll()
            
    # MMD Pause ALL
    def MMDPauseAll(self):
        if self.isDetected1:
            self.vmdMgr1.pauseAll()
        if self.isDetected2:
            self.vmdMgr2.PauseAll()

    # MMD play ALL
    def MMDStopAll(self):
        if self.isDetected1:
            self.vmdMgr1.stopAll()
        if self.isDetected2:
            self.vmdMgr2.StopAll()
    
    # MMD set anime position
    def MMDSetAnimPositionAll(self, time):
        if self.isDetected1:
            self.vmdMgr1.playAll()
            self.vmdMgr1.pauseAll()
            for vc in self.vmdMgr1.controllers:
                vc.SetAnimPosition(time)
            self.audioMgr1.AnimePosition = time
            self.cameraMgr1.AnimePosition = time
        if self.isDetected2:
            self.vmdMgr2.PlayAll()
            self.vmdMgr2.PauseAll()
            for vc in self.vmdMgr2.controllers:
                vc.SetAnimPosition(time)
            self.audioMgr2.AnimePosition = time
            self.cameraMgr2.AnimePosition = time
                
    # MMD get controller for char
    def MMDGetCharVmdController(self, char):
        from Studio import OCIChar
        if isinstance(char, HSNeoOCIChar):
            tgtChara = char.objctrl.charInfo
        elif isinstance(char, OCIChar): #might be redundant, not sure
            tgtChara = char.charInfo
        else:
            return None
        if self.isDetected1:
            for vc in self.vmdMgr1.controllers:
                if vc.chara == tgtChara:
                    return vc
        if self.isDetected2:
            for vc in self.vmdMgr2.controllers:
                if vc.chara == tgtChara:
                    return vc
        return None

    # MMD export setting for char
    def MMDExportCharVmdSetting(self, char):
        vc = self.MMDGetCharVmdController(char)
        if vc and vc.VMDAnimEnabled:
            exset = {}
            exset["VMDAnimEnabled"] = "1"
            exset["lastLoadedVMD"] = vc.lastLoadedVMD if vc.lastLoadedVMD else ""
            #exset["isLipSync"] = "1" if vc.isLipSync else "0"
            #exset["speed"] = str(vc.speed)
            #exset["Loop"] = "1" if vc.Loop else "0"
            return exset
        else:
            return None

    # MMD import setting for char
    def MMDImportCharVmdSetting(self, char, imSet):
        vc = self.MMDGetCharVmdController(char)
        if vc == None:
            return
        #if imSet.has_key("isLipSync"):
        #    vc.SetLipSyn(imSet["isLipSync"] == "1")
        # is the other settings necessary?     

    # MMD get all controller
    def MMDGetAllVmdController(self):
        if not self.isDetected:
            return None
        vcs = []
        if self.isDetected1:
            for vc in self.vmdMgr1.controllers:
                vcs.append(vc)
        if self.isDetected2:
            for vc in self.vmdMgr2.controllers:
                vcs.append(vc)
        return tuple(vcs)
    
    def MMDPlayVmd(self, ctrl):
        ctrl.Play()

    def MMDPauseVmd(self, ctrl):
        ctrl.Pause()

    def MMDStopVmd(self, ctrl):
        ctrl.Stop()

    def MMDSyncVmd(self, ctrl, time):
        ctrl.SetAnimPosition(time)

    def MMDGetVmdInfo(self, ctrl):
        info = {}
        clip = ctrl.animationForVMD.clip
        info["Loaded"] = clip != None
        info["ChaControl"] = ctrl.chara
        info["FilePath"] = ctrl.lastLoadedVMD
        info["Length"] = 0 if clip == None else ctrl.animationForVMD.clip.length
        info["Frames"] = 0 if clip == None else int(ctrl.animationForVMD.clip.length * 30.0)
        #info["BoneNameMap"] = ctrl.boneNameMap
        #info["BoneAdjustMap"] = ctrl.boneAdjust
        return info

    def MMDPlaySound(self):
        if self.isDetected1:
            self.audioMgr1.playSound()
        if self.isDetected2:
            self.audioMgr2.PlaySound()

    def MMDPauseSound(self):
        if self.isDetected1:
            self.audioMgr1.pauseSound()
        if self.isDetected2:
            self.audioMgr2.PauseSound()

    def MMDStopSound(self):
        if self.isDetected1:
            self.audioMgr1.stopSound()
        if self.isDetected2:
            self.audioMgr2.StopSound()

    def MMDSyncSound(self, time):
        if self.isDetected1:
            self.audioMgr1.AnimePosition = time
        if self.isDetected2:
            self.audioMgr2.AnimePosition = time

    def MMDGetSoundInfo(self):
        if not self.isDetected:
            return None
        info = {}
        info["Loaded"] = False
        if self.isDetected1 and self.audioMgr1.currentAudioClip != None:
            info["Loaded"] = True
            info["FilePath"] = self.audioMgr1.AudioFilePath
            info["Length"] = self.audioMgr1.SoundLength
        if self.isDetected2 and self.audioMgr2.currentAudioClip != None:
            info["Loaded"] = True
            info["FilePath"] = self.audioMgr2.audioFilePath
            info["Length"] = self.audioMgr2.SoundLength
        return info

    def MMDSetSound(self, pathname):
        if self.isDetected2:
            return self.audioMgr2.SetSoundClip(pathname)
        return False

    def MMDPlayCamera(self):
        if self.isDetected1:
            self.cameraMgr1.play()
        if self.isDetected2:
            self.cameraMgr2.Play()

    def MMDPauseCamera(self):
        if self.isDetected1:
            self.cameraMgr1.pause()
        if self.isDetected2:
            self.cameraMgr2.Pause()

    def MMDStopCamera(self):
        if self.isDetected1:
            self.cameraMgr1.stop()
        if self.isDetected2:
            self.cameraMgr2.Stop()

    def MMDSyncCamera(self, time):
        if self.isDetected1:
            self.cameraMgr1.AnimePosition = time
        if self.isDetected2:
            self.cameraMgr2.AnimePosition = time

    def MMDGetCameraInfo(self):
        if not self.isDetected:
            return None
        info = {}
        info["Loaded"] = False
        if self.isDetected1 and self.cameraMgr1.AnimeLength > 0 and self.cameraMgr1.cameraVMDFilePath != None:
            info["Loaded"] = True
            info["Enabled"] = self.cameraMgr1.CameraEnabled
            info["FilePath"] = self.cameraMgr1.cameraVMDFilePath
            info["Length"] = self.cameraMgr1.AnimeLength
        if self.isDetected2 and self.cameraMgr2.AnimeLength > 0 and self.cameraMgr2.cameraVMDFilePath != None:
            info["Loaded"] = True
            info["Enabled"] = self.cameraMgr2.CameraEnabled
            info["FilePath"] = self.cameraMgr2.cameraVMDFilePath
            info["Length"] = self.cameraMgr2.AnimeLength
        return info

class HS2VMDPlayPlugin(ExtPlugin):
    def __init__(self):
        ExtPlugin.__init__(self, "HS2_VMDPlayPlugin")
        # support class instance from plugin
        if self.isDetected:
            from HS2VMDPlayPlugin import VMDAnimationMgr
            self.vmdMgr = VMDAnimationMgr.Instance
            self.cameraMgr = self.vmdMgr.CameraMgr
            self.audioMgr = self.vmdMgr.SoundMgr

    # MMD play ALL
    def MMDPlayAll(self):
        if self.isDetected:
            self.vmdMgr.PlayAll()
            
    # MMD Pause ALL
    def MMDPauseAll(self):
        if self.isDetected:
            self.vmdMgr.PauseAll()

    # MMD play ALL
    def MMDStopAll(self):
        if self.isDetected:
            self.vmdMgr.StopAll()
    
    # MMD set anime position
    def MMDSetAnimPositionAll(self, time):
        if self.isDetected:
            self.vmdMgr.PlayAll()
            self.vmdMgr.PauseAll()
            for vc in self.vmdMgr.controllers:
                vc.SetAnimPosition(time)
            self.cameraMgr.AnimePosition = time
            self.audioMgr.AnimePosition = time
                
    # MMD get controller for char
    def MMDGetCharVmdController(self, char):
        from Studio import OCIChar
        if self.isDetected and char:
            if isinstance(char, HSNeoOCIChar):
                tgtChara = char.objctrl.charInfo
            elif isinstance(char, OCIChar): #might be redundant, not sure
                tgtChara = char.charInfo
            else:
                return None
            for vc in self.vmdMgr.controllers:
                if vc.chara == tgtChara:
                    return vc
        return None
        
    # MMD export setting for char
    def MMDExportCharVmdSetting(self, char):
        vc = self.MMDGetCharVmdController(char)
        if vc and vc.VMDAnimEnabled:
            exset = {}
            exset["VMDAnimEnabled"] = "1"
            exset["lastLoadedVMD"] = vc.lastLoadedVMD if vc.lastLoadedVMD else ""
            #exset["isLipSync"] = "1" if vc.isLipSync else "0"
            #exset["speed"] = str(vc.speed)
            #exset["Loop"] = "1" if vc.Loop else "0"
            return exset
        else:
            return None
            
    # MMD import setting for char
    def MMDImportCharVmdSetting(self, char, imSet):
        vc = self.MMDGetCharVmdController(char)
        if vc == None:
            return
        if imSet.has_key("isLipSync"):
            vc.SetLipSyn(imSet["isLipSync"] == "1")
        # is the other settings necessary?     

    # MMD get controller infomation
    def MMDGetAllVmdController(self):
        if not self.isDetected:
            return None
        vcs = []
        for vc in self.vmdMgr.controllers:
            vcs.append(vc)
        return tuple(vcs)

    def MMDGetVmdInfo(self, ctrl):
        info = {}
        state = ctrl.GetModelAnimationState()
        info["Loaded"] = state != None
        info["ChaControl"] = ctrl.chara
        info["FilePath"] = ctrl.lastLoadedVMD
        info["Length"] = 0 if state == None else state.length
        info["Frames"] = 0 if state == None else int(state.length * 30.0)
        #info["BoneNameMap"] = ctrl.boneNameMap
        #info["BoneAdjustMap"] = ctrl.boneAdjust
        return info

    def MMDGetCameraInfo(self):
        if not self.isDetected:
            return None
        info = {}
        info["Loaded"] = False
        if self.cameraMgr.AnimeLength > 0 and self.cameraMgr.cameraVMDFilePath != None:
            info["Loaded"] = True
            info["Enabled"] = self.cameraMgr.CameraEnabled
            info["FilePath"] = self.cameraMgr.cameraVMDFilePath
            info["Length"] = self.cameraMgr.AnimeLength
        return info

    def MMDGetSoundInfo(self):
        if not self.isDetected:
            return None
        info = {}
        info["Loaded"] = False
        if self.audioMgr.currentAudioClip != None:
            info["Loaded"] = True
            info["FilePath"] = self.audioMgr.audioFilePath
            info["Length"] = self.audioMgr.SoundLength
        return info

    # control and sync
    def MMDPlayVmd(self, ctrl):
        ctrl.Play()

    def MMDPauseVmd(self, ctrl):
        ctrl.Pause()

    def MMDStopVmd(self, ctrl):
        ctrl.Stop()

    def MMDSyncVmd(self, ctrl, time):
        ctrl.SetAnimPosition(time)

    def MMDPlayCamera(self):
        if self.isDetected:
            self.cameraMgr.Play()

    def MMDPauseCamera(self):
        if self.isDetected:
            self.cameraMgr.Pause()

    def MMDStopCamera(self):
        if self.isDetected:
            self.cameraMgr.Stop()

    def MMDSyncCamera(self, time):
        if self.isDetected:
            self.cameraMgr.AnimePosition = time

    def MMDPlaySound(self):
        if self.isDetected:
            self.audioMgr.PlaySound()

    def MMDPauseSound(self):
        if self.isDetected:
            self.audioMgr.PauseSound()

    def MMDStopSound(self):
        if self.isDetected:
            self.audioMgr.StopSound()

    def MMDSyncSound(self, time):
        if self.isDetected:
            self.audioMgr.AnimePosition = time

class DHH_AI(ExtPlugin):
    def __init__(self):
        self.is_new_dhh = ExtPlugin.exists("DHH_HS2") or ExtPlugin.exists("DHH_AI")
        if self.is_new_dhh:
            if ExtPlugin.exists("DHH_HS2"):
                ExtPlugin.__init__(self, "DHH_HS2")
            elif ExtPlugin.exists("DHH_AI"):
                ExtPlugin.__init__(self, "DHH_AI")
        else:
            ExtPlugin.__init__(self, "DHH_AI4")
            if self.isDetected:
                from DHH_AI4 import DHH_Main
                self.dhh_main = DHH_Main.instance
                self.dhh_path = os.path.realpath(GetPrivate(self.dhh_main, "path"))
                self.dhh_tempfile = os.path.join(self.dhh_path, "VNGETemp")
                self.delTempFiles()

    def getEnable(self):
        if self.isDetected:
            if self.is_new_dhh:
                from DHH import DHH_Main
                return DHH_Main.GraphicEnable
            else:
                return GetPrivate(self.dhh_main, "GraphicEnable")
        else:
            return False

    def setEnable(self, enable):
        if self.isDetected:
            if self.is_new_dhh:
                from DHH import DHH_Main
                DHH_Main.GraphicEnable = enable
            else:
                self.dhh_main.SetEnable(enable)

    def exportGraphSetting(self):
        if self.isDetected:
            if self.is_new_dhh:
                from DHH import DHH_Main
                return DHH_Main.Setting
            else:
                self.delTempFiles()
                idx = 0
                while (True):
                    indexedFile = self.dhh_tempfile + str(idx)
                    if not os.path.exists(indexedFile):
                        break
                    else:
                        idx += 1
                CallPrivate(self.dhh_main, "SaveGraphicSetting", [indexedFile])
                fp = open(indexedFile, "r")
                settxt = fp.read()
                fp.close()
                return settxt
        else:
            return None

    def importGraphSetting(self, setting):
        if self.isDetected:
            if self.is_new_dhh:
                from DHH import DHH_Main
                DHH_Main.Setting = setting
            else:
                self.delTempFiles()
                idx = 0
                while (True):
                    try:
                        indexedFile = self.dhh_tempfile + str(idx)
                        fp = open(indexedFile, "w")
                        fp.write(setting)
                        fp.flush()
                        fp.close()
                        break
                    except:
                        idx += 1
                # LoadGraphicSetting didn't close file stream...
                CallPrivate(self.dhh_main, "LoadGraphicSetting", [indexedFile])

    def delTempFiles(self):
        if self.isDetected:
            import os
            tempfiles = []
            for f in os.listdir(self.dhh_path):
                if f.startswith("VNGETemp"):
                    tempfiles.append(os.path.join(self.dhh_path, f))
            for f in tempfiles:
                try:
                    os.remove(f)
                except:
                    pass

class Graphics(ExtPlugin):
    def __init__(self):
        self.postPocessingValid = False
        self.graphicsInstance = None
        if ExtPlugin.exists("HS2Graphics"):
            ExtPlugin.__init__(self, "HS2Graphics")
        elif ExtPlugin.exists("AIGraphics"):
            ExtPlugin.__init__(self, "AIGraphics")
        else:
            self.isDetected = False
            return
        try:
            from Graphics import Graphics
            self.graphicsInstance = Graphics.Instance

            clr.AddReference("Unity.Postprocessing.Runtime")
            self.postPocessingValid = True
        except:
            pass

    def getEnable(self):
        if self.isDetected:
            try:
                from Graphics import Graphics
                return Graphics.PluginEnabled
            except Exception as e:
                print("cant get Graphics.PluginEnabled ")
                return True
        else:
            return False

    def setEnable(self, enable):
        if self.isDetected:
            try:
                from Graphics import Graphics
                Graphics.PluginEnabled = enable
            except Exception as e:
                print("cant set Graphics.PluginEnabled ")

    def getIgnoreDHHConflicts(self):
        if self.isDetected:
            try:
                from Graphics import Graphics
                return Graphics.IgnoreDHHConflicts
            except Exception as e:
                print("cant get Graphics.IgnoreDHHConflicts ")
                return True
        else:
            return True

    def setIgnoreDHHConflicts(self, ignore):
        if self.isDetected:
            try:
                from Graphics import Graphics
                Graphics.IgnoreDHHConflicts = ignore
            except Exception as e:
                print("cant set Graphics.IgnoreDHHConflicts ")

    def exportPreset(self):
        if self.isDetected:
            try:
                from Graphics import Graphics
                return Graphics.PresetString
            except Exception as e:
                # try new way Graphics
                prMan = self.getPresetsManager()
                return CallPrivate(prMan,"get_CurrentPreset",[])
        else:
            return None

    def importPreset(self, setting):
        if self.isDetected:
            try:
                from Graphics import Graphics
                Graphics.PresetString = setting
            except Exception as e:
                # try new way Graphics
                prMan = self.getPresetsManager()
                CallPrivate(prMan,"set_CurrentPreset",[setting])

    def getPresetsManager(self):
        from Graphics import Graphics
        # Graphics.PresetManager
        return GetPrivate(Graphics.Instance, "_presetManager")

    def getPresetData(self):
        if self.isDetected:
            try:
                from Graphics import Graphics
                #ba = Graphics.Instance.preset.Serialize()

                # workaround - get Bytes from ExtData
                paMan = self.getPresetsManager()
                extdata = CallPrivate(paMan, "GetExtendedData", [])
                ba = extdata.data["bytes"]
                from vnactor import bytearray_to_str64
                return bytearray_to_str64(ba)
            except Exception as e:
                print("cant get Graphics.Instance.preset.Serialize()")
                return ""
        else:
            return ""

    def setPresetData(self,str64):
        if self.isDetected:
            try:
                from Graphics import Graphics
                #ba = Graphics.Instance.preset.Serialize()
                from vnactor import str64_to_bytearray
                #ba = str64_to_bytearray(str64)
                #Graphics.Instance.preset.Load(ba)

                # workaround - save in presets folder and load tempvnge preset
                from System.IO import File
                File.WriteAllBytes("presets/tempvnge.preset", str64_to_bytearray(str64))
                CallPrivate(self.getPresetsManager(), "LoadPresets",[]) # reloading preset list
                self.importPreset("tempvnge")
            except Exception as e:
                print("cant Graphics.Instance.preset.Load()")
                return ""
        else:
            return ""
        
    def getPostProcessingSetting(self):
        try:
            if not self.postPocessingValid or self.graphicsInstance == None:
                return None
            
            from UnityEngine.Rendering import PostProcessing
            pps = GetPrivateProperty(self.graphicsInstance, "PostProcessingSettings")

            ppSetting = {}
            # depth Of Field
            dof = GetPrivate(pps, "depthOfFieldLayer")
            ppSetting["DepthOfField"] = {}
            ppSetting["DepthOfField"]["enabled"] = dof.enabled.value
            ppSetting["DepthOfField"]["focusDistance"] = dof.focusDistance.value
            ppSetting["DepthOfField"]["aperture"] = dof.aperture.value
            ppSetting["DepthOfField"]["focalLength"] = dof.focalLength.value
            ppSetting["DepthOfField"]["kernelSize"] = str(dof.kernelSize.value)

            return ppSetting

        except Exception as e:
            traceback.print_exc()
            return None

class HSIBL(ExtPlugin):
    def __init__(self):
        self.HSIBLInstance = None
        if ExtPlugin.exists("HSIBL"):
            ExtPlugin.__init__(self, "HSIBL")
        elif ExtPlugin.exists("HSLRE"):
            ExtPlugin.__init__(self, "HSLRE")
        else:
            self.isDetected = False
            return
        try:
            from UnityEngine import GameObject
            from HSIBL import HSIBL
            
            HSIBLobj = GameObject.Find("HSIBL")
            self.HSIBLInstance = HSIBLobj.GetComponent[HSIBL]()
        except:
            pass

    def GetSettingData(self):
        if not self.isDetected or not self.HSIBLInstance:
            return None

        clr.AddReference("System.Xml")

        from System.IO import StringWriter
        from System.Xml import XmlTextWriter

        stringWriter = StringWriter()
        xmlTextWriter = XmlTextWriter(stringWriter)
        xmlTextWriter.WriteStartElement("root")
        CallPrivate(self.HSIBLInstance, "SaveConfig", [xmlTextWriter])
        xmlTextWriter.WriteEndElement()

        settingData = stringWriter.ToString()
        return settingData

    def SetSettingsData(self, text):
        if not self.isDetected or not self.HSIBLInstance:
            return

        clr.AddReference("System.Xml")
        from System.Xml import XmlDocument

        xmlDocument = XmlDocument()
        xmlDocument.LoadXml(text)
        root = xmlDocument.FirstChild

        CallPrivate(self.HSIBLInstance, "LoadConfig", [root])
        
class RendererEditor(ExtPlugin):
    def __init__(self):
        self.rendererEditorInstance = None
        if ExtPlugin.exists("RendererEditor"):
            ExtPlugin.__init__(self, "RendererEditor")
        else:
            self.isDetected = False
            return
        try:
            # new version
            from RendererEditor import RendererEditor
            self.rendererEditorInstance = GetPrivateStatic(RendererEditor, "_self")
        except:
            # old version
            try:
                from RendererEditor import MainWindow
                self.rendererEditorInstance = GetPrivateStatic(MainWindow, "_self")
            except:
                pass

    def ResetAllTarget(self):
        if not self.isDetected or not self.rendererEditorInstance:
            return None
        
        dirtyTargetDict = GetPrivate(self.rendererEditorInstance, "_dirtyTargets")
        dirtyTargets = list(dirtyTargetDict.Keys)
        for target in dirtyTargets:
            CallPrivate(self.rendererEditorInstance, "ResetTarget", [target, True])

    def GetSettingData(self):
        if not self.isDetected or not self.rendererEditorInstance:
            return None

        clr.AddReference("System.Xml")

        from System.IO import StringWriter
        from System.Xml import XmlTextWriter

        stringWriter = StringWriter()
        xmlTextWriter = XmlTextWriter(stringWriter)
        xmlTextWriter.WriteStartElement("rendererEditor")
        CallPrivate(self.rendererEditorInstance, "OnSceneSave", ["dummy_path", xmlTextWriter])
        xmlTextWriter.WriteEndElement()

        settingData = stringWriter.ToString()
        return settingData

    def SetSettingsData(self, text):
        if not self.isDetected or not self.rendererEditorInstance:
            return
        
        self.ResetAllTarget()

        clr.AddReference("System.Xml")
        from System.Xml import XmlDocument

        xmlDocument = XmlDocument()
        xmlDocument.LoadXml(text)
        root = xmlDocument.FirstChild

        CallPrivate(self.rendererEditorInstance, "OnSceneLoad", ["dummy_path", root])

class StudioSceneSettings(ExtPlugin):
    def __init__(self):
        if ExtPlugin.exists("KK_StudioSceneSettings"):
            ExtPlugin.__init__(self, "KK_StudioSceneSettings")
            self.engine = "KK"
        elif ExtPlugin.exists("KKS_StudioSceneSettings"):
            ExtPlugin.__init__(self, "KKS_StudioSceneSettings")
            self.engine = "KKS"
        elif ExtPlugin.exists("AI_StudioSceneSettings"):
            ExtPlugin.__init__(self, "AI_StudioSceneSettings")
            self.engine = "AI"
        elif ExtPlugin.exists("HS2_StudioSceneSettings"):
            ExtPlugin.__init__(self, "HS2_StudioSceneSettings")
            self.engine = "HS2"
        else:
            self.isDetected = False
            self.engine = None

    def GetSettingData(self):
        if not self.isDetected:
            return None
        try:
            from KK_Plugins.StudioSceneSettings import SceneController
            data = {}
            data["MapMasking"] = SceneController.MapMasking.Value
            data["NearClipPlane"] = SceneController.NearClipPlane.Value
            data["FarClipPlane"] = SceneController.FarClipPlane.Value
            data["ShadowDistance"] = SceneController.ShadowDistance.Value
            return data
        except:
            traceback.print_exc()
            return None

    def SetSettingsData(self, data):
        if not self.isDetected or not data:
            return
        try:
            from KK_Plugins.StudioSceneSettings import SceneController
            if "MapMasking" in data:
                SceneController.MapMasking.Value = data["MapMasking"]
            if "NearClipPlane" in data:
                SceneController.NearClipPlane.Value = data["NearClipPlane"]
            if "FarClipPlane" in data:
                SceneController.FarClipPlane.Value = data["FarClipPlane"]
            if "ShadowDistance" in data:
                SceneController.ShadowDistance.Value = data["ShadowDistance"]
        except:
            traceback.print_exc()

class AI_FKIK(ExtPlugin):
    def __init__(self):
        if ExtPlugin.exists("AI_FKIK"):
            ExtPlugin.__init__(self, "AI_FKIK")
        elif ExtPlugin.exists("HS2_FKIK"):
            ExtPlugin.__init__(self, "HS2_FKIK")
        else:
            self.isDetected = False
        #ExtPlugin.__init__(self, "AI_FKIK")

    # Activate simulataneous FK/IK (char: HSNeoOCIChar, OCIChar)
    def activateFKIK(self, char):
        from Studio import OCIChar
        if self.isDetected == True and not char == None:
            from KK_Plugins import FKIK
            if isinstance(char, HSNeoOCIChar):
                FKIK.EnableFKIK(char.objctrl)
            elif isinstance(char, OCIChar): #might be redundant, not sure
                FKIK.EnableFKIK(char)

class CharaAnime(ExtPlugin):
    def __init__(self):
        ExtPlugin.__init__(self, "CharaAnime")
        if self.isDetected:
            from CharaAnime import CharaAnimeMgr, GizmosManager
            from UnityEngine import Camera
            self.Manager = CharaAnimeMgr.Instance
            self.GizmosMgr = GizmosManager.Instance

            # Chara Anime Mgr initialize
            if self.Manager == None:
                print("Start Chara Anime Manager in extplugin")
                CharaAnimeMgr.Install(Camera.main.gameObject)

            # Gizmo Mgr initialize
            if self.GizmosMgr == None:
                print("Start Gizmo Manager in extplugin")
                GizmosManager.Install(Camera.main.gameObject)

# ::::::::::: NodesConstraints (HS,KK) :::::::::::
class NodesConstraints(ExtPlugin):
    def __init__(self):
        ExtPlugin.__init__(self, "NodesConstraints")
        if self.isDetected:
            from NodesConstraints import NodesConstraints
            self.nodescon = GetPrivateStatic(NodesConstraints, "_self")
        else:
            self.nodescon = None

    def GetSysSettingsText(self):
        if not self.isDetected or not self.nodescon:
            return None

        clr.AddReference("System.Xml")

        from System.IO import StringWriter
        from System.Xml import XmlTextWriter, XmlDocument

        stringWriter = StringWriter()
        xmlTextWriter = XmlTextWriter(stringWriter)

        xmlTextWriter.WriteStartElement("nodescon")
        #ocichar.charInfo.gameObject.GetComponent(PoseController).SaveXml(xmlTextWriter)

        try:
            CallPrivate(self.nodescon,"SaveSceneGeneric",[xmlTextWriter])
        except:
            CallPrivate(self.nodescon, "OnSceneSave", ["dummy path", xmlTextWriter])

        xmlTextWriter.WriteEndElement()

        #return stringWriter.ToString()
        settingData = stringWriter.ToString()
        try:
            # load contents of setting data
            xDoc = XmlDocument()
            xDoc.LoadXml(settingData)

            # get the sorted list of all objects in studio
            from Studio import Studio
            studio = Studio.Instance
            silist = sorted(list(studio.dicObjectCtrl.Keys))
            
            # find each setting and adjust
            xRoot = xDoc.FirstChild
            if xRoot.Name != "nodescon":
                print("NodesConstraints Error: unexpected root node, should be 'nodescon'.")
                raise Exception()
            if not xRoot.HasChildNodes or xRoot.FirstChild.Name != "constraints":
                print("NodesConstraints Error: miss container node 'constraints'")
                raise Exception()
            for nc in xRoot.FirstChild.ChildNodes:
                if nc.Name == "constraint":
                    pidx = int(nc.GetAttribute("parentObjectIndex"))
                    cidx = int(nc.GetAttribute("childObjectIndex"))
                    pid = silist[pidx]
                    cid = silist[cidx]
                    #print "constraint setting: %d(%d) -> %d(%d)"%(pidx, pid, cidx, cid)
                    nc.SetAttribute("parentObjectID", str(pid))
                    nc.SetAttribute("childObjectID", str(cid))
                else:
                    print("NodesConstraints Warning: unknown setting node '%s'"%nc.Name)
            # export again
            stringWriter2 = StringWriter()
            xmlTextWriter2 = XmlTextWriter(stringWriter2)
            xDoc.WriteContentTo(xmlTextWriter2)
            settingData = stringWriter2.ToString()
        except:
            pass
        return settingData

    def SetSysSettingsText(self, text):
        if not self.isDetected or not self.nodescon:
            return

        clr.AddReference("System.Xml")

        from System.IO import StringWriter
        from System.Xml import XmlDocument

        xmlDocument = XmlDocument()
        xmlDocument.LoadXml(text)
        node = xmlDocument.FirstChild

        # re-calcuate object index base on the id
        try:
            # get the sorted list of all objects in studio
            from Studio import Studio
            studio = Studio.Instance
            silist = sorted(list(studio.dicObjectCtrl.Keys))

            if node.Name != "nodescon":
                print("NodesConstraints Error: unexpected root node, should be 'nodescon'.")
                raise Exception()
            if not node.HasChildNodes or node.FirstChild.Name != "constraints":
                print("NodesConstraints Error: miss container node 'constraints'")
                raise Exception()
            for nc in node.FirstChild.ChildNodes:
                if nc.Name == "constraint":
                    pid = int(nc.GetAttribute("parentObjectID"))
                    cid = int(nc.GetAttribute("childObjectID"))
                    pidx = silist.index(pid)
                    cidx = silist.index(cid)
                    #print "constraint setting: %d(%d) -> %d(%d)"%(pidx, pid, cidx, cid)
                    nc.SetAttribute("parentObjectIndex", str(pidx))
                    nc.SetAttribute("childObjectIndex", str(cidx))
                else:
                    print("NodesConstraints Warning: unknown setting node '%s'"%nc.Name)
        except:
            pass

        #clear node
        self.ClearConstrains()

        try:
            # new version
            CallPrivate(self.nodescon, "ExternalLoadScene", node)
            #self.nodescon.ExternalLoadScene(node)
            #print("NodesConstraints set by ExternalLoadScene(node)")
        except:
            traceback.print_exc()
            try:
                # HS version
                CallPrivate(self.nodescon, "LoadSceneGeneric", [node.FirstChild, -1])
                #print("NodesConstraints set by LoadSceneGeneric(node.FirstChild, -1)")
            except:
                # another try
                traceback.print_exc()
                CallPrivate(self.nodescon, "OnSceneLoad", ["dummy path", node])
                #print("NodesConstraints set by OnSceneLoad(dummyPath, node)")

    def ClearConstrains(self):
        if not self.isDetected or not self.nodescon:
            return

        constrains = GetPrivate(self.nodescon, "_constraints")
        for i in range(len(constrains)):
            CallPrivate(self.nodescon,"RemoveConstraintAt",[0])
        #ocichar.charInfo.gameObject.GetComponent(PoseController).ScheduleLoad(node, None)

    def GetConstrains(self):
        if not self.isDetected or not self.nodescon:
            return None
        constrains = GetPrivate(self.nodescon,"_constraints")
        return list(constrains)

    def GetNewToOldKeys(self):
        if not self.isDetected or not self.nodescon:
            return None
        
        from NodesConstraints import NodesConstraints
        try:
            siip = GetPrivateNestedType(NodesConstraints, "SceneInfo_Import_Patches")

            return GetPrivateStatic(siip, "_newToOldKeys")
        except:
            return None
        
    def ToggleUiVisible(self):
        if not self.isDetected or not self.nodescon:
            return
        showUI = GetPrivate(self.nodescon, "_showUI")
        SetPrivate(self.nodescon, "_showUI", not showUI)


# ::::::::::: ExtensibleSaveFormat (KK Bep5, AI) :::::::::::
class ExtensibleSaveFormat(ExtPlugin):
    def __init__(self):
        if ExtPlugin.exists("AI_ExtensibleSaveFormat"):
            ExtPlugin.__init__(self, "AI_ExtensibleSaveFormat")
        elif ExtPlugin.exists("HS2_ExtensibleSaveFormat"):
            ExtPlugin.__init__(self, "HS2_ExtensibleSaveFormat")
        elif ExtPlugin.exists("ExtensibleSaveFormat"):
            ExtPlugin.__init__(self, "ExtensibleSaveFormat")
        elif ExtPlugin.exists("KKS_ExtensibleSaveFormat"):
            ExtPlugin.__init__(self, "KKS_ExtensibleSaveFormat")
        elif ExtPlugin.exists("PH_ExtensibleSaveFormat"): # no, PH version doesn't suport studio save/load events
            ExtPlugin.__init__(self, "PH_ExtensibleSaveFormat")
        else:
            self.isDetected = False
        if self.isDetected:
            from ExtensibleSaveFormat import PluginData
            self.extSaveData = PluginData()
        else:
            self.extSaveData = None

    def reg_scene_being_loaded(self,callback):
        from ExtensibleSaveFormat import ExtendedSave
        ExtendedSave.SceneBeingLoaded += callback

    def reg_scene_being_saved(self,callback):
        from ExtensibleSaveFormat import ExtendedSave
        ExtendedSave.SceneBeingSaved += callback

    def reg_scene_being_imported(self,callback):
        from ExtensibleSaveFormat import ExtendedSave
        ExtendedSave.SceneBeingImported += callback

    def setExtendSaveData(self, key, data):
        if self.isDetected and self.extSaveData:
            self.extSaveData.data[key] = data

    def getExtendSaveData(self, key):
        if self.isDetected and self.extSaveData and self.extSaveData.data.ContainsKey(key):
            return self.extSaveData.data[key]
        else:
            return None

    def delExtendSaveData(self, key):
        if self.isDetected and self.extSaveData and self.extSaveData.data.ContainsKey(key):
            self.extSaveData.data.Remove(key)

    def newExtendSaveData(self, key):
        if self.isDetected:
            from ExtensibleSaveFormat import PluginData
            self.extSaveData = PluginData()

    def setExtendSaveVersion(self, ver):
        if self.isDetected and self.extSaveData:
            self.extSaveData.version = ver

    def getExtendSaveVersion(self):
        if self.isDetected and self.extSaveData:
            return self.extSaveData.version

    def saveExtendSaveData(self, id):
        from ExtensibleSaveFormat import ExtendedSave
        if self.isDetected:
            ExtendedSave.SetSceneExtendedDataById(id, self.extSaveData)

    def loadExtendSaveData(self, id):
        from ExtensibleSaveFormat import ExtendedSave, PluginData
        if self.isDetected:
            self.extSaveData = ExtendedSave.GetSceneExtendedDataById(id)
            if not self.extSaveData:
                self.extSaveData = PluginData()
            return self.extSaveData
        else:
            return None

class AI_ExtensibleSaveFormat(ExtensibleSaveFormat): # the same ExtensibleSaveFormat
    pass

# ::::::::::: Common class for KK_API, HS2_API etc, :::::::::::
class ILLAPI(ExtPlugin):
    def __init__(self):
        if ExtPlugin.exists("KKAPI"):
            ExtPlugin.__init__(self, "KKAPI")
        elif ExtPlugin.exists("KKSAPI"):
            ExtPlugin.__init__(self, "KKSAPI")
        elif ExtPlugin.exists("HS2API"):
            ExtPlugin.__init__(self, "HS2API")
        elif ExtPlugin.exists("AIAPI"):
            ExtPlugin.__init__(self, "AIAPI")
        elif ExtPlugin.exists("PHAPI"):
            ExtPlugin.__init__(self, "PHAPI")
        else:
            self.isDetected = False

    def Utilities_Extensions(self):
        from KKAPI.Utilities import Extensions
        return Extensions

    def Studio_StudioAPI(self):
        from KKAPI.Studio import StudioAPI
        return StudioAPI

    def get_api_instance(self):
        from KKAPI import KoikatuAPI
        import UnityEngine
        return UnityEngine.Object.FindObjectOfType[KoikatuAPI]()

    def Utilities_OpenFileDialog(self, callbackFunc, open = True, initialDir = None, title = None, extFilter = "All files|*.*", defExt = "", openMulti = False):
        from UnityEngine import Application
        from KKAPI.Utilities import OpenFileDialog
        from System import Action, Array, String
        from os import path

        if open:
            if title == None: title = "Open file"
            flags = OpenFileDialog.OpenSaveFileDialgueFlags.OFN_FILEMUSTEXIST | OpenFileDialog.OpenSaveFileDialgueFlags.OFN_EXPLORER | OpenFileDialog.OpenSaveFileDialgueFlags.OFN_LONGNAMES
            if openMulti:
                flags |= OpenFileDialog.OpenSaveFileDialgueFlags.OFN_ALLOWMULTISELECT
        else:
            if title == None: title = "Save file"
            flags = OpenFileDialog.OpenSaveFileDialgueFlags.OFN_EXPLORER | OpenFileDialog.OpenSaveFileDialgueFlags.OFN_LONGNAMES
        if initialDir == None or not path.isdir(initialDir):
            initialDir = path.realpath(path.join(Application.dataPath, '..'))

        ca = Action[Array[String]](callbackFunc)
        OpenFileDialog.Show(ca, title, initialDir, extFilter, defExt, flags)

# ::::::::::: ExtensibleSaveFormat (KK Bep5, AI) :::::::::::
class HSExtSave(ExtPlugin):
    def __init__(self):
        ExtPlugin.__init__(self, "HSExtSave")

    def reg_all_scene(self, id, callback_load, callback_import, callback_save):
        from HSExtSave import HSExtSave
        HSExtSave.RegisterHandler(id, None, None, callback_load,callback_import,callback_save,None,None)

# ::::::::::: Timeline (KK Bep5) :::::::::::
class ExtTimeline(ExtPlugin):
    def __init__(self):
        ExtPlugin.__init__(self, "Timeline")
        self.timeline = None
        if self.isDetected:
            from Timeline import Timeline
            self.timeline = Timeline
            try:
                self.timeline_obj = GetPrivateStatic(self.timeline,"_self")
            except Exception as e:
                print("VNGE: Error getting Timeline internal obj")

    def Play(self):
        if self.GetIsPlaying():
            return  # do not call play() when is playing. timeline will pause if you call play() when playing
        try:
            self.timeline.Play()
        except:
            CallPrivate(self.timeline_obj, "Play", [])

    def Pause(self):
        try:
            self.timeline.Pause()
        except:
            CallPrivate(self.timeline_obj, "Pause", [])

    def Stop(self):
        try:
            self.timeline.Stop()
        except:
            CallPrivate(self.timeline_obj, "Stop", [])

    def GetDuration(self):
        try:
            return self.timeline.duration
        except:
            return GetPrivate(self.timeline_obj, "_duration")

    def GetIsPlaying(self):
        try:
            return self.timeline.isPlaying
        except:
            return GetPrivate(self.timeline_obj, "_isPlaying")

    def GetPlaybackTime(self):
        try:
            return self.timeline.playbackTime
        except:
            return GetPrivate(self.timeline_obj, "_playbackTime")

    def SeekPlaybackTime(self,time):
        from System import Single
        CallPrivate(self.timeline_obj, "SeekPlaybackTime", [Single(time)])

    def GetInterpolables(self):
        if self.isDetected:
            tree = GetPrivate(self.timeline_obj, "_interpolables")
            return tree
        else:
            return None

    def SceneContainsInterpolables(self):
        tree = GetPrivate(self.timeline_obj, "_interpolables")
        return len(tree) > 0
    
    def Cleanup(self):
        emptyXml = '<root duration="10" blockLength="10" divisions="10" timeScale="1"></root>'
        self.SetSysSettingsText(emptyXml)

    def ToggleUiVisible(self):
        try:
            CallPrivate(self.timeline_obj, "ToggleUiVisible", [])
        except:
            pass    # not supported for HSPE

    def GetSysSettingsText(self):
        clr.AddReference("System.Xml")

        from System.IO import StringWriter
        from System.Xml import XmlTextWriter, XmlDocument

        stringWriter = StringWriter()
        xmlTextWriter = XmlTextWriter(stringWriter)

        xmlTextWriter.WriteStartElement("root")
        try:
            CallPrivate(self.timeline_obj, "SceneWrite", ["dummy path", xmlTextWriter])
        except:
            traceback.print_exc()
        xmlTextWriter.WriteEndElement()

        settingData = stringWriter.ToString()
        
        # convert objectIndex to objectID
        try:
            # load contents of setting data
            xDoc = XmlDocument()
            xDoc.LoadXml(settingData)

            # get the sorted list of all objects in studio
            from Studio import Studio
            studio = Studio.Instance
            silist = sorted(list(studio.dicObjectCtrl.Keys))
            
            # find each setting and adjust
            xRoot = xDoc.FirstChild
            if xRoot.Name != "root":
                print("Timeline Error: unexpected root node, should be 'root'.")
                raise Exception()
            for iobj in xRoot.ChildNodes:
                if iobj.Name == "interpolable":
                    oidx = iobj.GetAttribute("objectIndex")
                    if oidx:
                        oidx = int(oidx)
                    else:
                        continue
                    oid = silist[oidx]
                    iobj.SetAttribute("objectID", str(oid))
                else:
                    print("Timeline Warning: unknown setting node '%s'"%iobj.Name)
            # export again
            stringWriter2 = StringWriter()
            xmlTextWriter2 = XmlTextWriter(stringWriter2)
            xDoc.WriteContentTo(xmlTextWriter2)
            settingData = stringWriter2.ToString()
        except:
            traceback.print_exc()
        
        return settingData

    def SetSysSettingsText(self, text):
        clr.AddReference("System.Xml")

        from System.Xml import XmlDocument

        try:
            xDoc = XmlDocument()
            xDoc.LoadXml(text)
            xRoot = xDoc.FirstChild

            if xRoot.Name != "root":
                print("Timeline Error: unexpected root node, should be 'root'.")
                raise Exception()
            
            # get the sorted list of all objects in studio
            from Studio import Studio
            studio = Studio.Instance
            silist = sorted(list(studio.dicObjectCtrl.Keys))

            # convert objectID to objectIndex
            for iobj in xRoot.ChildNodes:
                if iobj.Name == "interpolable":
                    oid = iobj.GetAttribute("objectID")
                    if oid:
                        oid = int(oid)
                    else:
                        continue
                    idx = silist.index(oid)
                    iobj.SetAttribute("objectIndex", str(idx))
                else:
                    print("Timeline Warning: unknown setting node '%s'"%iobj.Name)

            # set to timeline
            CallPrivate(self.timeline_obj, "SceneLoad", ["dummy path", xRoot])
        except:
            traceback.print_exc()

# ::::::::::: ABMX (AI,HS2) :::::::::::
class ABMX(ExtPlugin):
    def __init__(self):
        if ExtPlugin.exists("KKABMX"):
            ExtPlugin.__init__(self, "KKABMX")
            self.engine = "KK"
        elif ExtPlugin.exists("KKSABMX"):
            ExtPlugin.__init__(self, "KKSABMX")
            self.engine = "KKS"
        elif ExtPlugin.exists("AIABMX"):
            ExtPlugin.__init__(self, "AIABMX")
            self.engine = "AI"
        elif ExtPlugin.exists("HS2ABMX"):
            ExtPlugin.__init__(self, "HS2ABMX")
            self.engine = "HS2"
        elif ExtPlugin.exists("PHABMX"):
            ExtPlugin.__init__(self, "PHABMX")
            self.engine = "PH"
        else:
            self.isDetected = False
            self.engine = None

    def GetBoneController(self, char):
        if not self.isDetected:
            return None

        from Studio import OCIChar
        if isinstance(char, OCIChar):
            ociChar = char
        elif isinstance(char, HSNeoOCIChar):
            ociChar = char.objctrl
        else:
            return None
        
        from KKABMX.Core import BoneController
        bc = ociChar.charInfo.gameObject.GetComponent(BoneController)
        return bc

    def GetBoneData(self, char):
        bc = self.GetBoneController(char)
        if not bc:
            return {}
        coord = bc.CurrentCoordinate.Value
        
        bd = {}
        for m in bc.Modifiers:
            if m.IsEmpty():
                continue
            bm0 = m.GetModifier(coord)
            bd[m.BoneName] = (bm0.ScaleModifier, bm0.LengthModifier, bm0.PositionModifier, bm0.RotationModifier)
        return bd

    def SetBoneData(self, char, data):
        if not data or len(data) == 0:
            return 
        bc = self.GetBoneController(char)
        if not bc:
            return
        coord = bc.CurrentCoordinate.Value

        from vnactor import tuple3_2_vector3
        for boneName in data.keys():
            m = bc.GetModifier(boneName)
            if not m:
                try:
                    from KKABMX.Core import BoneModifier
                    m = BoneModifier(boneName)
                    bc.AddModifier(m)
                    if not m.BoneTransform:
                        raise Exception("Transform for the bone not found!")
                    print ("Bone modifier [%s] not existed, created a new one."%boneName)
                except Exception as e:
                    print ("Bone modifier [%s] not existed, and fail to create it: %s"%(boneName, str(e)))
                    continue
            bm0 = m.GetModifier(coord)
            bm0.ScaleModifier = tuple3_2_vector3(data[boneName][0])
            bm0.LengthModifier = data[boneName][1]
            bm0.PositionModifier = tuple3_2_vector3(data[boneName][2])
            bm0.RotationModifier = tuple3_2_vector3(data[boneName][3])

# ::::::::::: Unity VideoPlayer support for item :::::::::::
class VideoPlayerExt(ExtPlugin):
    def __init__(self, ociObj = None, linkedClip = None):
        ExtPlugin.__init__(self, "UnityEngine.VideoModule")
        self.BindObject(ociObj, linkedClip)

    def BindObject(self, ociObj, linkedClip):
        self.videoPlayer = self.GetVideoPlayerComponent(ociObj)
        self.linkedClip = linkedClip

    @property
    def hasVideoPlayer(self):
        return self.videoPlayer != None

    @property
    def videoPlayerPrepared(self):
        return self.hasVideoPlayer and self.videoPlayer.isPrepared

    @property
    def videoLength(self):
        if self.videoPlayerPrepared:
            if hasattr(self.videoPlayer, "length"):
                return self.videoPlayer.length
            else:
                return self.videoPlayer.frameCount / self.videoPlayer.frameRate
        else:
            return 0

    def GetVideoPlayerComponent(self, ociObj):
        if ociObj == None: return None
        try:
            from UnityEngine.Video import VideoPlayer
            if hasattr(ociObj, "objctrl"):
                ociObj = ociObj.objctrl
            vp = ociObj.objectItem.GetComponentInChildren[VideoPlayer]()
            return vp
        except:
            return None

    def GetVolume(self):
        if self.videoPlayer != None and self.videoPlayer.canSetDirectAudioVolume:
            return self.videoPlayer.GetDirectAudioVolume(0)
        else:
            return 0

    def SetVolume(self, volume):
        if self.videoPlayer != None and self.videoPlayer.canSetDirectAudioVolume:
            self.videoPlayer.SetDirectAudioVolume(0, volume)

    def PlayVideo(self):
        if self.videoPlayer != None and not self.videoPlayer.isPlaying:
            self.videoPlayer.Play()

    def PauseVideo(self):
        if self.videoPlayer != None and self.videoPlayer.isPlaying:
            self.videoPlayer.Pause()

    def SeekVideo(self, time):
        if self.videoPlayer != None and self.videoPlayer.canSetTime and 0 <= time < self.videoLength:
            self.videoPlayer.time = time

    def ExportVideoPlayerState(self):
        if self.hasVideoPlayer:
            state = {}
            state["playing"] = "1" if self.videoPlayer.isPlaying else "0"
            state["time"] = self.videoPlayer.time
            state["autosync"] = 1
            state["volume"] = self.GetVolume()
            return state
        else:
            return None

    def ImportVideoPlayerState(self, state):
        if self.videoPlayerPrepared and state != None:
            if self.linkedClip and "autosync" in state and state["autosync"]:
                # auto sync mode overwrite time and playing
                ctime = self.linkedClip.curTime
                if not self.videoPlayer.isPlaying and self.linkedClip.isPlaying:
                    # sync start
                    if 0 <= ctime < self.videoLength:
                        self.SeekVideo(ctime)
                        self.videoPlayer.Play()
                        print("sync play video")
                elif self.videoPlayer.isPlaying and not self.linkedClip.isPlaying:
                    # sync pause
                    self.videoPlayer.Pause()
                    self.SeekVideo(ctime)
                    print("sync pause video")
                elif not self.videoPlayer.isPlaying and not self.linkedClip.isPlaying:
                    # sync frame
                    self.SeekVideo(ctime)
                    #print("sync video time %s"%ctime)
                else:
                    # do nothing
                    pass
            else:
                # time (paused only)
                if "time" in state and self.videoPlayer.canSetTime and not self.videoPlayer.isPlaying and 0 <= state["time"] <= self.videoLength:
                    self.videoPlayer.time = state["time"]
                # playing
                if "playing" in state:
                    if state["playing"] == "1" and not self.videoPlayer.isPlaying:
                        self.videoPlayer.Play()
                    elif state["playing"] != "1" and self.videoPlayer.isPlaying:
                        self.videoPlayer.Pause()
            # volume
            if "volume" in state and 0 <= state["volume"] <= 1:
                self.SetVolume(state["volume"])

# ::::::::::: CharaEditor :::::::::::
class CharaEditor(ExtPlugin):
    APPEND_PLUGIN = {"ABMX", "Overlay"}

    def __init__(self):
        ExtPlugin.__init__(self, "HS2StudioCharaEditor")
        if self.isDetected:
            from StudioCharaEditor import CharaEditorMgr
            self.Manager = CharaEditorMgr.Instance

    def GetCharaEditorContorller(self, ociChar):
        if self.isDetected:
            ctrl = self.Manager.GetEditorController(ociChar)
            return ctrl
        else:
            return None

    def GetCharaEditorDataFull(self, ociChar):
        if self.isDetected:
            ctrl = self.Manager.GetEditorController(ociChar)
            fullData = ctrl.GetDataDictFull()
            return CharaEditor.toPythonData(fullData)
        else:
            return None

    def GetCharaEditorDataRawFiltered(self, ociChar, category, exclude):
        from System import Array, String
        if self.isDetected:
            ctrl = self.Manager.GetEditorController(ociChar)
            # filter
            tgtKeys = []
            for key in ctrl.myUpdateSequence:
                need = False
                # check category
                for cat in category:
                    if key.startswith(cat):
                        need = True
                        break
                if not need:
                    continue
                # check exclude
                for ext in exclude:
                    if ext in key:
                        need = False
                        break
                if not need:
                    continue
                # add to tgt
                tgtKeys.append(key)
            # filtered data
            if len(tgtKeys) == 0:
                return {}
            filtedData = ctrl.GetDataDictByKeys(Array[String](tgtKeys))
            return filtedData
        else:
            return None

    def GetCharaEditorDataConDisFiltered(self, ociChar, category, exclude):
        from System import Array, String
        if self.isDetected:
            ctrl = self.Manager.GetEditorController(ociChar)
            filtedData = self.GetCharaEditorDataRawFiltered(ociChar, category, exclude)
            continuousData = ctrl.GetContinuousDataSet(filtedData)
            continuousData = CharaEditor.toPythonData(continuousData)
            discreteData = ctrl.GetDiscreteDataSet(filtedData)
            discreteData = CharaEditor.toPythonData(discreteData)
            # convert id data in safe way
            sideloader = Sideloader()
            for key in discreteData.keys():
                discreteData[key] = sideloader.UniGetUARResolveData(discreteData[key])
            return continuousData, discreteData
        else:
            return None, None
        
    def GetCharaEditorDataConDis(self, ociChar):
        if self.isDetected:
            ctrl = self.Manager.GetEditorController(ociChar)
            fullData = ctrl.GetDataDictVanilla()
            continuousData = ctrl.GetContinuousDataSet(fullData)
            continuousData = CharaEditor.toPythonData(continuousData)
            discreteData = ctrl.GetDiscreteDataSet(fullData)
            discreteData = CharaEditor.toPythonData(discreteData)
            # convert id data in safe way
            sideloader = Sideloader()
            for key in discreteData.keys():
                discreteData[key] = sideloader.UniGetUARResolveData(discreteData[key])
            return continuousData, discreteData
        else:
            return None, None

    def GetCharaEditorDataABMX(self, ociChar):
        if self.isDetected:
            ctrl = self.Manager.GetEditorController(ociChar)
            abmxData = ctrl.GetDataDictABMX()
            return CharaEditor.toPythonData(abmxData)
        else:
            return None

    def SetCharaEditorDataRaw(self, ociChar, data, force=False):
        if self.isDetected:
            # set to CharaEditor
            ctrl = self.Manager.GetEditorController(ociChar)
            ctrl.SetDataDict(data, force)

    def SetCharaEditorData(self, ociChar, data, force=False):
        if self.isDetected:
            # copy and resolve UARResolveData data
            copyData = {}
            sideloader = Sideloader()
            for ckey in data.keys():
                if isinstance(data[ckey], list) and isinstance(data[ckey][0], str):
                    localId = sideloader.UniGetUARLocalSlotId(data[ckey])
                    #print "Found UARResolveData", data[ckey], "=>", localId
                    if localId != None:
                        copyData[ckey] = localId
                else:
                    copyData[ckey] = data[ckey]
            # set to CharaEditor
            ctrl = self.Manager.GetEditorController(ociChar)
            cData = CharaEditor.toCSharpData(copyData)
            ctrl.SetDataDict(cData, force)

    @staticmethod
    def toPythonData(orgData):
        from System.Collections.Generic import Dictionary
        from System import Single, Array, Convert
        from UnityEngine import Color, Texture2D
        if isinstance(orgData, Dictionary[str, object]):
            pData = dict(orgData)
            for key in pData.keys():
                pData[key] = CharaEditor.toPythonData(pData[key])
            return pData
        elif isinstance(orgData, Dictionary[int, Array[Single]]):
            pData = dict(orgData)
            for key in pData.keys():
                pData[key] = CharaEditor.toPythonData(pData[key])
            return pData
        elif isinstance(orgData, Single):
            return float(orgData)
        elif isinstance(orgData, Color):
            return (orgData.r, orgData.g, orgData.b, orgData.a)
        elif isinstance(orgData, Array):
            pData = list(orgData)
            for i in range(len(pData)):
                pData[i] = CharaEditor.toPythonData(pData[i])
            return pData
        elif isinstance(orgData, Texture2D):
            pData = ("Texture2D", orgData.width, orgData.height, int(orgData.format), 1 if orgData.mipmapCount > 1 else 0, Convert.ToBase64String(orgData.GetRawTextureData()))
            return pData
        else:
            return orgData

    @staticmethod
    def toCSharpData(orgData):
        from System.Collections.Generic import Dictionary
        from System import Single, Array, Convert
        from UnityEngine import Color, Texture2D, TextureFormat
        if isinstance(orgData, dict):
            key0 = None if len(orgData) == 0 else orgData.keys()[0]
            if key0 == None:
                cData = None
            elif isinstance(key0, str):
                cData = Dictionary[str, object]()
                for key in orgData.keys():
                    cData[key] = CharaEditor.toCSharpData(orgData[key])
            elif isinstance(key0, int):
                cData = Dictionary[int, Array[Single]]()
                for key in orgData.keys():
                    cData[key] = CharaEditor.toCSharpData(orgData[key])
            else:
                raise Exception("Unexpected CharaEditor Data")
            return cData
        elif isinstance(orgData, list):
            cData = []
            for subData in orgData:
                cData.append(CharaEditor.toCSharpData(subData))
            return Array[type(cData[0])](cData)
        elif isinstance(orgData, tuple) and len(orgData) == 4:
            return Color(orgData[0], orgData[1], orgData[2], orgData[3])
        elif isinstance(orgData, tuple) and len(orgData) == 6 and orgData[0] == "Texture2D":
            from vnactor import value_2_enum
            tex = Texture2D(orgData[1], orgData[2], value_2_enum(TextureFormat, orgData[3]), bool(orgData[4]))
            tex.LoadRawTextureData(Convert.FromBase64String(orgData[5]))
            tex.Apply()
            return tex
        elif isinstance(orgData, float):
            return Single(orgData)
        else:
            return orgData

# ::::::::::: BoobSetting :::::::::::
class BoobSettings(ExtPlugin):
    def __init__(self):
        ExtPlugin.__init__(self, "HS2_BoobSettings")

    def GetBoobContorller(self, ociChar):
        if self.isDetected:
            from HS2_BoobSettings import BoobController
            try :
                ctrl = ociChar.charInfo.GetComponent[BoobController]()
                return ctrl
            except:
                import traceback
                traceback.print_exc()
                return None
        else:
            return None

    def GetFloatData(self, ociChar):
        bc = self.GetBoobContorller(ociChar)
        if bc:
            pdata = {}
            for key in bc.floatData.Keys:
                pdata[key] = float(bc.floatData[key])
            return pdata
        else:
            return None

    def GetBoolData(self, ociChar):
        bc = self.GetBoobContorller(ociChar)
        if bc:
            pdata = {}
            for key in bc.boolData.Keys:
                pdata[key] = bc.boolData[key]
            return pdata
        else:
            return None

    def SetFloatData(self, ociChar, pData):
        from System import Single
        bc = self.GetBoobContorller(ociChar)
        if bc:
            for key in pData.keys():
                bc.floatData[key] = Single(pData[key])
            ociChar.charInfo.UpdateBustSoftness()
            ociChar.charInfo.ChangeBustInert(False)
            ociChar.charInfo.UpdateBustGravity()

    def SetBoolData(self, ociChar, pData):
        bc = self.GetBoobContorller(ociChar)
        if bc:
            for key in pData.keys():
                bc.boolData[key] = pData[key]
            ociChar.charInfo.UpdateBustSoftness()
            ociChar.charInfo.ChangeBustInert(False)
            ociChar.charInfo.UpdateBustGravity()

# ::::::::::: BepInEx :::::::::::
class PLBepInEx(ExtPlugin):
    def __init__(self):
        if ExtPlugin.exists("BepInEx"):
            ExtPlugin.__init__(self, "BepInEx")
        else:
            self.isDetected = False

    def create_log_source(self,name):
        from BepInEx.Logging import Logger, LogLevel
        return Logger.CreateLogSource(name)

    def list_loaded_plugins(self):
        from BepInEx import MetadataHelper, BaseUnityPlugin, BepInPlugin
        from BepInEx.Bootstrap import Chainloader
        output = []
        for plugin in Chainloader.Plugins:
            metadata = MetadataHelper.GetMetadata(plugin)
            output.append((metadata.Name, metadata.GUID, metadata.Version))
        return tuple(output)

    def search_plugin(self, tgtname):
        tgtname = tgtname.lower()
        found = []
        for name, guid, ver in self.list_loaded_plugins():
            if tgtname in name.lower() or tgtname in guid.lower():
                found.append((name, guid, ver))
                print("Plugin: %s, GUID: %s, Version: %s"%(name, guid, str(ver)))
        if len(found) == 0:
            print("No plugin found with keyword <%s>"%tgtname)
        return found

    def check_plugin(self, name=None, guid=None, version=None):
        from System import Version
        if name == None and guid == None:
            raise Exception("PLBepInEx.check_plugin need name or guid or both of them to check!")
        if version != None:
            ver = Version(version)
        else:
            ver = None
        pluginInfos = self.list_loaded_plugins()
        for (pname, pguid, pversion) in pluginInfos:
            if name != None and pname != name:
                continue
            if guid != None and pguid != guid:
                continue
            if ver != None and pversion < ver:
                continue
            return True
        return False
    
    def get_pluginInfo_by_guid(self, tgtGuid):
        from BepInEx.Bootstrap import Chainloader
        if tgtGuid in Chainloader.PluginInfos:
            return Chainloader.PluginInfos[tgtGuid]
        else:
            return None

# ::::::::::: Sideloader :::::::::::
class Sideloader(ExtPlugin):
    UnknownLocalSlotId = set()

    def __init__(self):
        if ExtPlugin.exists("Sideloader"):
            ExtPlugin.__init__(self, "Sideloader")
            self.engine = "KK"
        elif ExtPlugin.exists("KKS_Sideloader"):
            ExtPlugin.__init__(self, "KKS_Sideloader")
            self.engine = "KKS"
        elif ExtPlugin.exists("AI_Sideloader"):
            ExtPlugin.__init__(self, "AI_Sideloader")
            self.engine = "AI"
        elif ExtPlugin.exists("HS2_Sideloader"):
            ExtPlugin.__init__(self, "HS2_Sideloader")
            self.engine = "HS2"
        else:
            self.isDetected = False
            self.engine = None

    def isSideloaderId(self, localSlotId):
        if isinstance(localSlotId, int) and self.isDetected and localSlotId not in Sideloader.UnknownLocalSlotId:
            from Sideloader.AutoResolver import UniversalAutoResolver
            return localSlotId >= UniversalAutoResolver.BaseSlotID
        else:
            return False

    def UniGetUARResolveData(self, localSlotId):
        if self.isSideloaderId(localSlotId):
            from Sideloader.AutoResolver import UniversalAutoResolver
            for ri in UniversalAutoResolver.LoadedStudioResolutionInfo:
                if ri.LocalSlot == localSlotId:
                    # version 1.0: version of resolve algorithm, GUID, Slot, Category
                    #return ["1.0", ri.GUID, ri.Slot, ri.Category]
                    # version 2.0: version of resolve algorithm, GUID, Group, Category, Slot
                    return ["2.0", ri.GUID, ri.Group, ri.Category, ri.Slot]
            for ri in UniversalAutoResolver.LoadedResolutionInfo:
                if ri.LocalSlot == localSlotId:
                    # version 1.0: version of resolve algorithm, GUID, Slot, Category
                    return ["1.0", ri.GUID, ri.Slot, int(ri.CategoryNo)]
            print("VNGE Sideloader, error find localSlotId=" + str(localSlotId))
            Sideloader.UnknownLocalSlotId.add(localSlotId)
            return localSlotId
        else:
            return localSlotId

    def UniGetUARLocalSlotId(self, resolveData):
        if self.isDetected:
            if isinstance(resolveData, (int, long)):  # type: ignore[name-defined]
                # no data
                return resolveData

            # if resolveData[0] == "0.9": # resolve for 0.9 version of algo - if Slot and GUID enough
            #     from Sideloader.AutoResolver import UniversalAutoResolver
            #     for ri in UniversalAutoResolver.LoadedStudioResolutionInfo:
            #         if ri.GUID == resolveData[1] and ri.Slot == resolveData[2]:
            #             return ri.LocalSlot

            if resolveData[0] == "1.0": # resolve for 1.0 version of algo
                from Sideloader.AutoResolver import UniversalAutoResolver
                for ri in UniversalAutoResolver.LoadedStudioResolutionInfo:
                    if ri.GUID == resolveData[1] and ri.Slot == resolveData[2] and ri.Category == resolveData[3]:
                        return ri.LocalSlot
                for ri in UniversalAutoResolver.LoadedResolutionInfo:
                    if ri.GUID == resolveData[1] and ri.Slot == resolveData[2] and int(ri.CategoryNo) == resolveData[3]:
                        return ri.LocalSlot
            if resolveData[0] == "2.0":
                from Sideloader.AutoResolver import UniversalAutoResolver
                for ri in UniversalAutoResolver.LoadedStudioResolutionInfo:
                    if ri.GUID == resolveData[1] and ri.Group == resolveData[2] and ri.Category == resolveData[3] and ri.Slot == resolveData[4]:
                        return ri.LocalSlot
                for ri in UniversalAutoResolver.LoadedResolutionInfo:
                    if ri.GUID == resolveData[1] and ri.Group == resolveData[2] and int(ri.CategoryNo) == resolveData[3] and ri.Slot == resolveData[4]:
                        return ri.LocalSlot                
        else:
            return resolveData

# ::::::::::: Overlay :::::::::::
class Overlay(ExtPlugin):
    def __init__(self, actor = None):
        if ExtPlugin.exists("HS2_OverlayMods"):
            ExtPlugin.__init__(self, "HS2_OverlayMods")
            self.engine = "HS2"
        elif ExtPlugin.exists("KK_OverlayMods"):
            ExtPlugin.__init__(self, "KK_OverlayMods")
            self.engine = "KK"
        elif ExtPlugin.exists("KKS_OverlayMods"):
            ExtPlugin.__init__(self, "KKS_OverlayMods")
            self.engine = "KK"
        else:
            self.isDetected = False
            self.engine = None
        self.BindActor(actor)

    def BindActor(self, actor):
        # actor can be a Actor, OCIChar or ChaControl
        self.targetChaCtrl = None
        self.skinOverlayCtrl = None
        self.clothOverlayCtrl = None
        self.MainClothesNames = None
        if actor == None:
            return
        if self.engine in {"HS2", "AI"}:
            from AIChara import ChaControl
        elif self.engine in {"KKS", "KK"}:
            import ChaControl
        else:
            return
        from vnactor import Actor
        from KoiSkinOverlayX import KoiSkinOverlayController
        from KoiClothesOverlayX import KoiClothesOverlayController, KoiClothesOverlayMgr
        if isinstance(actor, ChaControl):
            self.targetChaCtrl = actor
        elif isinstance(actor, Actor):
            self.targetChaCtrl = actor.objctrl.charInfo
        else:
            self.targetChaCtrl = actor.charInfo
        self.skinOverlayCtrl = self.targetChaCtrl.gameObject.GetComponentInChildren[KoiSkinOverlayController]()
        self.clothOverlayCtrl = self.targetChaCtrl.gameObject.GetComponentInChildren[KoiClothesOverlayController]()
        self.MainClothesNames = KoiClothesOverlayMgr.MainClothesNames

    def GetSkinTexType(self, name):
        from KoiSkinOverlayX import TexType
        if name == "BodyOver":
            return TexType.BodyOver
        elif name == "FaceOver":
            return TexType.FaceOver
        elif name == "BodyUnder":
            return TexType.BodyUnder
        elif name == "FaceUnder":
            return TexType.FaceUnder
        elif name == "EyeUnder":
            return TexType.EyeUnder
        elif name == "EyeOver":
            return TexType.EyeOver
        elif name == "EyeUnderL":
            return TexType.EyeUnderL
        elif name == "EyeOverL":
            return TexType.EyeOverL
        elif name == "EyeUnderR":
            return TexType.EyeUnderR
        elif name == "EyeOverR":
            return TexType.EyeOverR
        elif name == "EyebrowUnder":
            return TexType.EyebrowUnder
        elif name == "EyelineUnder":
            return TexType.EyelineUnder
        else:
            raise Exception("Unknown skin TexType name <%s>"%name)

    def GetSkinTexture(self, texName):
        if self.skinOverlayCtrl == None:
            return None
        texType = self.GetSkinTexType(texName)
        return self.skinOverlayCtrl.OverlayStorage.GetTexture(texType)

    def GetClothesTexData(self, clothPartsIndex):
        if self.clothOverlayCtrl == None:
            return None
        curTexDict = GetPrivateProperty(self.clothOverlayCtrl, "CurrentOverlayTextures")
        clothName = self.MainClothesNames[clothPartsIndex]
        if clothName in curTexDict:
            return curTexDict[clothName]
        else:
            return None

    def refreshClothesTexture(self, clothPartsIndex):
        clothName = self.MainClothesNames[clothPartsIndex]
        self.clothOverlayCtrl.RefreshTexture(clothName)

    def refreshClothesAllTextrue(self):
        self.clothOverlayCtrl.RefreshAllTextures()

    def DumpClothOrignalTexture(self, clothPartsIndex):
        from System import Action, Array, Byte
        from KoiSkinOverlayX import KoiSkinOverlayGui
        clothName = self.MainClothesNames[clothPartsIndex]
        def WriteAndOpenPng(pngData):
            KoiSkinOverlayGui.WriteAndOpenPng(pngData, clothName + "_Original")
        ca = Action[Array[Byte]](WriteAndOpenPng)
        self.clothOverlayCtrl.DumpBaseTexture(clothName, ca)

    def DumpClothOverlayTexture(self, clothPartsIndex):
        from KoiSkinOverlayX import KoiSkinOverlayGui
        from vngameengine import vnge_game
        clothName = self.MainClothesNames[clothPartsIndex]
        try:
            tex = self.clothOverlayCtrl.GetOverlayTex(clothName, False)
            if tex == None or tex.TextureBytes == None:
                vnge_game.logger_log_message("Nothing to export")
                return

            KoiSkinOverlayGui.WriteAndOpenPng(tex.TextureBytes, clothName)
        except Exception as e:
            vnge_game.logger_log_message("Failed to export texture - " + str(e))

    def DumpSkinOverlayTexture(self, texName):
        from KoiSkinOverlayX import KoiSkinOverlayGui
        from vngameengine import vnge_game
        try:
            tex = self.GetSkinTexture(texName)
            if tex == None:
                vnge_game.logger_log_message("Nothing to export")
                return
            #texCopy = tex.ToTexture2D()
            from UnityEngine import TextureFormat, ImageConversion, Texture2D
            pngBytes = ImageConversion.EncodeToPNG(tex)
            KoiSkinOverlayGui.WriteAndOpenPng(pngBytes, texName)
        except Exception as e:
            vnge_game.logger_log_message("Failed to export texture - " + str(e))

    def LoadNewOverlayTexture(self, partsIndex):
        # open file dialog to load
        from KoiSkinOverlayX import KoiSkinOverlayGui
        def callbackWrapper_api(files):
            if files and len(files):
                from vngameengine import vnge_game
                vnge_game.updFunc = Overlay._LoadNewOverlayTextureFileWrapper
                vnge_game.updFuncParam = (self, partsIndex, files[0])
        illApi = ILLAPI()
        illApi.Utilities_OpenFileDialog(
            callbackWrapper_api, 
            True, 
            KoiSkinOverlayGui.GetDefaultLoadDir(), 
            "Open overlay image", 
            KoiSkinOverlayGui.FileFilter, 
            KoiSkinOverlayGui.FileExt)

    @staticmethod
    def _LoadNewOverlayTextureFileWrapper(param):
        # wrapper
        param[0].LoadNewOverlayTextureFile(param[1], param[2])

    def LoadNewOverlayTextureFile(self, partsIndex, filename):
        # load from a file, must be called in update
        from vngameengine import vnge_game
        if not os.path.isfile(filename):
            vnge_game.logger_log_message("File <%s> not existed."%filename)
            return
        try:
            from System.IO import File
            from UnityEngine import TextureFormat, ImageConversion, Texture2D
            from KoiSkinOverlayX import Util
            pngBytes = File.ReadAllBytes(filename)
            if isinstance(partsIndex, str):
                # skin overlay
                self.SkinSetTexAndUpdate(partsIndex, pngBytes)
            elif isinstance(partsIndex, int):
                # cloth overlay
                textureFormat = TextureFormat.ARGB32
                tex = Util.TextureFromBytes(pngBytes, textureFormat)
                #tex = Texture2D(2, 2)
                #ImageConversion.LoadImage(tex, pngBytes)
                self.ClothSetTexAndUpdate(partsIndex, tex)
        except Exception as e:
            traceback.print_exc()
            vnge_game.logger_log_message("Load from file failed: %s."%str(e))

    def SkinSetTexAndUpdate(self, texName, texBytes):
        # note, texBytes is PNG bytes data, or None
        from vngameengine import vnge_game
        try:
            if self.skinOverlayCtrl:
                texType = self.GetSkinTexType(texName)
                self.skinOverlayCtrl.SetOverlayTex(texBytes, texType)
        except Exception as e:
            traceback.print_exc()
            vnge_game.logger_log_message("Import texture failed: " + str(e))

    def ClothSetTexAndUpdate(self, clothPartsIndex, tex):
        # note, tex is Texture2D object, or None
        from vngameengine import vnge_game
        try:
            # load a textrue2D data
            clothName = self.MainClothesNames[clothPartsIndex]
            if tex != None:
                origTex = tuple(self.clothOverlayCtrl.GetApplicableRenderers(clothName))[0].material.mainTexture
                isWrongRes = origTex != None and (tex.width != origTex.width or tex.height != origTex.height)
                if isWrongRes:
                    vnge_game.logger_log_message("WARNING - Wrong texture resolution! It's recommended to use %dx%d instead."%(origTex.width, origTex.height))
                else:
                    vnge_game.logger_log_message("Texture imported successfully")
            t = self.clothOverlayCtrl.GetOverlayTex(clothName, True)
            t.Texture = tex
            self.clothOverlayCtrl.RefreshTexture(clothName)
        except Exception as e:
            traceback.print_exc()
            vnge_game.logger_log_message("Import texture failed: " + str(e))

# ::::::::::: MoreAccessories :::::::::::
class MoreAccessories(ExtPlugin):
    def __init__(self):
        self.isDetected = False
        self.mgrInstance = None
        self.engine = None
        self.vanillaSlotCount = 0
        if ExtPlugin.exists("MoreAccessories"):
            ExtPlugin.__init__(self, "MoreAccessories")
            self.isDetected = True
            # get MoreAccessories instance
            try:
                engid = get_engine_id()
                if engid == "charastudio":
                    from MoreAccessoriesKOI import MoreAccessories
                    self.mgrInstance = GetPrivateStatic(MoreAccessories, "_self")
                    self.engine = "KK"
                    self.vanillaSlotCount = 20
                elif engid == "neov2":
                    from MoreAccessoriesAI import MoreAccessories
                    self.mgrInstance = GetPrivateStatic(MoreAccessories, "_self")
                    self.engine = "AI/HS2"
                    self.vanillaSlotCount = 20
                elif engid == "neo":
                    from MoreAccessories import MoreAccessories
                    self.mgrInstance = GetPrivateStatic(MoreAccessories, "_self")
                    self.engine = "HS"
                    self.vanillaSlotCount = 10
            except:
                print ("Fail to initialize MoreAccessories")

    def _toChaCtrl(self, ociChar):
        try:
            from vnactor import Actor
            from Studio import OCIChar
            if isinstance(ociChar, Actor):
                chaCtrl = ociChar.objctrl.charInfo
            elif isinstance(ociChar, OCIChar):
                chaCtrl = ociChar.charInfo
            else:
                chaCtrl = ociChar
            return chaCtrl
        except:
            raise Exception("Input must be a Actor, OCIChar, or ChaCtrl object")

    def getAdditionalAccessoriesData(self, ociChar):
        if not self.isDetected:
            return None
        chaFile = self._toChaCtrl(ociChar).chaFile
        # TODO: check different data type in KK/KKS and AI/HS2
        if self.engine == "KK" and self.mgrInstance:
            accessoriesByChar = GetPrivate(self.mgrInstance, "_accessoriesByChar")
            if chaFile in accessoriesByChar:
                return accessoriesByChar[chaFile]
        elif self.engine == "AI/HS2" and self.mgrInstance:
            additionalData = CallPrivate(self.mgrInstance, "GetAdditionalDataByCharacter", [chaFile])
            return additionalData
        elif self.engine == "HS" and self.mgrInstance:
            accessoriesByChar = GetPrivate(self.mgrInstance, "_accessoriesByChar")
            if chaFile in accessoriesByChar:
                return accessoriesByChar[chaFile]
        return None

    def getAccessoryCount(self, ociChar):
        if not self.isDetected:
            return self.vanillaSlotCount
        additionData = self.getAdditionalAccessoriesData(ociChar)
        if not additionData:
            return self.vanillaSlotCount
        if self.engine == "KK":
            return self.vanillaSlotCount + len(additionData.showAccessories)
        elif self.engine == "AI/HS2":
            return self.vanillaSlotCount + len(additionData.objects)
        elif self.engine == "HS":
            return self.vanillaSlotCount + len(additionData.showAccessory)

    def addAccessorySlot(self, ociChar, numToAdd = 1):
        raise Exception("I cannot create MoreAccessories.AdditionalData.AccessoryObject!! T.T")
        
        additionData = self.getAdditionalAccessoriesData(ociChar)
        if not additionData:
            return
        if self.engine == "AI/HS2":
            from AIChara import ChaFileAccessory
            pi = ChaFileAccessory.PartsInfo()
            pi.MemberInit()
            pi.type = 350
            additionData.parts.Add(pi)


    def getAccessoryCmp(self, ociChar, slotNo):
        if slotNo < self.vanillaSlotCount:
            return self._toChaCtrl(ociChar).cmpAccessory[slotNo]
        if self.isDetected:
            additionData = self.getAdditionalAccessoriesData(ociChar)
            if additionData:
                if self.engine == "KK":
                    pass
                elif self.engine == "AI/HS2" and slotNo - self.vanillaSlotCount < len(additionData.objects):
                    return additionData.objects[slotNo - self.vanillaSlotCount].cmp
        return None

    def getAccessoryInfo(self, ociChar, slotNo):
        if slotNo < self.vanillaSlotCount:
            return self._toChaCtrl(ociChar).infoAccessory[slotNo]
        if self.isDetected:
            additionData = self.getAdditionalAccessoriesData(ociChar)
            if additionData:
                if self.engine == "KK":
                    pass
                elif self.engine == "AI/HS2" and slotNo - self.vanillaSlotCount < len(additionData.objects):
                    return additionData.objects[slotNo - self.vanillaSlotCount].info
                elif self.engine == "HS":
                    return additionData.infoAccessory[slotNo - self.vanillaSlotCount]
        return None

    def getAccessoryPartsInfo(self, ociChar, slotNo):
        if slotNo < self.vanillaSlotCount:
            return self._toChaCtrl(ociChar).nowCoordinate.accessory.parts[slotNo]
        if self.isDetected:
            additionData = self.getAdditionalAccessoriesData(ociChar)
            if additionData:
                if self.engine == "KK":
                    pass
                elif self.engine == "AI/HS2" and slotNo - self.vanillaSlotCount < len(additionData.objects):
                    return additionData.parts[slotNo - self.vanillaSlotCount]
        return None

    def getAccessoryVisiable(self, ociChar, slotNo):
        if slotNo < self.vanillaSlotCount:
            if self.engine == "HS":
                self.objctrl.charFileInfoStatus.showAccessory[slotNo]
            else:
                return self._toChaCtrl(ociChar).fileStatus.showAccessory[slotNo]
        if self.isDetected:
            additionData = self.getAdditionalAccessoriesData(ociChar)
            if additionData:
                if self.engine == "KK":
                    pass
                elif self.engine == "AI/HS2" and slotNo - self.vanillaSlotCount < len(additionData.objects):
                    return additionData.objects[slotNo - self.vanillaSlotCount].show
        return None

    def setAccessoryVisiable(self, ociChar, slotNo, visiable):
        if slotNo < self.vanillaSlotCount:
            self._toChaCtrl(ociChar).fileStatus.showAccessory[slotNo] = visiable
        elif self.isDetected:
            additionData = self.getAdditionalAccessoriesData(ociChar)
            if additionData:
                if self.engine == "KK":
                    pass
                elif self.engine == "AI/HS2" and slotNo - self.vanillaSlotCount < len(additionData.objects):
                    additionData.objects[slotNo - self.vanillaSlotCount].show = visiable

    def getAdditionalAccessoriesVisiable(self, ociChar):
        if not self.isDetected:
            return None
        from vnactor import Actor
        if isinstance(ociChar, Actor):
            ociChar = ociChar.objctrl
        if self.engine == "KK" and self.mgrInstance:
            chaFileControl = ociChar.charInfo.chaFile
            accessoriesByChar = GetPrivate(self.mgrInstance, "_accessoriesByChar")
            if chaFileControl in accessoriesByChar:
                charAdditionalData = accessoriesByChar[chaFileControl]
                return list(charAdditionalData.showAccessories)
        elif self.engine == "AI/HS2" and self.mgrInstance:
            chaFileControl = ociChar.charInfo.chaFile
            additionalData = CallPrivate(self.mgrInstance, "GetAdditionalDataByCharacter", [chaFileControl])
            aav = []
            for adObject in additionalData.objects:
                if adObject.obj:
                    aav.append(adObject.show)
                else:
                    aav.append(None)
            return aav
        elif self.engine == "HS" and self.mgrInstance:
            additionalData = self.getAdditionalAccessoriesData(ociChar)
            if additionalData:
                return list(additionalData.showAccessory)
        return None

    def setAdditionalAccessoriesVisiable(self, ociChar, visibleSet):
        if not self.isDetected:
            return
        from vnactor import Actor
        if isinstance(ociChar, Actor):
            ociChar = ociChar.objctrl
        if self.engine == "KK" and self.mgrInstance:
            chaFileControl = ociChar.charInfo.chaFile
            accessoriesByChar = GetPrivate(self.mgrInstance, "_accessoriesByChar")
            if chaFileControl in accessoriesByChar:
                charAdditionalData = accessoriesByChar[chaFileControl]
                for i in range(min(len(charAdditionalData.showAccessories), len(visibleSet))):
                    charAdditionalData.showAccessories[i] = bool(visibleSet[i])
        elif self.engine == "AI/HS2" and self.mgrInstance:
            chaFileControl = ociChar.charInfo.chaFile
            additionalData = CallPrivate(self.mgrInstance, "GetAdditionalDataByCharacter", [chaFileControl])
            for i in range(len(additionalData.objects)):
                adObject = additionalData.objects[i]
                if adObject.obj and i < len(visibleSet):
                    adObject.show = bool(visibleSet[i])
        elif self.engine == "HS" and self.mgrInstance:
            additionalData = self.getAdditionalAccessoriesData(ociChar)
            if additionalData:
                for i in range(min(len(additionalData.showAccessory), len(visibleSet))):
                    additionalData.showAccessory[i] = bool(visibleSet[i])

# ::::::::::: AdditionalSkinEffects :::::::::::
class AdditionalSkinEffects(ExtPlugin):
    def __init__(self):
        self.isDetected = False
        self.engine = None
        if ExtPlugin.exists("KK_SkinEffects"):
            ExtPlugin.__init__(self, "KK_SkinEffects")
            self.isDetected = True
            self.engine = "KK"
        elif ExtPlugin.exists("KKS_SkinEffects"):
            ExtPlugin.__init__(self, "KKS_SkinEffects")
            self.isDetected = True
            self.engine = "KKS"

    def SkinEffectController(self, ociChar):
        if not self.isDetected:
            return None
        from KK_SkinEffects import SkinEffectsController
        try:
            return ociChar.charInfo.gameObject.GetComponentInChildren[SkinEffectsController]()
        except:
            traceback.print_exc()
            return None
    
    def GetAdditionalSkinEffects(self, ociChar):
        if not self.isDetected:
            return None
        ctrl = self.SkinEffectController(ociChar)
        if ctrl:
            #return (ctrl.ButtLevel, ctrl.SweatLevel, ctrl.TearLevel, ctrl.DroolLevel, ctrl.BukkakeLevel, ctrl.BloodLevel)
            # version 2, return a dict
            levels = [k for k in dir(ctrl) if k[0] != "_" and k.endswith("Level") and isinstance(getattr(ctrl, k), int)]
            aseData = {}
            for k in levels:
                aseData[k] = getattr(ctrl, k)
            return aseData
        else:
            return None

    def SetAdditionalSkinEffects(self, ociChar, value):
        if not self.isDetected:
            return
        # data check
        if (isinstance(value, tuple) or isinstance(value, list)) and len(value) == 6:
            # old data, transfer to dict
            aseData = {}
            aseData["ButtLevel"] = value[0]
            aseData["SweatLevel"] = value[1]
            aseData["TearLevel"] = value[2]
            aseData["DroolLevel"] = value[3]
            aseData["BukkakeLevel"] = value[4]
            aseData["BloodLevel"] = value[5]
        elif isinstance(value, dict):
            # new data
            aseData = value
        else:
            # unknown data
            return
        # load data
        ctrl = self.SkinEffectController(ociChar)
        if ctrl:
            for k in aseData.keys():
                try:
                    if hasattr(ctrl, k):
                        setattr(ctrl, k, aseData[k])
                except:
                    print("[Extplugins/AdditionalSkinEffects] Fail to restore skin effect: " + k)

# ::::::::::: ExpressionControl :::::::::::
class ExpressionControl(ExtPlugin):
    def __init__(self):
        self.isDetected = False
        self.engine = None
        if ExtPlugin.exists("KK_ExpressionControl"):
            ExtPlugin.__init__(self, "KK_ExpressionControl")
            self.isDetected = True
            self.engine = "KK"
        elif ExtPlugin.exists("KKS_ExpressionControl"):
            ExtPlugin.__init__(self, "KKS_ExpressionControl")
            self.isDetected = True
            self.engine = "KKS"

    def GetExpressionController(self):
        if not self.isDetected:
            return None
        from ExpressionControl import ExpressionControlPlugin
        try:
            return GetPrivateStatic(ExpressionControlPlugin, "inst")
        except:
            traceback.print_exc()
            return None
        
    def GetFemaleData(self, ociChar):
        ctrl = self.GetExpressionController()
        if not ctrl:
            return None
        ctrl.UpdateFemale()
        femaleList = GetPrivate(ctrl, "femaleList")
        for fd in femaleList:
            if fd.ociFemale == ociChar:
                return fd
            if fd.female == ociChar.charInfo:
                return fd
        return None
    
    def GetExpressionData(self, ociChar):
        eData = self.GetFemaleData(ociChar)
        if eData:
            ex = eData.expression
            ed = {}
            ed["guid"] = ex.guid
            ed["name"] = ex.name
            ed["eyebrowPtn"] = str(ex.eyebrowPtn)
            ed["eyesPtn"] = str(ex.eyesPtn)
            ed["mouthPtn"] = str(ex.mouthPtn)
            ed["hideHighlight"] = str(ex.hideHighlight)
            ed["blink"] = str(ex.blink)
            ed["eyeOpen"] = ex.eyeOpen
            ed["mouthOpen"] = ex.mouthOpen
            ed["hohoAka"] = ex.hohoAka
            ed["tearLv"] = str(ex.tearLv)
            ed["eyeY"] = ex.eyeY
            ed["eyeSmall"] = ex.eyeSmall
            return ed
        else:
            return None
            
    def SetExpressionData(self, ociChar, data):
        from System import Byte
        eData = self.GetFemaleData(ociChar)
        if eData:
            from ExpressionControl import ExpressionControl
            ex = ExpressionControl.Expression()
            for key, value in data.items():
                if hasattr(ex, key):
                    if isinstance(getattr(ex, key), bool):
                        # bool
                        setattr(ex, key, eval(value))
                    elif isinstance(getattr(ex, key), int):
                        # int
                        setattr(ex, key, int(value))
                    elif isinstance(getattr(ex, key), Byte):
                        # byte
                        setattr(ex, key, Byte(value))
                    else:
                        # float(Single) or str
                        setattr(ex, key, value)
            eData.SetExpression(ex)

# ::::::::::: AdvIKPlugin :::::::::::
class AdvIKPlugin(ExtPlugin):
    IKSOLVER_SETTING = (
        "ShoulderRotationEnabled", 
        "IndependentShoulders",
        "ReverseShoulderL",
        "ReverseShoulderR",
        "ShoulderWeight",
        "ShoulderOffset",
        "ShoulderRightWeight",
        "ShoulderRightOffset",
        "SpineStiffness",
        "EnableSpineFKHints",
        "EnableShoulderFKHints",
        "EnableToeFKHints",
        "EnableHeelzHoverAll",
        "EnableHeelzHoverLeftFoot",
        "EnableHeelzHoverRightFoot",
    )

    BREATHING_SETTING = (
        "Enabled",
        "MagnitudeFactor",
        "IntakePause",
        "HoldPause",
        "InhalePercentage",
        "BreathsPerMinute",
        "ShoulderDampeningFactor",
        "BreathMagnitude",
        "UpperChestRelativeScaling",
        "LowerChestRelativeScaling",
        "AbdomenRelativeScaling",
        "NeckMotionDampeningFactor",
    )

    def __init__(self):
        if ExtPlugin.exists("KK_AdvIKPlugin"):
            ExtPlugin.__init__(self, "KK_AdvIKPlugin")
            self.engine = "KK"
        elif ExtPlugin.exists("KKS_AdvIKPlugin"):
            ExtPlugin.__init__(self, "KKS_AdvIKPlugin")
            self.engine = "KKS"
        elif ExtPlugin.exists("AI_AdvIKPlugin"):
            ExtPlugin.__init__(self, "AI_AdvIKPlugin")
            self.engine = "AI"
        elif ExtPlugin.exists("HS2_AdvIKPlugin"):
            ExtPlugin.__init__(self, "HS2_AdvIKPlugin")
            self.engine = "HS2"
        else:
            self.isDetected = False
            self.engine = None

    def AdvIKSolverController(self, ociChar):
        if not self.isDetected:
            return None
        from AdvIKPlugin import AdvIKCharaController
        try:
            return ociChar.charInfo.gameObject.GetComponentInChildren[AdvIKCharaController]()
        except:
            traceback.print_exc()
            return None
        
    def BreathingController(self, ociChar):
        aisCtrl = self.AdvIKSolverController(ociChar)
        if aisCtrl:
            try:
                return aisCtrl.BreathingController
            except:
                traceback.print_exc()
                return None
        else:
            return None
        
    def GetAdvIKSolverSetting(self, ociChar):
        ctrl = self.AdvIKSolverController(ociChar)
        if ctrl:
            iksData = {}
            for attr in AdvIKPlugin.IKSOLVER_SETTING:
                if hasattr(ctrl, attr):
                    iksData[attr] = getattr(ctrl, attr)
            return iksData
        else:
            return None

    def SetAdvIKSolverSetting(self, ociChar, value):
        ctrl = self.AdvIKSolverController(ociChar)
        if ctrl:
            for k in value.keys():
                try:
                    if hasattr(ctrl, k):
                        setattr(ctrl, k, value[k])
                except:
                    print("[Extplugins/AdvIKPlugin] Fail to restore IK Solver setting: " + k)

    def GetBreathingSetting(self, ociChar):
        from UnityEngine import Vector3
        def expandVector3(v):
            if isinstance(v, Vector3):
                return (v.x, v.y, v.z)
            else:
                return v

        ctrl = self.BreathingController(ociChar)
        if ctrl:
            bsData = {}
            for attr in AdvIKPlugin.BREATHING_SETTING:
                if hasattr(ctrl, attr):
                    bsData[attr] = expandVector3(getattr(ctrl, attr))
            return bsData
        else:
            return None

    def SetBreathingSetting(self, ociChar, value):
        from UnityEngine import Vector3
        def packVector3(v):
            if isinstance(v, tuple) and len(v) == 3:
                return Vector3(v[0], v[1], v[2])
            else:
                return v

        ctrl = self.BreathingController(ociChar)
        if ctrl:
            for k in value.keys():
                try:
                    if hasattr(ctrl, k):
                        setattr(ctrl, k, packVector3(value[k]))
                except:
                    print("[Extplugins/AdvIKPlugin] Fail to restore breathing setting: " + k)

# ::::::::::: Material Editor :::::::::::
class MaterialEditor(ExtPlugin):
    VALID_DATA_NAME = (
        "RendererProperty", 
        "ProjectorProperty", 
        "MaterialShader", 
        "MaterialTextureProperty",
        "MaterialColorProperty", 
        "MaterialFloatProperty", 
        "MaterialKeywordProperty", 
        #"MaterialNameProperty", 
        #"MaterialCopy",
    )
    CHAR_DATA_IDENTIFIER_LENGTH = {
        "RendererProperty": 5,
        "ProjectorProperty": 5,
        "MaterialShader": 4,
        "MaterialTextureProperty": 5,
        "MaterialColorProperty": 5,
        "MaterialFloatProperty": 5,
        "MaterialKeywordProperty": 5,
        #"MaterialNameProperty": 5,
        #"MaterialCopy": 4,
    }
    ITEM_DATA_IDENTIFIER_LENGTH = {
        "RendererProperty": 4,
        "ProjectorProperty": 4,
        "MaterialShader": 3,
        "MaterialTextureProperty": 4,
        "MaterialColorProperty": 4,
        "MaterialFloatProperty": 4,
        "MaterialKeywordProperty": 4,
        #"MaterialNameProperty": 4,
        #"MaterialCopy": 3,
    }

    def __init__(self):
        if ExtPlugin.exists("KK_MaterialEditor"):
            ExtPlugin.__init__(self, "KK_MaterialEditor")
            self.engine = "KK"
        elif ExtPlugin.exists("KKS_MaterialEditor"):
            ExtPlugin.__init__(self, "KKS_MaterialEditor")
            self.engine = "KKS"
        elif ExtPlugin.exists("AI_MaterialEditor"):
            ExtPlugin.__init__(self, "AI_MaterialEditor")
            self.engine = "AI"
        elif ExtPlugin.exists("HS2_MaterialEditor"):
            ExtPlugin.__init__(self, "HS2_MaterialEditor")
            self.engine = "HS2"
        elif ExtPlugin.exists("PH_MaterialEditor"):
            ExtPlugin.__init__(self, "PH_MaterialEditor")
            self.engine = "PH"
        else:
            self.isDetected = False
            self.engine = None

    def GetGameObjectRenderers(self, gameObject):
        from MaterialEditorAPI import MaterialAPI
        try:
            renderList = MaterialAPI.GetRendererList(gameObject)
            return list(renderList)
        except:
            return None

    def GetGameObjectRendererByName(self, gameObject, rdrName):
        renderers = self.GetGameObjectRenderers(gameObject)
        if renderers:
            for rd in renderers:
                if MaterialEditor.FormatName(rd.name) == rdrName:
                    return rd
        return None
    
    def GetGameObjectMaterials(self, gameObject):
        from MaterialEditorAPI import MaterialAPI
        try:
            renders = self.GetGameObjectRenderers(gameObject)
            materials = []
            for rd in renders:
                mats = MaterialAPI.GetMaterials(gameObject, rd)
                materials.extend(list(mats))
            return materials
        except:
            return None
        
    def GetGameObjectMaterialByName(self, gameObject, matName):
        materials = self.GetGameObjectMaterials(gameObject)
        if materials:
            for mat in materials:
                if MaterialEditor.FormatName(mat.name) == matName:
                    return mat
                
        # try search in projector
        from MaterialEditorAPI import MaterialAPI
        projectors = MaterialAPI.GetProjectorList(gameObject, False)
        for projector in projectors:
            if projector.name == matName:
                return projector.material

        return None
    
    def GetGameObjectProjectorByName(self, gameObject, projName):
        from MaterialEditorAPI import MaterialAPI
        projectors = MaterialAPI.GetProjectorList(gameObject, False)
        for projector in projectors:
            if MaterialEditor.FormatName(projector.name) == projName:
                return projector
        return None
        
    def GetMaterialEditorController(self, ociChar):
        if not self.isDetected:
            return None
        from KK_Plugins.MaterialEditor import MaterialEditorCharaController, MEStudio
        try:
            if ociChar != None:
                if hasattr(ociChar, "objctrl"):
                    ociChar = ociChar.objctrl
                return ociChar.charInfo.gameObject.GetComponentInChildren[MaterialEditorCharaController]()
            else:
                return MEStudio.GetSceneController()
        except:
            traceback.print_exc()
            return None
        
    def GetMaterialEditorData(self, targetObj):
        def getDataSerializer(name):
            listName = name + "List"
            serializerName = "Serialize" + name
            if hasattr(MaterialEditor, serializerName):
                return listName, getattr(MaterialEditor, serializerName)
            else:
                return None, None

        meData = {}
        # check targetObj, set to oci
        if targetObj == None:
            raise Exception("targetObj is None")
        if hasattr(targetObj, "objctrl"):
            targetObj = targetObj.objctrl

        # deal by character or item
        from Studio import OCIChar, OCIItem
        if isinstance(targetObj, OCIChar):
            mec = self.GetMaterialEditorController(targetObj)
            if mec:
                for dataName in MaterialEditor.VALID_DATA_NAME:
                    listName, serializer = getDataSerializer(dataName)
                    if listName and serializer:
                        try:
                            dataList = GetPrivate(mec, listName)
                        except:
                            dataList = []
                        if len(dataList) > 0:
                            try:
                                meData[dataName] = list([serializer(d) for d in dataList])
                            except Exception as e:
                                print("[ExtPlugin/MaterialEditor] Failed to serialize %s: %s"%(dataName, str(e)))
                                continue
        elif isinstance(targetObj, OCIItem):
            mec = self.GetMaterialEditorController(None)
            if mec:
                for dataName in MaterialEditor.VALID_DATA_NAME:
                    listName, serializer = getDataSerializer(dataName)
                    if listName and serializer:
                        try:
                            dataList = GetPrivate(mec, listName)
                        except:
                            dataList = []
                        if len(dataList) > 0:
                            try:
                                dataOfObj = list([serializer(d) for d in dataList if d.ID == targetObj.objectInfo.dicKey])
                                if len(dataOfObj) > 0:
                                    meData[dataName] = dataOfObj
                            except Exception as e:
                                print("[ExtPlugin/MaterialEditor] Failed to serialize %s: %s"%(dataName, str(e)))
                                continue

        # done
        return meData
    
    def SetMaterialEditorData(self, targetObj, meData):
        def getSetter(name):
            listName = name + "List"
            setterName = "Set" + name
            if hasattr(self, setterName):
                return listName, getattr(self, setterName)
            else:
                return None, None
        def matchData(orgData, tgtData, dataName):
            if orgData[0] != "SceneItem":
                matchLen = MaterialEditor.CHAR_DATA_IDENTIFIER_LENGTH[dataName]
            else:
                matchLen = MaterialEditor.ITEM_DATA_IDENTIFIER_LENGTH[dataName]
            sameData = orgData[0:matchLen] == tgtData[0:matchLen]
            if sameData:
                sameValue = orgData[matchLen:] == tgtData[matchLen:]
            else:
                sameValue = False
            return sameData, sameValue
        def needSetAndDoRemoveData(dataDict, dataName, tgtData):
            if not dataName in dataDict:
                return True
            for i in range(len(dataDict[dataName])):
                sameData, sameValue = matchData(dataDict[dataName][i], tgtData, dataName)
                if sameData:
                    del dataDict[dataName][i]
                    return not sameValue
            return True
        
        # check targetObj, set to oci
        if targetObj == None:
            raise Exception("targetObj is None")
        if hasattr(targetObj, "objctrl"):
            targetObj = targetObj.objctrl

        # deal by character or item
        from Studio import OCIChar, OCIItem
        if isinstance(targetObj, OCIChar):
            mec = self.GetMaterialEditorController(targetObj)
            if mec:
                toResetData = self.GetMaterialEditorData(targetObj)
                # set data
                for dataName in MaterialEditor.VALID_DATA_NAME:
                    listName, setter = getSetter(dataName)
                    if listName and setter and dataName in meData:
                        try:
                            for data in meData[dataName]:
                                if needSetAndDoRemoveData(toResetData, dataName, data):
                                    setter(mec, data)
                        except Exception as e:
                            traceback.print_exc()
                            print("[ExtPlugin/MaterialEditor] Failed to set %s: %s\n  data: %s"%(dataName, str(e), str(data)))
                # reset data
                for dataName in reversed(MaterialEditor.VALID_DATA_NAME):
                    listName, setter = getSetter(dataName) 
                    if listName and setter and dataName in toResetData:
                        try:
                            for data in toResetData[dataName]:
                                setter(mec, data, True)
                        except Exception as e:
                            traceback.print_exc()
                            print("[ExtPlugin/MaterialEditor] Failed to reset %s: %s\n  data: %s"%(dataName, str(e), str(data)))
                            
        elif isinstance(targetObj, OCIItem):
            mec = self.GetMaterialEditorController(None)
            if mec:
                toResetData = self.GetMaterialEditorData(targetObj)
                # set data
                for dataName in MaterialEditor.VALID_DATA_NAME:
                    listName, setter = getSetter(dataName)
                    if listName and setter and dataName in meData:
                        try:
                            for data in meData[dataName]:
                                if needSetAndDoRemoveData(toResetData, dataName, data):
                                    setter(mec, data)
                        except Exception as e:
                            traceback.print_exc()
                            print("[ExtPlugin/MaterialEditor] Failed to set %s: %s\n  data: %s"%(dataName, str(e), str(data)))
                # reset data
                for dataName in reversed(MaterialEditor.VALID_DATA_NAME):
                    listName, setter = getSetter(dataName) 
                    if listName and setter and dataName in toResetData:
                        try:
                            for data in toResetData[dataName]:
                                setter(mec, data, True)
                        except Exception as e:
                            traceback.print_exc()
                            print("[ExtPlugin/MaterialEditor] Failed to reset %s: %s\n  data: %s"%(dataName, str(e), str(data)))

    def GetMaterialEditorTexture(self, targetObj):
        meTex = []
        # check targetObj, set to oci
        if targetObj == None:
            raise Exception("targetObj is None")
        if hasattr(targetObj, "objctrl"):
            targetObj = targetObj.objctrl

        # deal by character or item
        from Studio import OCIChar, OCIItem
        from vnactor import bytearray_to_str64
        if isinstance(targetObj, OCIChar):
            mec = self.GetMaterialEditorController(targetObj)
            if mec:
                try:
                    dataList = GetPrivate(mec, "MaterialTexturePropertyList")
                    TextureDictionary = GetPrivate(mec, "TextureDictionary")
                    for texProp in [td for td in dataList if td.TexID != None and TextureDictionary.ContainsKey(td.TexID)]:
                        texContainer = TextureDictionary[texProp.TexID]
                        texInfo = (
                            str(texProp.ObjectType),
                            texProp.CoordinateIndex,
                            texProp.Slot,
                            texProp.MaterialName, 
                            texProp.Property, 
                            bytearray_to_str64(texContainer.Data)
                        )
                        meTex.append(texInfo)

                except Exception as e:
                    print("[ExtPlugin/MaterialEditor] Failed to serialize texture: %s"%(str(e)))
                        
        elif isinstance(targetObj, OCIItem):
            from KK_Plugins.MaterialEditor import SceneController
            mec = self.GetMaterialEditorController(None)
            if mec:
                try:
                    dataList = GetPrivate(mec, "MaterialTexturePropertyList")
                    TextureDictionary = GetPrivateStatic(SceneController, "TextureDictionary")                    
                    for texProp in [td for td in dataList if td.ID == targetObj.objectInfo.dicKey and td.TexID != None and TextureDictionary.ContainsKey(td.TexID)]:
                        texContainer = TextureDictionary[texProp.TexID]
                        texInfo = (
                            texProp.ID,
                            texProp.MaterialName, 
                            texProp.Property, 
                            bytearray_to_str64(texContainer.Data)
                        )
                        meTex.append(texInfo)
                    
                except Exception as e:
                    print("[ExtPlugin/MaterialEditor] Failed to serialize texture: %s"%(str(e)))

        # done
        return meTex

    def SetMaterialEditorTexture(self, targetObj, meTex):
        # check targetObj, set to oci
        if targetObj == None:
            raise Exception("targetObj is None")
        if hasattr(targetObj, "objctrl"):
            targetObj = targetObj.objctrl

        # deal by character or item
        from Studio import OCIChar, OCIItem
        from vnactor import str64_to_bytearray
        if isinstance(targetObj, OCIChar):
            mec = self.GetMaterialEditorController(targetObj)
            if mec:
                try:
                    for texInfo in meTex:
                        objectType, _, slot, go, material = self.ExtCharacterMaterialInfo(mec, texInfo[0], texInfo[1], texInfo[2], texInfo[3])
                        if go and material:
                            propertyName = texInfo[4]
                            texData = str64_to_bytearray(texInfo[5])
                            mec.SetMaterialTexture(slot, objectType, material, propertyName, texData, go)
                except Exception as e:
                    traceback.print_exc()
                    print("[ExtPlugin/MaterialEditor] Failed to set texture: %s"%(str(e)))
        elif isinstance(targetObj, OCIItem):
            mec = self.GetMaterialEditorController(None)
            if mec:
                try:
                    for texInfo in meTex:
                        id, _, material = self.ExtItemMaterialInfo(texInfo[0], texInfo[1])
                        if material:
                            propertyName = texInfo[2]
                            texData = str64_to_bytearray(texInfo[3])
                            mec.SetMaterialTexture(id, material, propertyName, texData)
                except Exception as e:
                    traceback.print_exc()
                    print("[ExtPlugin/MaterialEditor] Failed to set texture: %s"%(str(e)))

    def ImportMaterialEditorData(self, targetObj, meData):
        def getDataDeserializer(name):
            listName = name + "List"
            deserializerName = "Deserialize" + name
            if hasattr(MaterialEditor, deserializerName):
                return listName, getattr(MaterialEditor, deserializerName)
            else:
                return None, None

        # check targetObj, set to oci
        if targetObj == None:
            raise Exception("targetObj is None")
        if hasattr(targetObj, "objctrl"):
            targetObj = targetObj.objctrl

        # deal by character or item
        from Studio import OCIChar, OCIItem
        if isinstance(targetObj, OCIChar):
            mec = self.GetMaterialEditorController(targetObj)
            if mec:
                for dataName in MaterialEditor.VALID_DATA_NAME:
                    listName, deserializer = getDataDeserializer(dataName)
                    if listName and deserializer and dataName in meData:
                        try:
                            dataList = GetPrivate(mec, listName)
                            dataList.Clear()
                            for me in meData[dataName]:
                                dataList.Add(deserializer(me))
                        except Exception as e:
                            print("[ExtPlugin/MaterialEditor] Failed to set list of %s: %s"%(dataName, str(e)))
                            continue
        elif isinstance(targetObj, OCIItem):
            mec = self.GetMaterialEditorController(None)
            if mec:
                for dataName in MaterialEditor.VALID_DATA_NAME:
                    listName, deserializer = getDataDeserializer(dataName)
                    if listName and deserializer and dataName in meData:
                        try:
                            dataList = GetPrivate(mec, listName)
                            dataList.Clear()    # TODO not clear, delete only the same id
                            for me in meData[dataName]:
                                dataList.Add(deserializer(me))
                        except Exception as e:
                            print("[ExtPlugin/MaterialEditor] Failed to set list of %s: %s"%(dataName, str(e)))
                            continue

    def ResetMaterialEditorData(self, targetObj, targetMaterial = None, targetProperty = None):
        # check targetObj, set to oci
        if targetObj == None:
            raise Exception("targetObj is None")
        if hasattr(targetObj, "objctrl"):
            targetObj = targetObj.objctrl

        # deal by character or item
        from Studio import OCIChar, OCIItem
        if isinstance(targetObj, OCIChar):
            mec = self.GetMaterialEditorController(targetObj)
            mIndex = 3
            pIndex = 4
        elif isinstance(targetObj, OCIItem):
            mec = self.GetMaterialEditorController(None)
            mIndex = 2
            pIndex = 3
        if mec == None:
            return

        # filter material editor data to reset
        meData = self.GetMaterialEditorData(targetObj)
        if targetMaterial != None:
            for dataName, dataSet in meData.items():
                toSkip = []
                for i in range(len(dataSet)):
                    if dataSet[i][mIndex] not in targetMaterial:
                        toSkip.append(i)
                for i in reversed(toSkip):
                    del dataSet[i]
        if targetProperty != None:
            for dataName, dataSet in meData.items():
                toSkip = []
                for i in range(len(dataSet)):
                    if dataSet[i][pIndex] not in targetProperty:
                        toSkip.append(i)
                for i in reversed(toSkip):
                    del dataSet[i]
        
        # print to reset data
        for dataName, dataSet in meData.items():
            if len(dataSet) > 0:
                setterName = "Set" + dataName
                if hasattr(self, setterName):
                    setter = getattr(self, setterName)
                else:
                    continue

                print("Reset %s Data:" % dataName)
                for data in dataSet:
                    print("  %s" % str(data))
                    setter(mec, data, True)

    # RendererProperty
    @staticmethod
    def SerializeRendererProperty(obj):
        if hasattr(obj, "ObjectType"):
            return (
                str(obj.ObjectType),
                str(obj.CoordinateIndex), 
                str(obj.Slot), 
                obj.RendererName, 
                str(obj.Property), 
                obj.Value, 
                obj.ValueOriginal
            )
        else:
            return (
                "SceneItem",
                str(obj.ID),
                obj.RendererName, 
                str(obj.Property), 
                obj.Value, 
                obj.ValueOriginal
            )
    
    @staticmethod
    def DeserializeRendererProperty(data):
        from vnactor import str_2_enum
        from MaterialEditorAPI import MaterialAPI
        if data[0] != "SceneItem":
            from KK_Plugins.MaterialEditor import MaterialEditorCharaController
            obj = MaterialEditorCharaController.RendererProperty(
                str_2_enum(MaterialEditorCharaController.ObjectType, data[0]),
                int(data[1]),
                int(data[2]),
                data[3],
                str_2_enum(MaterialAPI.RendererProperties, data[4]),
                str(data[5]),
                str(data[6])
            )
            return obj
        else:
            from KK_Plugins.MaterialEditor import SceneController
            obj = SceneController.RendererProperty(
                int(data[1]),
                data[2],
                str_2_enum(MaterialAPI.RendererProperties, data[3]),
                str(data[4]),
                str(data[5])
            )
            return obj

    def SetRendererProperty(self, meCtrl, data, reset = False):
        from MaterialEditorAPI import MaterialAPI
        from vnactor import str_2_enum
        if data[0] != "SceneItem":
            objectType, _, slot, go, renderer = self.ExtCharacterMaterialInfo(meCtrl, data[0], data[1], data[2], data[3], "renderer")
            if go and renderer:
                propertyName = data[4]
                property = str_2_enum(MaterialAPI.RendererProperties, propertyName)
                value = data[5] if not reset else data[6]
                meCtrl.SetRendererProperty(slot, objectType, renderer, property, value, go)
        else:
            id, _, renderer = self.ExtItemMaterialInfo(data[1], data[2], "renderer")
            if renderer:
                propertyName = data[3]
                property = str_2_enum(MaterialAPI.RendererProperties, propertyName)
                value = data[4] if not reset else data[5]
                meCtrl.SetRendererProperty(id, renderer, property, value)

    # ProjectorProperty
    @staticmethod
    def SerializeProjectorProperty(obj):
        if hasattr(obj, "ObjectType"):
            return (
                str(obj.ObjectType),
                str(obj.CoordinateIndex), 
                str(obj.Slot), 
                obj.ProjectorName, 
                str(obj.Property), 
                obj.Value, 
                obj.ValueOriginal
            )
        else:
            return (
                "SceneItem",
                str(obj.ID),
                obj.ProjectorName, 
                str(obj.Property), 
                obj.Value, 
                obj.ValueOriginal
            )
        
    @staticmethod
    def DeserializeProjectorProperty(data):
        from vnactor import str_2_enum
        from MaterialEditorAPI import MaterialAPI
        if data[0] != "SceneItem":
            from KK_Plugins.MaterialEditor import MaterialEditorCharaController
            obj = MaterialEditorCharaController.ProjectorProperty(
                str_2_enum(MaterialEditorCharaController.ObjectType, data[0]),
                int(data[1]),
                int(data[2]),
                data[3],
                str_2_enum(MaterialAPI.ProjectorProperties, data[4]),
                str(data[5]),
                str(data[6])
            )
            return obj
        else:
            from KK_Plugins.MaterialEditor import SceneController
            obj = SceneController.ProjectorProperty(
                int(data[1]),
                data[2],
                str_2_enum(MaterialAPI.ProjectorProperties, data[3]),
                str(data[4]),
                str(data[5])
            )
            return obj

    def SetProjectorProperty(self, meCtrl, data, reset = False):
        from MaterialEditorAPI import MaterialAPI
        from vnactor import str_2_enum
        if data[0] != "SceneItem":
            objectType, _, slot, go, projector = self.ExtCharacterMaterialInfo(meCtrl, data[0], data[1], data[2], data[3], "projector")
            if go and projector:
                propertyName = data[4]
                property = str_2_enum(MaterialAPI.ProjectorProperties, propertyName)
                value = float(data[5] if not reset else data[6])
                meCtrl.SetProjectorProperty(slot, objectType, projector, property, value, go)
        else:
            id, _, projector = self.ExtItemMaterialInfo(data[1], data[2], "projector")
            if projector:
                propertyName = data[3]
                property = str_2_enum(MaterialAPI.ProjectorProperties, propertyName)
                value = float(data[4] if not reset else data[5])
                meCtrl.SetProjectorProperty(id, projector, property, value)

    # MaterialNameProperty
    @staticmethod
    def SerializeMaterialNameProperty(obj):
        if hasattr(obj, "ObjectType"):
            return (
                str(obj.ObjectType),
                str(obj.CoordinateIndex), 
                str(obj.Slot), 
                obj.Renderer, 
                obj.MaterialName, 
                obj.Value, 
                obj.ValueOriginal
            )
        else:
            return (
                "SceneItem",
                str(obj.ID),
                obj.Renderer, 
                obj.MaterialName, 
                obj.Value, 
                obj.ValueOriginal
            )
    
    @staticmethod
    def DeserializeMaterialNameProperty(data):
        from vnactor import str_2_enum
        if data[0] != "SceneItem":
            from KK_Plugins.MaterialEditor import MaterialEditorCharaController
            obj = MaterialEditorCharaController.MaterialNameProperty(
                str_2_enum(MaterialEditorCharaController.ObjectType, data[0]),
                int(data[1]),
                int(data[2]),
                data[3],
                data[4],
                str(data[5]),
                str(data[6])
            )
            return obj
        else:
            from KK_Plugins.MaterialEditor import SceneController
            obj = SceneController.MaterialNameProperty(
                int(data[1]),
                data[2],
                data[3],
                str(data[4]),
                str(data[5]),
            )
            return obj

    # MaterialFloatProperty
    @staticmethod
    def SerializeMaterialFloatProperty(obj):
        if hasattr(obj, "ObjectType"):
            return (
                str(obj.ObjectType),
                str(obj.CoordinateIndex), 
                str(obj.Slot), 
                obj.MaterialName, 
                obj.Property, 
                float(obj.Value), 
                float(obj.ValueOriginal)
            )
        else:
            return (
                "SceneItem",
                str(obj.ID),
                obj.MaterialName, 
                obj.Property, 
                float(obj.Value), 
                float(obj.ValueOriginal)
            )
    
    @staticmethod
    def DeserializeMaterialFloatProperty(data):
        from vnactor import str_2_enum
        if data[0] != "SceneItem":
            from KK_Plugins.MaterialEditor import MaterialEditorCharaController
            obj = MaterialEditorCharaController.MaterialFloatProperty(
                str_2_enum(MaterialEditorCharaController.ObjectType, data[0]),
                int(data[1]),
                int(data[2]),
                data[3],
                data[4],
                str(data[5]),
                str(data[6])
            )
            return obj
        else:
            from KK_Plugins.MaterialEditor import SceneController
            obj = SceneController.MaterialFloatProperty(
                int(data[1]),
                data[2],
                data[3],
                str(data[4]),
                str(data[5]),
            )
            return obj

    def SetMaterialFloatProperty(self, meCtrl, data, reset = False):
        if data[0] != "SceneItem":
            objectType, _, slot, go, material = self.ExtCharacterMaterialInfo(meCtrl, data[0], data[1], data[2], data[3])
            if go and material:
                propertyName = data[4]
                value = float(data[5] if not reset else data[6])
                meCtrl.SetMaterialFloatProperty(slot, objectType, material, propertyName, value, go)
        else:
            id, _, material = self.ExtItemMaterialInfo(data[1], data[2])
            if material:
                propertyName = data[3]
                value = float(data[4] if not reset else data[5])
                meCtrl.SetMaterialFloatProperty(id, material, propertyName, value)

    # MaterialKeywordProperty
    @staticmethod
    def SerializeMaterialKeywordProperty(obj):
        if hasattr(obj, "ObjectType"):
            return (
                str(obj.ObjectType),
                str(obj.CoordinateIndex), 
                str(obj.Slot), 
                obj.MaterialName, 
                obj.Property, 
                str(obj.Value), 
                str(obj.ValueOriginal)
            )
        else:
            return (
                "SceneItem",
                str(obj.ID),
                obj.MaterialName, 
                obj.Property, 
                str(obj.Value), 
                str(obj.ValueOriginal)
            )
    
    @staticmethod
    def DeserializeMaterialKeywordProperty(data):
        from vnactor import str_2_enum
        if data[0] != "SceneItem":
            from KK_Plugins.MaterialEditor import MaterialEditorCharaController
            obj = MaterialEditorCharaController.MaterialKeywordProperty(
                str_2_enum(MaterialEditorCharaController.ObjectType, data[0]),
                int(data[1]),
                int(data[2]),
                data[3],
                data[4],
                bool(eval(data[5])),
                bool(eval(data[6]))
            )
            return obj
        else:
            from KK_Plugins.MaterialEditor import SceneController
            obj = SceneController.MaterialKeywordProperty(
                int(data[1]),
                data[2],
                data[3],
                bool(eval(data[4])),
                bool(eval(data[5])),
            )
            return obj

    def SetMaterialKeywordProperty(self, meCtrl, data, reset = False):
        if data[0] != "SceneItem":
            objectType, _, slot, go, material = self.ExtCharacterMaterialInfo(meCtrl, data[0], data[1], data[2], data[3])
            if go and material:
                propertyName = data[4]
                value = bool(eval(data[5] if not reset else data[6]))
                meCtrl.SetMaterialKeywordProperty(slot, objectType, material, propertyName, value, go)
        else:
            id, _, material = self.ExtItemMaterialInfo(data[1], data[2])
            if material:
                propertyName = data[3]
                value = bool(eval(data[4] if not reset else data[5]))
                meCtrl.SetMaterialKeywordProperty(id, material, propertyName, value)

    # MaterialColorProperty
    @staticmethod
    def SerializeMaterialColorProperty(obj):
        if hasattr(obj, "ObjectType"):
            return (
                str(obj.ObjectType),
                str(obj.CoordinateIndex), 
                str(obj.Slot), 
                obj.MaterialName, 
                obj.Property, 
                (obj.Value.r, obj.Value.g, obj.Value.b, obj.Value.a), 
                (obj.ValueOriginal.r, obj.ValueOriginal.g, obj.ValueOriginal.b, obj.ValueOriginal.a)
            )
        else:
            return (
                "SceneItem",
                str(obj.ID),
                obj.MaterialName, 
                obj.Property, 
                (obj.Value.r, obj.Value.g, obj.Value.b, obj.Value.a), 
                (obj.ValueOriginal.r, obj.ValueOriginal.g, obj.ValueOriginal.b, obj.ValueOriginal.a)
            )
    
    @staticmethod
    def DeserializeMaterialColorProperty(data):
        from vnactor import str_2_enum
        from UnityEngine import Color
        if data[0] != "SceneItem":
            from KK_Plugins.MaterialEditor import MaterialEditorCharaController
            obj = MaterialEditorCharaController.MaterialColorProperty(
                str_2_enum(MaterialEditorCharaController.ObjectType, data[0]),
                int(data[1]),
                int(data[2]),
                data[3],
                data[4],
                Color(data[5][0], data[5][1], data[5][2], data[5][3]),
                Color(data[6][0], data[6][1], data[6][2], data[6][3])
            )
            return obj
        else:
            from KK_Plugins.MaterialEditor import SceneController
            obj = SceneController.MaterialColorProperty(
                int(data[1]),
                data[2],
                data[3],
                Color(data[4][0], data[4][1], data[4][2], data[4][3]),
                Color(data[5][0], data[5][1], data[5][2], data[5][3])
            )
            return obj

    def SetMaterialColorProperty(self, meCtrl, data, reset = False):
        from UnityEngine import Color
        if data[0] != "SceneItem":
            objectType, _, slot, go, material = self.ExtCharacterMaterialInfo(meCtrl, data[0], data[1], data[2], data[3])
            if go and material:
                propertyName = data[4]
                value = Color(data[5][0], data[5][1], data[5][2], data[5][3]) if not reset else Color(data[6][0], data[6][1], data[6][2], data[6][3])
                meCtrl.SetMaterialColorProperty(slot, objectType, material, propertyName, value, go)
        else:
            id, _, material = self.ExtItemMaterialInfo(data[1], data[2])
            if material:
                propertyName = data[3]
                value = Color(data[4][0], data[4][1], data[4][2], data[4][3]) if not reset else Color(data[5][0], data[5][1], data[5][2], data[5][3])
                meCtrl.SetMaterialColorProperty(id, material, propertyName, value)

    # MaterialTextureProperty
    @staticmethod
    def SerializeMaterialTextureProperty(obj):
        def serializeTexAnimationDef(tad):
            from MessagePack import MessagePackSerializer
            from vnactor import bytearray_to_str64
            tadBytes = MessagePackSerializer.Serialize(tad)
            return bytearray_to_str64(tadBytes)

        if hasattr(obj, "ObjectType"):
            return (
                str(obj.ObjectType),
                str(obj.CoordinateIndex), 
                str(obj.Slot), 
                obj.MaterialName, 
                obj.Property, 
                str(obj.TexID) if obj.TexID else None, 
                (obj.Offset.x, obj.Offset.y) if obj.Offset else None,
                (obj.OffsetOriginal.x, obj.OffsetOriginal.y) if obj.OffsetOriginal else None,
                (obj.Scale.x, obj.Scale.y) if obj.Scale else None,
                (obj.ScaleOriginal.x, obj.ScaleOriginal.y) if obj.ScaleOriginal else None,
                serializeTexAnimationDef(obj.TexAnimationDef)
            )
        else:
            return (
                "SceneItem",
                str(obj.ID),
                obj.MaterialName, 
                obj.Property, 
                str(obj.TexID) if obj.TexID else None, 
                (obj.Offset.x, obj.Offset.y) if obj.Offset else None,
                (obj.OffsetOriginal.x, obj.OffsetOriginal.y) if obj.OffsetOriginal else None,
                (obj.Scale.x, obj.Scale.y) if obj.Scale else None,
                (obj.ScaleOriginal.x, obj.ScaleOriginal.y) if obj.ScaleOriginal else None,
                serializeTexAnimationDef(obj.TexAnimationDef)
            )
    
    @staticmethod
    def DeserializeMaterialTextureProperty(data):
        def deserializeTexAnimationDef(tadStr64):
            from MessagePack import MessagePackSerializer
            from KK_Plugins.MaterialEditor import MEAnimationDefine
            from vnactor import str64_to_bytearray
            tadBytes = str64_to_bytearray(tadStr64)
            tad = MessagePackSerializer.Deserialize[MEAnimationDefine](tadBytes)
            return tad
        
        from vnactor import str_2_enum
        from UnityEngine import Vector2
        if data[0] != "SceneItem":
            from KK_Plugins.MaterialEditor import MaterialEditorCharaController
            obj = MaterialEditorCharaController.MaterialTextureProperty(
                str_2_enum(MaterialEditorCharaController.ObjectType, data[0]),
                int(data[1]),
                int(data[2]),
                data[3],
                data[4],
                int(data[5]) if data[5] != None else None,
                Vector2(data[6][0], data[6][1]) if data[6] != None else None,
                Vector2(data[7][0], data[7][1]) if data[7] != None else None,
                Vector2(data[8][0], data[8][1]) if data[8] != None else None,
                Vector2(data[9][0], data[9][1]) if data[9] != None else None,
                deserializeTexAnimationDef(data[10])
            )
            return obj
        else:
            from KK_Plugins.MaterialEditor import SceneController
            obj = SceneController.MaterialTextureProperty(
                int(data[1]),
                data[2],
                data[3],
                int(data[4]) if data[4] != None else None,
                Vector2(data[5][0], data[5][1]) if data[5] != None else None,
                Vector2(data[6][0], data[6][1]) if data[6] != None else None,
                Vector2(data[7][0], data[7][1]) if data[7] != None else None,
                Vector2(data[8][0], data[8][1]) if data[8] != None else None,
                deserializeTexAnimationDef(data[9])
            )
            return obj

    def SetMaterialTextureProperty(self, meCtrl, data, reset = False):
        from UnityEngine import Vector2
        if data[0] != "SceneItem":
            objectType, _, slot, go, material = self.ExtCharacterMaterialInfo(meCtrl, data[0], data[1], data[2], data[3])
            if go and material:
                propertyName = data[4]
                texId = int(data[5]) if data[5] != None else None
                offset = (Vector2(data[6][0], data[6][1]) if not reset else Vector2(data[7][0], data[7][1])) if data[6] != None and data[7] != None else None
                scale = (Vector2(data[8][0], data[8][1]) if not reset else Vector2(data[9][0], data[9][1])) if data[8] != None and data[9] != None else None
                if texId != None:
                    pass
                if offset != None:
                    meCtrl.SetMaterialTextureOffset(slot, objectType, material, propertyName, offset, go)
                if scale != None:
                    meCtrl.SetMaterialTextureScale(slot, objectType, material, propertyName, scale, go)
        else:
            id, _, material = self.ExtItemMaterialInfo(data[1], data[2])
            if material:
                propertyName = data[3]
                texId = int(data[4]) if data[4] != None else None
                offset = (Vector2(data[5][0], data[5][1]) if not reset else Vector2(data[6][0], data[6][1])) if data[5] != None and data[6] != None else None
                scale = (Vector2(data[7][0], data[7][1]) if not reset else Vector2(data[8][0], data[8][1])) if data[7] != None and data[8] != None else None
                if texId != None:
                    pass
                if offset != None:
                    meCtrl.SetMaterialTextureOffset(id, material, propertyName, offset)
                if scale != None:
                    meCtrl.SetMaterialTextureScale(id, material, propertyName, scale)

    # MaterialShader
    @staticmethod
    def SerializeMaterialShader(obj):
        if hasattr(obj, "ObjectType"):
            return (
                str(obj.ObjectType),
                str(obj.CoordinateIndex), 
                str(obj.Slot), 
                obj.MaterialName, 
                obj.ShaderName, 
                obj.ShaderNameOriginal,
                str(obj.RenderQueue) if obj.RenderQueue != None else None,
                str(obj.RenderQueueOriginal) if obj.RenderQueueOriginal != None else None,
            )
        else:
            return (
                "SceneItem",
                str(obj.ID),
                obj.MaterialName, 
                obj.ShaderName, 
                obj.ShaderNameOriginal,
                str(obj.RenderQueue) if obj.RenderQueue != None else None,
                str(obj.RenderQueueOriginal) if obj.RenderQueueOriginal != None else None,
            )
    
    @staticmethod
    def DeserializeMaterialShader(data):
        from vnactor import str_2_enum
        if data[0] != "SceneItem":
            from KK_Plugins.MaterialEditor import MaterialEditorCharaController
            obj = MaterialEditorCharaController.MaterialShader(
                str_2_enum(MaterialEditorCharaController.ObjectType, data[0]),
                int(data[1]),
                int(data[2]),
                data[3],
                data[4],
                data[5],
                int(data[6]) if data[6] != None else None,
                int(data[7]) if data[7] != None else None,
            )
            return obj
        else:
            from KK_Plugins.MaterialEditor import SceneController
            obj = SceneController.MaterialShader(
                int(data[1]),
                data[2],
                data[3],
                data[4],
                int(data[5]) if data[5] != None else None,
                int(data[6]) if data[6] != None else None
            )
            return obj

    def SetMaterialShader(self, meCtrl, data, reset = False):
        if data[0] != "SceneItem":
            objectType, _, slot, go, material = self.ExtCharacterMaterialInfo(meCtrl, data[0], data[1], data[2], data[3])
            if go and material:
                shaderName = data[4] if not reset else data[5]
                renderQueue = int(data[6] if not reset else data[7]) if data[6] != None and data[7] != None else None
                if shaderName != None:
                    meCtrl.SetMaterialShader(slot, objectType, material, shaderName, go)
                if renderQueue != None:
                    meCtrl.SetMaterialShaderRenderQueue(slot, objectType, material, renderQueue, go)
        else:
            id, _, material = self.ExtItemMaterialInfo(data[1], data[2])
            if material:
                shaderName = data[3] if not reset else data[4]
                renderQueue = int(data[5] if not reset else data[6]) if data[5] != None and data[6] != None else None
                if shaderName != None:
                    meCtrl.SetMaterialShader(id, material, shaderName)
                if renderQueue != None:
                    meCtrl.SetMaterialShaderRenderQueue(id, material, renderQueue)

    # MaterialCopy
    @staticmethod
    def SerializeMaterialCopy(obj):
        if hasattr(obj, "ObjectType"):
            return (
                str(obj.ObjectType),
                str(obj.CoordinateIndex), 
                str(obj.Slot), 
                obj.MaterialName, 
                obj.MaterialCopyName, 
            )
        else:
            return (
                "SceneItem",
                str(obj.ID),
                obj.MaterialName, 
                obj.MaterialCopyName, 
            )
    
    @staticmethod
    def DeserializeMaterialCopy(data):
        from vnactor import str_2_enum
        if data[0] != "SceneItem":
            from KK_Plugins.MaterialEditor import MaterialEditorCharaController
            obj = MaterialEditorCharaController.MaterialCopy(
                str_2_enum(MaterialEditorCharaController.ObjectType, data[0]),
                int(data[1]),
                int(data[2]),
                data[3],
                data[4],
            )
            return obj
        else:
            from KK_Plugins.MaterialEditor import SceneController
            obj = SceneController.MaterialCopy(
                int(data[1]),
                data[2],
                data[3],
            )
            return obj
        
    @staticmethod
    def FormatName(name):
        return name.replace("(Instance)", "").replace(" Instance", "").strip()

    def ExtCharacterMaterialInfo(self, controller, objectType, coordinateIndex, slot, name, type = "material"):
        from vnactor import str_2_enum
        from KK_Plugins.MaterialEditor import MaterialEditorCharaController
        objectType = str_2_enum(MaterialEditorCharaController.ObjectType, objectType)
        coordinateIndex = int(coordinateIndex)
        slot = int(slot)
        go = CallPrivate(controller, "FindGameObject", [objectType, slot])
        if go:
            if type == "renderer":
                renderer = self.GetGameObjectRendererByName(go, name)
                return objectType, coordinateIndex, slot, go, renderer
            elif type == "projector":
                projector = self.GetGameObjectProjectorByName(go, name)
                return objectType, coordinateIndex, slot, go, projector
            else:
                material = self.GetGameObjectMaterialByName(go, name)
                return objectType, coordinateIndex, slot, go, material
        else:
            return objectType, coordinateIndex, slot, None, None
        
    def ExtItemMaterialInfo(self, id, name, type = "material"):
        from KK_Plugins.MaterialEditor import SceneController
        id = int(id)
        go = CallPrivateStatic(SceneController, "GetObjectByID", [id])
        if go:
            if type == "renderer":
                renderer = self.GetGameObjectRendererByName(go, name)
                return id, go, renderer
            elif type == "projector":
                projector = self.GetGameObjectProjectorByName(go, name)
                return id, go, projector
            else:
                material = self.GetGameObjectMaterialByName(go, name)
                return id, go, material
        else:
            return id, None, None

    # Debug Code
    def PrintData(self, targetObj):
        print("\nMaterialEditor Data of %s (%d)"%(targetObj.text_name, targetObj.dicKey))
        data = self.GetMaterialEditorData(targetObj)
        for dataName in MaterialEditor.VALID_DATA_NAME:
            if dataName in data.keys():
                print("> %s: %s"%(dataName, len(data[dataName])))
                for item in data[dataName]:
                    print("    " + str(item))
            else:
                print("> %s: None"%(dataName))
        print("")

# ::::::::::: InvisibleBody :::::::::::
class InvisibleBody(ExtPlugin):
    def __init__(self):
        if ExtPlugin.exists("KK_InvisibleBody"):
            ExtPlugin.__init__(self, "KK_InvisibleBody")
            self.engine = "KK"
        elif ExtPlugin.exists("KKS_InvisibleBody"):
            ExtPlugin.__init__(self, "KKS_InvisibleBody")
            self.engine = "KKS"
        elif ExtPlugin.exists("AI_InvisibleBody"):
            ExtPlugin.__init__(self, "AI_InvisibleBody")
            self.engine = "AI"
        elif ExtPlugin.exists("HS2_InvisibleBody"):
            ExtPlugin.__init__(self, "HS2_InvisibleBody")
            self.engine = "HS2"
        else:
            self.isDetected = False
            self.engine = None

    def GetInvisibleBodyCharaController(self, ociChar):
        if not self.isDetected:
            return None
        from KK_Plugins import InvisibleBody
        try:
            if ociChar != None:
                if hasattr(ociChar, "objctrl"):
                    ociChar = ociChar.objctrl
                return ociChar.charInfo.gameObject.GetComponentInChildren[InvisibleBody.InvisibleBodyCharaController]()
        except:
            traceback.print_exc()
            return None
        
    def GetBodyInvisible(self, ociChar):
        if not self.isDetected:
            return None
        ibc = self.GetInvisibleBodyCharaController(ociChar)
        if not ibc:
            return None
        return ibc.Invisible

    def SetBodyInvisible(self, ociChar, invisible):
        if not self.isDetected:
            return
        ibc = self.GetInvisibleBodyCharaController(ociChar)
        if not ibc:
            return
        ibc.Invisible = invisible

# ::::::::::: UncensorSelector :::::::::::
class UncensorSelector(ExtPlugin):
    def __init__(self):
        if ExtPlugin.exists("KK_UncensorSelector"):
            ExtPlugin.__init__(self, "KK_UncensorSelector")
            self.engine = "KK"
        elif ExtPlugin.exists("KKS_UncensorSelector"):
            ExtPlugin.__init__(self, "KKS_UncensorSelector")
            self.engine = "KKS"
        elif ExtPlugin.exists("AI_UncensorSelector"):
            ExtPlugin.__init__(self, "AI_UncensorSelector")
            self.engine = "AI"
        elif ExtPlugin.exists("HS2_UncensorSelector"):
            ExtPlugin.__init__(self, "HS2_UncensorSelector")
            self.engine = "HS2"
        else:
            self.isDetected = False
            self.engine = None

    def GetUncensorSelectorController(self, ociChar):
        if not self.isDetected:
            return None
        from KK_Plugins import UncensorSelector
        try:
            if ociChar != None:
                if hasattr(ociChar, "objctrl"):
                    ociChar = ociChar.objctrl
                return ociChar.charInfo.gameObject.GetComponentInChildren[UncensorSelector.UncensorSelectorController]()
        except:
            traceback.print_exc()
            return None
        
    def GetUncensorData(self, ociChar):
        if not self.isDetected:
            return None
        usc = self.GetUncensorSelectorController(ociChar)
        if not usc:
            return None
        body = GetPrivateProperty(usc, "BodyGUID")
        penis = GetPrivateProperty(usc, "PenisGUID")
        ball = GetPrivateProperty(usc, "BallsGUID")
        return (body, penis, ball)

    def SetUncensorData(self, ociChar, usData):
        if not self.isDetected:
            return
        usc = self.GetUncensorSelectorController(ociChar)
        if not usc:
            return
        SetPrivateProperty(usc, "BodyGUID", (usData[0],))
        SetPrivateProperty(usc, "PenisGUID", (usData[1],))
        SetPrivateProperty(usc, "BallsGUID", (usData[2],))
        usc.UpdateUncensor()

# ::::::::::: BetterPenetration :::::::::::
class BetterPenetration(ExtPlugin):
    def __init__(self):
        if ExtPlugin.exists("KK_Studio_BetterPenetration"):
            ExtPlugin.__init__(self, "KK_Studio_BetterPenetration")
            self.engine = "KK"
        elif ExtPlugin.exists("KKS_Studio_BetterPenetration"):
            ExtPlugin.__init__(self, "KKS_Studio_BetterPenetration")
            self.engine = "KKS"
        elif ExtPlugin.exists("AI_Studio_BetterPenetration"):
            ExtPlugin.__init__(self, "AI_Studio_BetterPenetration")
            self.engine = "AI"
        elif ExtPlugin.exists("HS2_Studio_BetterPenetration"):
            ExtPlugin.__init__(self, "HS2_Studio_BetterPenetration")
            self.engine = "HS2"
        else:
            self.isDetected = False
            self.engine = None

    def GetBetterPenetrationController(self, ociChar):
        if not self.isDetected:
            return None
        from Core_BetterPenetration import BetterPenetrationController
        try:
            if ociChar != None:
                if hasattr(ociChar, "objctrl"):
                    ociChar = ociChar.objctrl
                return ociChar.charInfo.gameObject.GetComponentInChildren[BetterPenetrationController]()
        except:
            traceback.print_exc()
            return None
        
    def GetBetterPenetrationData(self, ociChar):
        bpc = self.GetBetterPenetrationController(ociChar)
        if bpc == None:
            return None
        
        bpd = {}
        bpd["Enabled"] = bpc.Enabled
        bpd["DanRadiusScale"] = bpc.DanColliderRadiusScale
        bpd["DanLengthScale"] = bpc.DanColliderLengthScale
        bpd["DanLengthSquish"] = bpc.DanLengthSquish
        bpd["DanGirthSquish"] = bpc.DanGirthSquish
        bpd["DanSquishThrd"] = bpc.DanSquishThreshold
        bpd["AutoTarget"] = bpc.DanAutoTarget
        bpd["MaxPull"] = bpc.MaxPull
        bpd["MaxPush"] = bpc.MaxPush
        bpd["PullRate"] = bpc.PullRate
        bpd["ReturnRate"] = bpc.ReturnRate
        bpd["BellyBulge"] = bpc.EnableBellyBulge
        bpd["BellyBulgeRate"] = bpc.BellyBulgeScale
        return bpd

    def SetBetterPenetrationData(self, ociChar, bpData):
        bpc = self.GetBetterPenetrationController(ociChar)
        if bpc == None:
            return
        
        try:
            # enable
            if "Enabled" in bpData and bpData["Enabled"] != bpc.Enabled:
                if bpData["Enabled"]:
                    pl = PLBepInEx()
                    ncInfo = pl.get_pluginInfo_by_guid("com.joan6694.illusionplugins.nodesconstraints")
                    if ncInfo != None and ncInfo.Instance != None:
                        ncPlugin = ncInfo.Instance
                    else:
                        print("Fail to get NodeConstraints plugin, needed by BetterPenetrationData")
                        return
                    bpc.enabled = True
                    bpc.InitializeDanAgent()
                    bpc.AddDanConstraints(ncPlugin, None, None)
                else:
                    bpc.ClearDanAgent()
                    bpc.enabled = False

            # properties
            if "DanRadiusScale" in bpData:
                bpc.DanColliderRadiusScale = bpData["DanRadiusScale"]
            if "DanLengthScale" in bpData:
                bpc.DanColliderLengthScale = bpData["DanLengthScale"]
            if "DanLengthSquish" in bpData:
                bpc.DanLengthSquish = bpData["DanLengthSquish"]
            if "DanGirthSquish" in bpData:
                bpc.DanGirthSquish = bpData["DanGirthSquish"]
            if "DanSquishThrd" in bpData:
                bpc.DanSquishThreshold = bpData["DanSquishThrd"]
            if "AutoTarget" in bpData:
                bpc.DanAutoTarget = bpData["AutoTarget"]
            if "MaxPull" in bpData:
                bpc.MaxPull = bpData["MaxPull"]
            if "MaxPush" in bpData:
                bpc.MaxPush = bpData["MaxPush"]
            if "PullRate" in bpData:
                bpc.PullRate = bpData["PullRate"]
            if "ReturnRate" in bpData:
                bpc.ReturnRate = bpData["ReturnRate"]
            if "BellyBulge" in bpData:
                bpc.EnableBellyBulge = bpData["BellyBulge"]
            if "BellyBulgeRate" in bpData:
                bpc.BellyBulgeScale = bpData["BellyBulgeRate"]
        except:
            return

# ::::::::::: AnimationCurveEditor :::::::::::
class ACEditor(ExtPlugin):
    ACEObject = None
    ACEditor = None

    def __init__(self):
        if ExtPlugin.exists("AnimationCurveEditor.Old"):
            ExtPlugin.__init__(self, "AnimationCurveEditor.Old")
            self.version = "old"
        elif ExtPlugin.exists("AnimationCurveEditor.New"):
            ExtPlugin.__init__(self, "AnimationCurveEditor.New")
            self.version = "new"
        else:
            self.isDetected = False
            self.version = None

    def GetAnimationCurveEditor(self):
        if not self.isDetected:
            return None
        
        from UnityEngine import Camera
        from AnimationCurveEditor import AnimationCurveEditor
        if ACEditor.ACEObject == None:
            ACEditor.ACEObject = Camera.current.gameObject
        if ACEditor.ACEditor == None:
            ACEditor.ACEditor = ACEditor.ACEObject.GetComponent[AnimationCurveEditor]()
        if ACEditor.ACEditor == None:
            ACEditor.ACEditor = ACEditor.ACEObject.AddComponent[AnimationCurveEditor]()
        return ACEditor.ACEditor


    def ShowAnimationCurveEditor(self, acData = None, rect = None):
        if not self.isDetected:
            return None

        from UnityEngine import AnimationCurve, Rect
        if acData == None:
            acData = AnimationCurve()
            acData.AddKey(0, 0.0)
            acData.AddKey(1, 1.0)
        if rect == None:
            rect = Rect(100, 100, 300, 300)

        def showACE(game, aceParam):
            ace, acData, rect = aceParam
            ace.Init(acData, rect)
            return True

        from vngameengine import vnge_game as game
        ace = self.GetAnimationCurveEditor()
        if ace:
            game.append_update_job(showACE, (ace, acData, rect))
        return ace

# ::::::::::: ExtraJointCorrection :::::::::::
class ExtraJointCorrection(ExtPlugin):
    def __init__(self):
        ExtPlugin.__init__(self, "ExtraJointCorrection")

    def GetExtraJointCorrectionCtrl(self, ociChar):
        if not self.isDetected:
            return None
        from ExtraJointCorrection import ExtraJointController
        try:
            if ociChar != None:
                if hasattr(ociChar, "objctrl"):
                    ociChar = ociChar.objctrl
                return ociChar.charInfo.gameObject.GetComponentInChildren[ExtraJointController]()
        except:
            traceback.print_exc()
            return None

    def GetExtraJoinData(self, ociChar):
        if hasattr(ociChar, "objctrl"):
            ociChar = ociChar.objctrl
        ejcc = self.GetExtraJointCorrectionCtrl(ociChar)
        if not ejcc:
            return None
        info = ociChar.charInfo.expression.info
        ejd = {}
        ejd["Mouth"] = ejcc.MouthCorrection
        ejd["ShoulderLeft"] = info[0].enable
        ejd["ShoulderRight"] = info[7].enable
        return ejd

    def SetExtraJoinData(self, ociChar, ejData):
        if hasattr(ociChar, "objctrl"):
            ociChar = ociChar.objctrl
        ejcc = self.GetExtraJointCorrectionCtrl(ociChar)
        if not ejcc:
            return
        try:
            info = ociChar.charInfo.expression.info
            if "Mouth" in ejData:
                ejcc.MouthCorrection = ejData["Mouth"]
            if "ShoulderLeft" in ejData:
                info[0].enable = ejData["ShoulderLeft"]
            if "ShoulderRight" in ejData:
                info[7].enable = ejData["ShoulderRight"]
        except:
            return

# ::::::::::: HooahGlobalConfig :::::::::::
class HooahGlobalConfig(ExtPlugin):
    def __init__(self):
        if ExtPlugin.exists("HooahComponents"):
            ExtPlugin.__init__(self, "HooahComponents")
            from HooahComponents.Configuration import AuraConfigManager
            self.instance = AuraConfigManager.Instance
        else:
            self.isDetected = False
            self.instance = None
    
    def GetGlobalConfig(self):
        if self.instance:
            try:
                fs = {}
                fs["UseDensity"] = str(self.instance.Settings.baseSettings.useDensity)
                fs["BaseDensity"] = self.instance.Settings.baseSettings.density
                fs["UseScattering"] = str(self.instance.Settings.baseSettings.useScattering)
                fs["BaseScattering"] = self.instance.Settings.baseSettings.scattering
                fs["UseAmbientLighting"] = str(self.instance.Settings.baseSettings.useAmbientLighting)
                fs["BaseAmbientLighting"] = self.instance.Settings.baseSettings.ambientLightingStrength
                return fs
            except:
                traceback.print_exc()
                return None
        else:
            return None
        
    def SetGlobalConfig(self, fs):
        if self.instance:
            try:
                if "UseDensity" in fs:
                    self.instance.Settings.baseSettings.useDensity = bool(fs["UseDensity"])
                    self.instance.Config.UseDensity = bool(fs["UseDensity"])
                if "BaseDensity" in fs:
                    self.instance.Settings.baseSettings.density = fs["BaseDensity"]
                    self.instance.Config.BaseDensity = fs["BaseDensity"]
                if "UseScattering" in fs:
                    self.instance.Settings.baseSettings.useScattering = bool(fs["UseScattering"])
                    self.instance.Config.UseScattering = bool(fs["UseScattering"])
                if "BaseScattering" in fs:
                    self.instance.Settings.baseSettings.scattering = fs["BaseScattering"]
                    self.instance.Config.BaseScattering = fs["BaseScattering"]
                if "UseAmbientLighting" in fs:
                    self.instance.Settings.baseSettings.useAmbientLighting = bool(fs["UseAmbientLighting"])
                    self.instance.Config.UseAmbientLighting = bool(fs["UseAmbientLighting"])
                if "BaseAmbientLighting" in fs:
                    self.instance.Settings.baseSettings.ambientLightingStrength = fs["BaseAmbientLighting"]
                    self.instance.Config.BaseAmbientLighting = fs["BaseAmbientLighting"]
            except:
                traceback.print_exc()

# ::::::::::: HideAllUI :::::::::::
class HideAllUI(ExtPlugin):
    def __init__(self):
        if ExtPlugin.exists("HideAllUI.Koikatu"):
            ExtPlugin.__init__(self, "HideAllUI.Koikatu")
            self.engine = "KK"
        elif ExtPlugin.exists("HideAllUI.KoikatsuSunshine"):
            ExtPlugin.__init__(self, "HideAllUI.KoikatsuSunshine")
            self.engine = "KKS"
        elif ExtPlugin.exists("HideAllUI.AISyoujyo"):
            ExtPlugin.__init__(self, "HideAllUI.AISyoujyo")
            self.engine = "AI"
        elif ExtPlugin.exists("HideAllUI.HoneySelect2"):
            ExtPlugin.__init__(self, "HideAllUI.HoneySelect2")
            self.engine = "HS2"
        elif ExtPlugin.exists("HideAllUI.PlayHome"):
            ExtPlugin.__init__(self, "HideAllUI.PlayHome")
            self.engine = "PH"
        else:
            self.isDetected = False
            self.engine = None

        if self.isDetected:
            from HideAllUI import HideAllUICore
            self.uiHandle = GetPrivateStatic(HideAllUICore, "currentUIHandler")
        else:
            self.uiHandle = None

    def ToggleUI(self):
        if self.uiHandle:
            self.uiHandle.ToggleUI()

    def Visible(self):
        if self.uiHandle:
            return GetPrivate(self.uiHandle, "visible")
        else:
            return None
        
    def ShowHideUI(self, show):
        if self.uiHandle:
            visible = self.Visible()
            if (visible and not show) or (not visible and show):
                self.ToggleUI()

# :::::::::::: ObjectMap ::::::::::::
class ObjectMap(ExtPlugin):
    def __init__(self):
        if ExtPlugin.exists("KK.ObjectMap"):
            ExtPlugin.__init__(self, "KK.ObjectMap")
            self.engine = "KK"
        elif ExtPlugin.exists("KKS.ObjectMap"):
            ExtPlugin.__init__(self, "KKS.ObjectMap")
            self.engine = "KKS"
        elif ExtPlugin.exists("HS2.ObjectMap"):
            ExtPlugin.__init__(self, "HS2.ObjectMap")
            self.engine = "HS2"
        else:
            self.isDetected = False
            self.engine = None

        if self.isDetected:
            pass

    def GetObjectMapData(self, diff = False):
        try:
            from Core.ObjectMap import ObjectMap, GameObjectPathUtility
            from Studio import OCIItem, OCIFolder, OCILight
            MapObjects = GetPrivateStatic(ObjectMap, "MapObjects")
            #OriginalProperties = GetPrivateStatic(ObjectMap, "OriginalProperties")

            mapData = {}
            for gameObject in MapObjects.Keys:
                oci = MapObjects[gameObject]
                ociInfo = oci.objectInfo
                path = GameObjectPathUtility.GetPathWithSiblingIndex(gameObject)
                if isinstance(oci, (OCIFolder, OCIItem)):
                    mapData[path] = (oci.treeNodeObject.visible, 
                                    ociInfo.changeAmount.pos, 
                                    ociInfo.changeAmount.rot, 
                                    ociInfo.changeAmount.scale)
                elif isinstance(oci, OCILight):
                    mapData[path] = (oci.treeNodeObject.visible, 
                                    ociInfo.changeAmount.pos, 
                                    ociInfo.changeAmount.rot, 
                                    ociInfo.changeAmount.scale,
                                    ociInfo.color,
                                    ociInfo.intensity,
                                    ociInfo.range,
                                    ociInfo.spotAngle,
                                    ociInfo.shadow,
                                    ociInfo.enable,
                                    ociInfo.drawTarget)
            return mapData
        except:
            print("Fail to get ObjectMap data")
            traceback.print_exc()
            return {}

    def SetObjectMapData(self, mapData):
        try:
            from Core.ObjectMap import ObjectMap, GameObjectPathUtility
            from Studio import OCIItem, OCIFolder, OCILight
            from vnactor import tuple3_2_vector3, tuple4_2_color
            MapObjects = GetPrivateStatic(ObjectMap, "MapObjects")

            for path, data in mapData.items():
                gameObject = GameObjectPathUtility.FindByPathWithSiblingIndex(path)
                if not gameObject or gameObject not in MapObjects:
                    continue
                oci = MapObjects[gameObject]
                if isinstance(oci, (OCIFolder, OCIItem)):
                    oci.treeNodeObject.visible = data[0]
                    ca = oci.objectInfo.changeAmount
                    ca.pos = tuple3_2_vector3(data[1])
                    ca.rot = tuple3_2_vector3(data[2])
                    ca.scale = tuple3_2_vector3(data[3])
                    ca.OnChange()
                elif isinstance(oci, OCILight):
                    #oci.treeNodeObject.visible = data[0]
                    ca = oci.objectInfo.changeAmount
                    ca.pos = tuple3_2_vector3(data[1])
                    ca.rot = tuple3_2_vector3(data[2])
                    ca.scale = tuple3_2_vector3(data[3])
                    ca.OnChange()

                    oci.SetColor(tuple4_2_color(data[4]))
                    oci.SetIntensity(data[5], False)
                    oci.SetRange(data[6], False)
                    oci.SetSpotAngle(data[7], False)
                    oci.SetShadow(data[8], False)
                    oci.SetEnable(data[9], True)
                    #oci.objectInfo.drawTarget = data[10]
                    oci.treeNodeObject.SetVisible(data[9])
        except:
            print("Fail to set ObjectMap data")
            traceback.print_exc()

# :::::::::::: AssetSS ::::::::::::
# Plugin: "Asset Scene System" by darkseraph, BepInEx GUID "darkseraph.assetss", assembly name "AssetSS"
# Covers: splicer scene-wide data (system state) and character/item-prop blendshape weights
# HS2 only. The splicer scene state is treated as a single opaque system blob (matching the
# NodesConstraints/ObjectMap/ExtTimeline family), not as individual selectable VNGE Prop nodes -
# VNGE has no extension point for registering a new Studio tree node type.
class AssetSS(ExtPlugin):
    _FLAGS = BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic

    def __init__(self):
        if ExtPlugin.exists("AssetSS"):
            ExtPlugin.__init__(self, "AssetSS")
            self.engine = "HS2"
        else:
            self.isDetected = False
            self.engine = None
        self.assembly = None
        self.splicerType = None
        self.blendshapeStoreType = None
        self.layersType = None
        if self.isDetected:
            from System import AppDomain
            for loadedAssembly in AppDomain.CurrentDomain.GetAssemblies():
                if str(loadedAssembly.GetName().Name) == "AssetSS":
                    self.assembly = loadedAssembly
                    break
            if self.assembly is not None:
                self.splicerType = self.assembly.GetType("AssetSS.SplicerManager")
                self.blendshapeStoreType = self.assembly.GetType("AssetSS.BlendshapeStore")
                self.layersType = self.assembly.GetType("AssetSS.SplicerLayers")
            if self.splicerType is None or self.blendshapeStoreType is None:
                self.isDetected = False

    def _get_field(self, obj, name):
        field = obj.GetType().GetField(name, self._FLAGS)
        return field.GetValue(obj) if field is not None else None

    def _set_field(self, obj, name, value):
        field = obj.GetType().GetField(name, self._FLAGS)
        if field is None:
            return
        field.SetValue(obj, self._coerce(value, field.FieldType))

    def _get_property(self, obj, name):
        prop = obj.GetType().GetProperty(name, self._FLAGS)
        return prop.GetValue(obj, None) if prop is not None else None

    def _set_property(self, obj, name, value):
        prop = obj.GetType().GetProperty(name, self._FLAGS)
        if prop is not None and prop.CanWrite:
            prop.SetValue(obj, self._coerce(value, prop.PropertyType), None)

    def _coerce(self, value, targetType):
        from System import Convert, Single, Enum
        from UnityEngine import Color, Vector2, Vector3, Quaternion
        if value is None:
            return None
        typeName = targetType.Name
        if typeName == "Color" and isinstance(value, (tuple, list)):
            return Color(Single(value[0]), Single(value[1]), Single(value[2]), Single(value[3]))
        if typeName == "Vector2" and isinstance(value, (tuple, list)):
            return Vector2(Single(value[0]), Single(value[1]))
        if typeName == "Vector3" and isinstance(value, (tuple, list)):
            return Vector3(Single(value[0]), Single(value[1]), Single(value[2]))
        if typeName == "Quaternion" and isinstance(value, (tuple, list)):
            return Quaternion(Single(value[0]), Single(value[1]), Single(value[2]), Single(value[3]))
        if targetType.IsEnum:
            return Enum.ToObject(targetType, value)
        return Convert.ChangeType(value, targetType)

    def _value(self, value):
        from System import Convert
        if value is None:
            return None
        typeName = value.GetType().Name
        if typeName == "Color":
            return (float(value.r), float(value.g), float(value.b), float(value.a))
        if typeName == "Vector2":
            return (float(value.x), float(value.y))
        if typeName == "Vector3":
            return (float(value.x), float(value.y), float(value.z))
        if typeName == "Quaternion":
            return (float(value.x), float(value.y), float(value.z), float(value.w))
        if value.GetType().IsArray and value.GetType().GetElementType().Name == "Byte":
            return str(Convert.ToBase64String(value)) if value.Length else ""
        if typeName == "String":
            return str(value)
        if typeName == "Boolean":
            return bool(value)
        if typeName in ("Byte", "SByte", "Int16", "UInt16", "Int32", "UInt32", "Int64", "UInt64"):
            return int(value)
        if typeName in ("Single", "Double", "Decimal"):
            return float(value)
        return value

    def _invoke(self, obj, name, args):
        method = obj.GetType().GetMethod(name, self._FLAGS)
        if method is not None:
            return method.Invoke(obj, tuple(args))

    def _splicers(self):
        if self.splicerType is None:
            return ()
        prop = self.splicerType.GetProperty("All", self._FLAGS)
        return prop.GetValue(None, None) if prop is not None else ()

    def _refresh_parenting(self):
        # AssetSS.SplicerParenting.Reconcile/Reset/QueueRestore confirmed present and matching this
        # exact signature as of AssetSS v0.6.6 (was absent in v0.6.0). The "is not None" guards below
        # are kept anyway in case a user is on an older plugin build without this API.
        if self.assembly is None:
            return
        parentingType = self.assembly.GetType("AssetSS.SplicerParenting")
        if parentingType is not None:
            reconcile = parentingType.GetMethod("Reconcile", self._FLAGS)
            if reconcile is not None:
                reconcile.Invoke(None, ())

    def _hold_character_parts(self):
        # AssetSS.CharacterPartHooks.Hold() confirmed present as of AssetSS v0.6.6 (was absent in
        # v0.6.0; there are now two overloads, Hold() and Hold(float), the 0-arg filter below picks
        # the right one). The "is not None" guards are kept in case of an older plugin build.
        if self.assembly is None:
            return
        hooksType = self.assembly.GetType("AssetSS.CharacterPartHooks")
        if hooksType is None:
            return
        for method in hooksType.GetMethods(self._FLAGS):
            if method.Name == "Hold" and len(method.GetParameters()) == 0:
                method.Invoke(None, ())
                return

    def _splicer_state(self, splicer):
        settings = self._get_field(splicer, "Settings")
        settingValues = {}
        if settings is not None:
            for field in settings.GetType().GetFields(self._FLAGS):
                if not field.IsStatic and not field.IsLiteral:
                    settingValues[field.Name] = self._value(field.GetValue(settings))
        state = {
            "id": self._value(self._get_field(splicer, "Id")),
            "dicKey": int(self._get_field(splicer, "DicKey")),
            "name": self._value(self._get_field(splicer, "Name")),
            "assetPath": self._value(self._get_field(splicer, "AssetPath")),
            "owner": self._value(self._get_field(splicer, "Owner")),
            "enabled": bool(self._get_field(splicer, "Enabled")),
            "position": self._value(self._get_property(splicer, "Position")),
            "rotation": self._value(self._get_property(splicer, "Rotation")),
            "size": self._value(self._get_property(splicer, "Size")),
            "scale": self._value(self._get_property(splicer, "Size")),
            "settings": settingValues,
        }
        # ParentDicKey/ParentSplicerId/ParentPartIndex/ParentNodePath/ChildDicKeys confirmed present
        # on AssetSS.SceneSplicer as of AssetSS v0.6.6 (int/string/int/string/List<int> respectively,
        # were absent in v0.6.0). _get_field still returns None safely on an older plugin build.
        for name in ("ImageData", "ImageExtension", "DetailData", "DetailExtension",
                     "BumpData", "BumpExtension", "ParentDicKey", "ParentSplicerId",
                     "ParentPartIndex", "ParentNodePath"):
            state[name] = self._value(self._get_field(splicer, name))
        childDicKeys = self._get_field(splicer, "ChildDicKeys")
        state["ChildDicKeys"] = [int(key) for key in childDicKeys] if childDicKeys is not None else []
        return state

    def _layers_serialize(self):
        if self.layersType is None:
            return None
        return self.layersType.GetMethod("Serialize", self._FLAGS)

    def _layers_deserialize(self):
        # This looks for a 3-parameter "Deserialize" overload. As of AssetSS v0.6.6 one now exists:
        # Deserialize(byte[] bytes, bool replace, Dictionary<int,int> keyMap) - note this is a
        # different shape than originally assumed (no remapTarget/targetKey/targetLabel); it was
        # absent in v0.6.0 (only 1-param and 6-declared-param overloads existed then). _restore_layers
        # below calls this with (bytes, True, None) - None is passed as the keyMap, meaning "no dicKey
        # remap", which is a valid call and restores the baked layers as-is.
        if self.layersType is None:
            return None
        for method in self.layersType.GetMethods(self._FLAGS):
            if method.Name == "Deserialize" and len(method.GetParameters()) == 3:
                return method
        return None

    def _layers_clear(self):
        if self.layersType is None:
            return None
        return self.layersType.GetMethod("ClearAll", self._FLAGS)

    def _layers_blob(self):
        from System import Convert
        serialize = self._layers_serialize()
        if serialize is None:
            return ""
        try:
            data = serialize.Invoke(None, ())
            if data is None or data.Length == 0:
                return ""
            return str(Convert.ToBase64String(data))
        except Exception:
            return ""

    def _restore_layers(self, states):
        from System import Convert
        deserialize = self._layers_deserialize()
        if deserialize is None or "layers" not in states:
            return
        try:
            # Removing layers one by one lets each material take its own texture back before the
            # state's layers are baked over it, so a state without layers clears the previous bake.
            clearAll = self._layers_clear()
            if clearAll is not None:
                clearAll.Invoke(None, ())
                self._hold_character_parts()
            encoded = states.get("layers")
            if not encoded:
                return
            deserialize.Invoke(None, (Convert.FromBase64String(str(encoded)), True, None))
        except Exception as error:
            print("VNGE AssetSS layer restore failed: " + str(error))

    def GetSplicerSceneData(self):
        # whole-scene splicer list, treated as a single opaque system-state blob
        if not self.isDetected:
            return None
        self._refresh_parenting()
        states = []
        for splicer in self._splicers():
            if splicer is not None:
                states.append(self._splicer_state(splicer))
        checked = []
        checkedProperty = self.splicerType.GetProperty("CheckedIds", self._FLAGS)
        if checkedProperty is not None:
            checked = [str(value) for value in checkedProperty.GetValue(None, None)]
        primaryProperty = self.splicerType.GetProperty("PrimaryId", self._FLAGS)
        primary = primaryProperty.GetValue(None, None) if primaryProperty is not None else ""
        return {"splicers": states, "checked": checked, "primary": str(primary or ""),
                "layers": self._layers_blob()}

    def _set_image(self, splicer, layer, data, extension):
        from System import Convert
        raw = Convert.FromBase64String(data) if data else None
        extension = extension or "png"
        loader = self._splicer_layer_loader(layer)
        if loader is not None:
            loader.Invoke(None, (splicer, raw, extension))
            return
        self._invoke(splicer, "Set" + layer,
                     (self._texture_from_bytes(raw), raw, extension))

    def _splicer_layer_loader(self, layer):
        if self.splicerType is None:
            return None
        name = "Load" + layer
        for method in self.splicerType.GetMethods(self._FLAGS):
            if method.Name != name or not method.IsStatic:
                continue
            parameters = method.GetParameters()
            if len(parameters) == 3 and parameters[0].ParameterType.Name == "SceneSplicer":
                return method
        return None

    def _texture_from_bytes(self, raw):
        if not raw or not raw.Length:
            return None
        from UnityEngine import ImageConversion, Texture2D, TextureFormat
        texture = Texture2D(2, 2, TextureFormat.ARGB32, False)
        if not ImageConversion.LoadImage(texture, raw):
            raise Exception("AssetSS could not load tracked splicer image data")
        return texture

    def _create_splicer(self, state):
        from System import Convert
        imageData = state.get("ImageData")
        if not imageData:
            return None
        raw = Convert.FromBase64String(imageData)
        method = self.splicerType.GetMethod("CreateFromImageBytes", self._FLAGS)
        if method is None:
            return None
        return method.Invoke(None, (raw, state.get("ImageExtension") or "png",
                                    state.get("name") or "Splicer"))

    def _find_or_create_splicer(self, state):
        splicer = None
        splicerId = state.get("id")
        if splicerId:
            find = self.splicerType.GetMethod("Find", self._FLAGS)
            if find is not None:
                splicer = find.Invoke(None, (splicerId,))
        if splicer is None and state.get("dicKey") is not None:
            findByDicKey = self.splicerType.GetMethod("FindByDicKey", self._FLAGS)
            if findByDicKey is not None:
                splicer = findByDicKey.Invoke(None, (int(state["dicKey"]),))
        if splicer is None:
            splicer = self._create_splicer(state)
        return splicer

    def _restore_splicer(self, splicer, state, dicKeyMap):
        if splicer is None:
            return
        self._set_field(splicer, "Id", state.get("id"))
        self._set_field(splicer, "Name", state.get("name"))
        self._set_field(splicer, "AssetPath", state.get("assetPath"))
        self._set_field(splicer, "Owner", state.get("owner"))
        node = self._get_field(splicer, "Node")
        prefixField = self.splicerType.GetField("TreeNodePrefix", self._FLAGS)
        if node is not None:
            prefix = str(prefixField.GetValue(None)) if prefixField is not None else "Splicer : "
            node.textName = prefix + str(state.get("name") or "Splicer")
        # ParentDicKey/ParentSplicerId/ParentPartIndex/ParentNodePath/ChildDicKeys confirmed present
        # on AssetSS.SceneSplicer as of v0.6.6 (see _splicer_state). _set_field/_get_field still
        # no-op safely on an older plugin build.
        for name in ("ParentDicKey", "ParentSplicerId", "ParentPartIndex", "ParentNodePath"):
            if name in state:
                value = state[name]
                if name == "ParentDicKey":
                    value = dicKeyMap.get(int(value), int(value)) if value is not None else value
                self._set_field(splicer, name, value)
        childDicKeys = self._get_field(splicer, "ChildDicKeys")
        if childDicKeys is not None:
            childDicKeys.Clear()
            for key in state.get("ChildDicKeys", []):
                childDicKeys.Add(dicKeyMap.get(int(key), int(key)))
        for name, value in state.get("settings", {}).items():
            settings = self._get_field(splicer, "Settings")
            if settings is not None:
                self._set_field(settings, name, value)
        self._set_property(splicer, "Position", state.get("position"))
        self._set_property(splicer, "Rotation", state.get("rotation"))
        self._set_property(splicer, "Size", state.get("scale", state.get("size")))
        for layer in ("Image", "Detail", "Bump"):
            self._set_image(splicer, layer, state.get(layer + "Data"),
                            state.get(layer + "Extension"))
        enabled = state.get("enabled")
        if enabled is not None:
            self._invoke(splicer, "SetEnabled", (bool(enabled),))
        self._invoke(splicer, "SyncMaterial", (True,))

    def SetSplicerSceneData(self, states):
        # whole-scene splicer list restore, matching GetSplicerSceneData's shape
        if not self.isDetected or states is None:
            return
        splicerStates = states.get("splicers", [])
        splicers = []
        dicKeyMap = {}
        keepDicKeys = set()
        for state in splicerStates:
            splicer = self._find_or_create_splicer(state)
            splicers.append((splicer, state))
            oldKey = state.get("dicKey")
            if splicer is not None and oldKey is not None:
                currentKey = int(self._get_field(splicer, "DicKey"))
                dicKeyMap[int(oldKey)] = currentKey
                keepDicKeys.add(currentKey)
        # SplicerParenting confirmed present as of v0.6.6 - see _refresh_parenting
        parentingType = self.assembly.GetType("AssetSS.SplicerParenting") if self.assembly is not None else None
        if parentingType is not None:
            reset = parentingType.GetMethod("Reset", self._FLAGS)
            if reset is not None:
                reset.Invoke(None, ())
        for splicer, state in splicers:
            self._restore_splicer(splicer, state, dicKeyMap)
        remove = self.splicerType.GetMethod("Remove", self._FLAGS)
        if remove is not None:
            for splicer in list(self._splicers()):
                if splicer is not None and int(self._get_field(splicer, "DicKey")) not in keepDicKeys:
                    remove.Invoke(None, (splicer,))
        checkedProperty = self.splicerType.GetProperty("CheckedIds", self._FLAGS)
        if checkedProperty is not None:
            checkedIds = checkedProperty.GetValue(None, None)
            checkedIds.Clear()
            for splicerId in states.get("checked", []):
                checkedIds.Add(str(splicerId))
        deselect = self.splicerType.GetMethod("DeselectAllGuides", self._FLAGS)
        if deselect is not None:
            deselect.Invoke(None, ())
        primaryProperty = self.splicerType.GetProperty("PrimaryId", self._FLAGS)
        if primaryProperty is not None and states.get("primary") is not None:
            primaryProperty.SetValue(None, states.get("primary"), None)
        if parentingType is not None:
            queueRestore = parentingType.GetMethod("QueueRestore", self._FLAGS)
            restore = parentingType.GetMethod("Reconcile", self._FLAGS)
            if queueRestore is not None:
                for splicer, _ in splicers:
                    if splicer is not None:
                        queueRestore.Invoke(None, (splicer,))
            if restore is not None:
                restore.Invoke(None, ())
        self._restore_layers(states)

    # ---- per-character / per-item-prop blendshape weights ----
    def _target_root(self, target):
        if target is None:
            return None
        objctrl = target.objctrl if hasattr(target, "objctrl") else target
        charInfo = getattr(objctrl, "charInfo", None)
        if charInfo is not None:
            return charInfo.gameObject
        objectItem = getattr(objctrl, "objectItem", None)
        if objectItem is not None:
            return objectItem
        objectLight = getattr(objctrl, "objectLight", None)
        if objectLight is not None:
            return objectLight
        objectText = getattr(objctrl, "objectText", None)
        if objectText is not None:
            return objectText
        return None

    def _static_key(self, methodName, obj):
        if self.blendshapeStoreType is None or obj is None:
            return None
        for method in self.blendshapeStoreType.GetMethods(self._FLAGS):
            if method.Name != methodName or not method.IsStatic:
                continue
            parameters = method.GetParameters()
            if len(parameters) == 1 and parameters[0].ParameterType.IsInstanceOfType(obj):
                return method.Invoke(None, (obj,))
        return None

    def _blendshape_key(self, target):
        if target is None:
            return None
        objctrl = target.objctrl if hasattr(target, "objctrl") else target
        if getattr(objctrl, "charInfo", None) is not None:
            # BlendshapeStore.CanonicalKey confirmed present as of AssetSS v0.6.6, with overloads for
            # both ChaControl and OCIChar (it did not exist at all in v0.6.0 - only MakeCharacterKey
            # did, which CanonicalKey now wraps). objctrl here is an OCIChar, so the OCIChar overload
            # matches via _static_key's IsInstanceOfType check.
            return self._static_key("CanonicalKey", objctrl)
        if getattr(objctrl, "objectItem", None) is not None:
            return self._static_key("MakeKey", objctrl)
        return None

    def _transform_path(self, transform, root):
        parts = []
        while transform is not None and transform != root:
            parts.insert(0, str(transform.name))
            transform = transform.parent
        return "/".join(parts)

    def _blendshape_state(self, root, key):
        from UnityEngine import SkinnedMeshRenderer
        if root is None:
            return ()
        weights = {}
        renderers = root.GetComponentsInChildren[SkinnedMeshRenderer](True)
        for renderer in renderers:
            if renderer is None or renderer.sharedMesh is None:
                continue
            mesh = renderer.sharedMesh
            path = self._transform_path(renderer.transform, root.transform)
            for index in range(mesh.blendShapeCount):
                name = mesh.GetBlendShapeName(index)
                weights[(path, str(mesh.name), str(name))] = float(renderer.GetBlendShapeWeight(index))
        if key and self.blendshapeStoreType is not None:
            entriesField = self.blendshapeStoreType.GetField("PerItem", self._FLAGS)
            if entriesField is not None:
                entries = entriesField.GetValue(None)
                if entries.ContainsKey(key):
                    for entry in entries[key]:
                        if entry is None:
                            continue
                        shapeKey = (str(self._get_field(entry, "RendererPath") or ""),
                                    str(self._get_field(entry, "MeshName") or ""),
                                    str(self._get_field(entry, "ShapeName") or ""))
                        weights[shapeKey] = float(self._get_field(entry, "Weight"))
        return [(path, meshName, shapeName, weight)
                for (path, meshName, shapeName), weight in weights.items()]

    def _set_stored_weight(self, key, path, meshName, shapeName, weight):
        from System import Single
        if not key or self.blendshapeStoreType is None:
            return
        for method in self.blendshapeStoreType.GetMethods(self._FLAGS):
            if method.Name == "SetShapeWeight" and method.IsStatic and len(method.GetParameters()) == 5:
                method.Invoke(None, (key, path, meshName, shapeName, Single(weight)))
                return

    def _restore_blendshapes(self, target, state):
        from System import Single
        from UnityEngine import SkinnedMeshRenderer
        root = self._target_root(target)
        if root is None:
            return
        key = self._blendshape_key(target) or state.get("blendshapeKey")
        snapshot = {}
        for entry in state.get("blendshapes", ()):
            if len(entry) == 4:
                path, meshName, shapeName, weight = entry
                snapshot[(str(path), str(meshName), str(shapeName))] = float(weight)
        renderers = root.GetComponentsInChildren[SkinnedMeshRenderer](True)
        for renderer in renderers:
            if renderer is None or renderer.sharedMesh is None:
                continue
            mesh = renderer.sharedMesh
            path = self._transform_path(renderer.transform, root.transform)
            for index in range(mesh.blendShapeCount):
                name = str(mesh.GetBlendShapeName(index))
                weight = snapshot.get((path, str(mesh.name), name), 0.0)
                renderer.SetBlendShapeWeight(index, Single(weight))
                self._set_stored_weight(key, path, str(mesh.name), name, weight)

    def GetBlendShapeData(self, target):
        if not self.isDetected:
            return None
        state = {}
        root = self._target_root(target)
        key = self._blendshape_key(target)
        weights = self._blendshape_state(root, key)
        if weights:
            state["blendshapeKey"] = str(key) if key else ""
            state["blendshapes"] = weights
        return state if state else None

    def SetBlendShapeData(self, target, state):
        if not self.isDetected or state is None:
            return
        if "blendshapes" in state:
            self._restore_blendshapes(target, state)


# :::::::::::: CustomFluids ::::::::::::
# Plugin: "CustomFluids" by darkseraph, BepInEx GUID "darkseraph.customfluid", assembly name
# "CustomFluids". Covers fluid spawn point scene-wide data (system state) only - HS2 only, treated
# as a single opaque system blob same as AssetSS's splicer data (see AssetSS class comment above).
class CustomFluids(ExtPlugin):
    _FLAGS = BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic

    def __init__(self):
        if ExtPlugin.exists("CustomFluids"):
            ExtPlugin.__init__(self, "CustomFluids")
            self.engine = "HS2"
        else:
            self.isDetected = False
            self.engine = None
        self.managerType = None
        self.spawnManagerType = None
        self.parentingType = None
        if self.isDetected:
            from System import AppDomain
            assembly = None
            for loadedAssembly in AppDomain.CurrentDomain.GetAssemblies():
                if str(loadedAssembly.GetName().Name) == "CustomFluids":
                    assembly = loadedAssembly
                    break
            if assembly is not None:
                self.managerType = assembly.GetType("CustomFluids.CustomFluidManager")
                self.spawnManagerType = assembly.GetType("CustomFluids.FluidSpawnManager")
                # CustomFluids.FluidSpawnParenting.QueueRestore/Reconcile/Reset confirmed present and
                # matching exactly as of CustomFluids v1.4.3 (was absent in v1.3.0). The lookup still
                # guards every call site with "is not None" in case of an older plugin build. The
                # original reference implementation raised ImportError when this type was missing,
                # which would make this class permanently fail to construct (every CustomFluids() call
                # would throw) - that would have been a real functional break, not a harmless degrade,
                # so that raise is deliberately not carried over even now that the type exists.
                self.parentingType = assembly.GetType("CustomFluids.FluidSpawnParenting")
            if self.managerType is None or self.spawnManagerType is None:
                self.isDetected = False

    def _coerce(self, value, targetType):
        from System import Convert, Single, Enum
        from UnityEngine import Color, Vector3
        if value is None:
            return None
        if targetType.Name == "Color" and isinstance(value, (tuple, list)):
            return Color(Single(value[0]), Single(value[1]), Single(value[2]), Single(value[3]))
        if targetType.Name == "Vector3" and isinstance(value, (tuple, list)):
            return Vector3(Single(value[0]), Single(value[1]), Single(value[2]))
        if targetType.IsEnum:
            return Enum.ToObject(targetType, value)
        return Convert.ChangeType(value, targetType)

    def _value(self, value):
        if value is None:
            return None
        typeName = value.GetType().Name
        if typeName == "Color":
            return (float(value.r), float(value.g), float(value.b), float(value.a))
        if typeName == "Vector3":
            return (float(value.x), float(value.y), float(value.z))
        if typeName == "String":
            return str(value)
        if typeName == "Boolean":
            return bool(value)
        if typeName in ("Byte", "SByte", "Int16", "UInt16", "Int32", "UInt32", "Int64", "UInt64"):
            return int(value)
        if typeName in ("Single", "Double", "Decimal"):
            return float(value)
        return value

    def _manager(self):
        if self.managerType is None:
            return None
        prop = self.managerType.GetProperty("Instance", self._FLAGS)
        return prop.GetValue(None, None) if prop is not None else None

    def _item_manager(self, manager):
        if manager is None:
            return None
        field = manager.GetType().GetField("_itemManager", self._FLAGS)
        return field.GetValue(manager) if field is not None else None

    def _get_property(self, obj, name):
        if obj is None:
            return None
        prop = obj.GetType().GetProperty(name, self._FLAGS)
        return prop.GetValue(obj, None) if prop is not None else None

    def _set_property(self, obj, name, value):
        if obj is None or value is None:
            return
        prop = obj.GetType().GetProperty(name, self._FLAGS)
        if prop is not None and prop.CanWrite:
            prop.SetValue(obj, self._coerce(value, prop.PropertyType), None)

    def _get_field(self, obj, name):
        if obj is None:
            return None
        field = obj.GetType().GetField(name, self._FLAGS)
        return field.GetValue(obj) if field is not None else None

    def _set_field(self, obj, name, value):
        if obj is None:
            return
        field = obj.GetType().GetField(name, self._FLAGS)
        if field is not None:
            field.SetValue(obj, self._coerce(value, field.FieldType))

    def _invoke_static(self, targetType, name, args=()):
        if targetType is None:
            return None
        method = targetType.GetMethod(name, self._FLAGS)
        if method is not None:
            return method.Invoke(None, tuple(args))

    def _invoke(self, obj, name, args=()):
        if obj is None:
            return None
        method = obj.GetType().GetMethod(name, self._FLAGS)
        if method is not None:
            return method.Invoke(obj, tuple(args))

    def _queue_parenting_restore(self, spawn):
        # CustomFluids.FluidSpawnParenting confirmed present as of v1.4.3 - see __init__.
        self._invoke_static(self.parentingType, "QueueRestore", (spawn,))

    def _refresh_parenting(self):
        # see _queue_parenting_restore
        self._invoke_static(self.parentingType, "Reconcile")

    def _spawn_for_key(self, dicKey):
        if dicKey is None:
            return None
        from Studio import Studio
        studio = Studio.Instance
        key = int(dicKey)
        if studio is None or not studio.dicObjectCtrl.ContainsKey(key):
            return None
        objctrl = studio.dicObjectCtrl[key]
        if objctrl is None or str(objctrl.GetType().Name) != "FluidSpawnCtrlInfo":
            return None
        return self._get_field(objctrl, "Spawn")

    def _parameter_state(self, obj):
        values = {}
        if obj is None:
            return values
        for field in obj.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public):
            if not field.IsStatic and not field.IsLiteral:
                values[field.Name] = self._value(field.GetValue(obj))
        return values

    def _apply_parameters(self, obj, values):
        if obj is None:
            return
        for name, value in values.items():
            field = obj.GetType().GetField(name, BindingFlags.Instance | BindingFlags.Public)
            if field is not None and not field.IsInitOnly:
                field.SetValue(obj, self._coerce(value, field.FieldType))

    def _running_particle_count(self, item, values):
        if "particleCount" not in values:
            return values
        emitter = self._get_property(item, "Emitter")
        if emitter is None or not bool(self._get_property(emitter, "Initialized")):
            return values
        liveCount = self._get_property(emitter, "NumParticles")
        if liveCount is None or int(liveCount) == int(values["particleCount"]):
            return values
        # ObiEmitter.NumParticles re-initializes the emitter and drops every particle that is alive,
        # so a running fluid keeps its particle pool and only reports the value the state had.
        print("VNGE CustomFluids: keeping the running fluid at {0} particles (state had {1})".format(
            int(liveCount), int(values["particleCount"])))
        values = dict(values)
        values["particleCount"] = int(liveCount)
        return values

    def _item_state(self, item):
        spawn = self._spawn_for_key(item.DicKey)
        if spawn is not None:
            captureWorkspace = spawn.GetType().GetMethod("CaptureWorkspaceState", self._FLAGS)
            if captureWorkspace is not None:
                captureWorkspace.Invoke(spawn, ())
        # ChildDicKeys confirmed present on CustomFluids.FluidSpawn as of v1.4.3 (a List<int> field,
        # was absent in v1.3.0). _get_field still returns None safely on an older plugin build.
        childDicKeys = self._get_field(spawn, "ChildDicKeys")
        return {
            "dicKey": int(item.DicKey),
            "physics": self._parameter_state(item.Physics),
            "appearance": self._parameter_state(item.Appearance),
            "collision": self._parameter_state(item.CollisionParams),
            "isEmitting": bool(item.IsEmitting),
            "isFrozen": bool(item.IsFrozen),
            "collisionEnabled": bool(item.CollisionEnabled),
            "position": self._value(self._get_property(spawn, "Position")),
            "rotation": self._value(self._get_property(spawn, "Rotation")),
            "scale": self._value(self._get_property(spawn, "Size")),
            "spawnId": self._value(self._get_field(spawn, "Id")),
            "name": self._value(self._get_field(spawn, "Name")),
            "enabled": bool(self._get_property(spawn, "SerializedEnabled")),
            # ParentDicKey/ParentPartIndex confirmed present on FluidSpawn as of v1.4.3 - see above
            "ParentDicKey": self._value(self._get_field(spawn, "ParentDicKey")),
            "ParentPartIndex": self._value(self._get_field(spawn, "ParentPartIndex")),
            "ChildDicKeys": [int(key) for key in childDicKeys] if childDicKeys is not None else [],
        }

    def GetFluidSceneData(self):
        # whole-scene fluid item list, treated as a single opaque system-state blob
        if not self.isDetected:
            return None
        manager = self._manager()
        itemManager = self._item_manager(manager)
        if itemManager is None:
            return None
        self._refresh_parenting()
        return [self._item_state(item) for item in itemManager.Items if item is not None]

    def _apply_state(self, item, manager, state, dicKeyMap=None):
        appearance = item.Appearance
        previousMode = appearance.materialMode
        previousColorShader = appearance.colorShaderName
        previousFluidShader = appearance.fluidShaderName
        wasFrozen = bool(item.IsFrozen)
        self._apply_parameters(item.Physics, self._running_particle_count(item, state.get("physics", {})))
        self._apply_parameters(appearance, state.get("appearance", {}))
        self._apply_parameters(item.CollisionParams, state.get("collision", {}))
        spawn = self._spawn_for_key(item.DicKey)
        self._set_property(spawn, "Position", state.get("position"))
        self._set_property(spawn, "Rotation", state.get("rotation"))
        self._set_property(spawn, "Size", state.get("scale"))
        if spawn is not None:
            if "spawnId" in state:
                self._set_field(spawn, "Id", state["spawnId"])
            if "name" in state:
                self._set_field(spawn, "Name", state["name"])
                node = self._get_field(spawn, "Node")
                nodeLabel = self.spawnManagerType.GetMethod("NodeLabel", self._FLAGS)
                if node is not None and nodeLabel is not None:
                    node.textName = str(nodeLabel.Invoke(None, (state["name"],)))
            # ParentDicKey/ParentPartIndex/ChildDicKeys confirmed present on FluidSpawn as of v1.4.3 -
            # see _item_state. _set_field/_get_field still no-op safely on an older plugin build.
            for name in ("ParentDicKey", "ParentPartIndex"):
                if name not in state:
                    continue
                value = state[name]
                if name == "ParentDicKey" and value is not None:
                    value = (dicKeyMap or {}).get(int(value), int(value))
                self._set_field(spawn, name, value)
            childDicKeys = self._get_field(spawn, "ChildDicKeys")
            if childDicKeys is not None and "ChildDicKeys" in state:
                childDicKeys.Clear()
                for key in state["ChildDicKeys"]:
                    childDicKeys.Add((dicKeyMap or {}).get(int(key), int(key)))
            if "enabled" in state:
                wanted = bool(state["enabled"])
                current = self._get_property(spawn, "SerializedEnabled")
                if current is None or bool(current) != wanted:
                    self._invoke(spawn, "SetEnabled", (wanted,))
        for stateName, propertyName in (("isEmitting", "IsEmitting"),
                                        ("isFrozen", "IsFrozen"),
                                        ("collisionEnabled", "CollisionEnabled")):
            if stateName not in state:
                continue
            prop = item.GetType().GetProperty(propertyName, self._FLAGS)
            if prop is not None and prop.CanWrite:
                prop.SetValue(item, self._coerce(state[stateName], prop.PropertyType), None)
        if manager is not None and (previousMode != appearance.materialMode
                                    or previousColorShader != appearance.colorShaderName
                                    or previousFluidShader != appearance.fluidShaderName):
            recreateMaterials = manager.GetType().GetMethod("RecreateItemMaterials", self._FLAGS)
            if recreateMaterials is not None:
                recreateMaterials.Invoke(manager, (item,))
        item.ApplyAll()
        if manager is not None:
            applyFreeze = manager.GetType().GetMethod("ApplyItemFreeze", self._FLAGS)
            if applyFreeze is not None and wasFrozen != bool(item.IsFrozen):
                applyFreeze.Invoke(manager, (item,))
            for methodName in ("SyncItemColor", "ApplySharedAppearanceToRenderer",
                               "SyncRendererItemInfo"):
                method = manager.GetType().GetMethod(methodName, self._FLAGS)
                if method is not None:
                    method.Invoke(manager, (item,))
            saveConfig = manager.GetType().GetMethod("SaveItemConfig", self._FLAGS)
            if saveConfig is not None:
                saveConfig.Invoke(manager, (item,))
            itemManager = self._item_manager(manager)
            if itemManager is not None:
                selected = itemManager.GetType().GetProperty("SelectedItem", self._FLAGS)
                if selected is not None and selected.GetValue(itemManager, None) == item:
                    emitting = manager.GetType().GetField("_isEmitting", self._FLAGS)
                    if emitting is not None:
                        emitting.SetValue(manager, bool(item.IsEmitting))
                    ui = manager.GetType().GetField("_ui", self._FLAGS)
                    if ui is not None and ui.GetValue(manager) is not None:
                        syncShaders = ui.GetValue(manager).GetType().GetMethod("SyncShaderNames", self._FLAGS)
                        if syncShaders is not None:
                            syncShaders.Invoke(ui.GetValue(manager), (
                                item.Appearance.colorShaderName,
                                item.Appearance.fluidShaderName))

    def SetFluidSceneData(self, states):
        # whole-scene fluid item list restore, matching GetFluidSceneData's shape
        if not self.isDetected or states is None:
            return
        manager = self._manager()
        itemManager = self._item_manager(manager)
        if itemManager is None:
            return
        itemsByKey = dict((int(item.DicKey), item) for item in itemManager.Items if item is not None)
        dicKeyMap = {}
        for state in states:
            oldKey = state.get("dicKey")
            item = itemsByKey.get(int(oldKey)) if oldKey is not None else None
            if item is not None:
                dicKeyMap[int(oldKey)] = int(item.DicKey)
        # FluidSpawnParenting confirmed present as of v1.4.3 - see _refresh_parenting
        self._invoke_static(self.parentingType, "Reset")
        for state in states:
            item = itemsByKey.get(int(state.get("dicKey", -1)))
            if item is not None:
                self._apply_state(item, manager, state, dicKeyMap)
        for state in states:
            item = itemsByKey.get(int(state.get("dicKey", -1)))
            if item is not None:
                spawn = self._spawn_for_key(item.DicKey)
                if spawn is not None:
                    self._queue_parenting_restore(spawn)
        self._refresh_parenting()


# :::::::::::: PregnancyPlus ::::::::::::
class PregnancyPlus(ExtPlugin):
    PPD_KEYS_SINGLE = [
        "inflationSize",
        "inflationMoveY",
        "inflationMoveZ",
        "inflationStretchX",
        "inflationStretchY",
        "inflationShiftY",
        "inflationShiftZ",
        "inflationTaperY",
        "inflationTaperZ",
        "inflationMultiplier",
        "inflationClothOffset",
        "inflationFatFold",
        "inflationFatFoldHeight",
        "inflationFatFoldGap",
        "inflationRoundness",
        "inflationDrop"
    ]

    def __init__(self):
        if ExtPlugin.exists("KK_PregnancyPlus"):
            ExtPlugin.__init__(self, "KK_PregnancyPlus")
            self.engine = "KK"
        elif ExtPlugin.exists("KKS_PregnancyPlus"):
            ExtPlugin.__init__(self, "KKS_PregnancyPlus")
            self.engine = "KKS"
        elif ExtPlugin.exists("AI_PregnancyPlus"):
            ExtPlugin.__init__(self, "AI_PregnancyPlus")
            self.engine = "AI"
        elif ExtPlugin.exists("HS2_PregnancyPlus"):
            ExtPlugin.__init__(self, "HS2_PregnancyPlus")
            self.engine = "HS2"
        else:
            self.isDetected = False
            self.engine = None

    def GetPregnancyPlusController(self, ociChar):
        if not self.isDetected:
            return None
        from KK_PregnancyPlus import PregnancyPlusCharaController
        try:
            if ociChar != None:
                if hasattr(ociChar, "objctrl"):
                    ociChar = ociChar.objctrl
                return ociChar.charInfo.gameObject.GetComponentInChildren[PregnancyPlusCharaController]()
        except:
            traceback.print_exc()
            return None
        
    def GetPregnancyPlusData(self, ociChar):
        if not self.isDetected:
            return None
        ppc = self.GetPregnancyPlusController(ociChar)
        if not ppc:
            return None
        
        try:
            CallPrivate(ppc, "CaptureNewBlendshapeWeights", [])
            # save data
            ppdata = {}
            for k in PregnancyPlus.PPD_KEYS_SINGLE:
                if hasattr(ppc.infConfig, k):
                    ppdata[k] = getattr(ppc.infConfig, k)
            return ppdata
        except:
            traceback.print_exc()
            return None

    def SetPregnancyPlusData(self, ociChar, ppData):
        if not self.isDetected:
            return
        ppc = self.GetPregnancyPlusController(ociChar)
        if not ppc:
            return
        
        try:
            from KK_PregnancyPlus import PregnancyPlusData, MeshInflateFlags
            #from ExtensibleSaveFormat import PluginData
            #pd = PluginData()
            #for k, v in ppData.items():
            #    pd.data.Add(k, v)
            #ppd = PregnancyPlusData.Load(pd)

            updated = False
            for k, v in ppData.items():
                if hasattr(ppc.infConfig, k) and getattr(ppc.infConfig, k) != v:
                    setattr(ppc.infConfig, k, v)
                    updated = True
            if not updated:
                return

            mfi = MeshInflateFlags(ppc)
            #mfi.freshStart = True
            mfi.visibilityUpdate = True

            ppc.MeshInflate(mfi, "VNGE")
            #ppc.MeshInflate(ppd, "VNGE", mfi)
            
        except:
            traceback.print_exc()
            return


# :::::::::::: Colliders ::::::::::::
class Colliders(ExtPlugin):
    COLLIDER_KEYS = ["FloorColliderEnabled", "BreastCollidersEnabled"]

    def __init__(self):
        if ExtPlugin.exists("KK_Colliders"):
            ExtPlugin.__init__(self, "KK_Colliders")
            self.engine = "KK"
        elif ExtPlugin.exists("KKS_Colliders"):
            ExtPlugin.__init__(self, "KKS_Colliders")
            self.engine = "KKS"
        elif ExtPlugin.exists("AI_Colliders"):
            ExtPlugin.__init__(self, "AI_Colliders")
            self.engine = "AI"
        elif ExtPlugin.exists("HS2_Colliders"):
            ExtPlugin.__init__(self, "HS2_Colliders")
            self.engine = "HS2"
        else:
            self.isDetected = False
            self.engine = None

    def GetColliderController(self, ociChar):
        if not self.isDetected:
            return None
        from KK_Plugins import Colliders
        try:
            if ociChar != None:
                if hasattr(ociChar, "objctrl"):
                    ociChar = ociChar.objctrl
                return Colliders.GetController(ociChar.charInfo)
        except:
            traceback.print_exc()
            return None

    def GetColliderData(self, ociChar):
        if not self.isDetected:
            return None
        ctrl = self.GetColliderController(ociChar)
        if not ctrl:
            return None

        try:
            data = {}
            for k in Colliders.COLLIDER_KEYS:
                if hasattr(ctrl, k):
                    data[k] = getattr(ctrl, k)
            if self.engine in ("KK", "KKS") and hasattr(ctrl, "SkirtCollidersEnabled"):
                data["SkirtCollidersEnabled"] = ctrl.SkirtCollidersEnabled
            return data
        except:
            traceback.print_exc()
            return None

    def SetColliderData(self, ociChar, data):
        if not self.isDetected:
            return
        ctrl = self.GetColliderController(ociChar)
        if not ctrl:
            return

        try:
            for k, v in data.items():
                if k == "SkirtCollidersEnabled" and self.engine not in ("KK", "KKS"):
                    continue
                if hasattr(ctrl, k):
                    setattr(ctrl, k, v)
            ctrl.ApplyColliders()
        except:
            traceback.print_exc()


# ::::::::::: PandarinkaToolkit Plugin Support for VNGE :::::::::::
class PandarinkaToolkit(ExtPlugin):
    def __init__(self):
        if ExtPlugin.exists("PandarinkaToolkit"):
            ExtPlugin.__init__(self, "PandarinkaToolkit")
            self.engine = "HS2"
        else:
            self.isDetected = False
            self.engine = None

    def GetSoftBodyComponent(self, ociChar):
        if not self.isDetected:
            return None
        from PandarinkaToolkit import PandarinkaSoftBody
        try:
            if ociChar != None:
                if hasattr(ociChar, "objctrl"):
                    ociChar = ociChar.objctrl
                return ociChar.charInfo.gameObject.GetComponent[PandarinkaSoftBody]()
        except:
            traceback.print_exc()
            return None

    def GetSoftbodyData(self, ociChar):
        if not self.isDetected:
            return None
        comp = self.GetSoftBodyComponent(ociChar)
        if not comp:
            return None
        try:
            return comp.SoftBodyState
        except:
            traceback.print_exc()
            return None

    def SetSoftbodyData(self, ociChar, data):
        if not self.isDetected:
            return
        comp = self.GetSoftBodyComponent(ociChar)
        if not comp:
            return
        try:
            comp.SoftBodyState = data
        except:
            traceback.print_exc()

    # ----- RigFlow (Pandarinka Toolkit 3.9.5+) -----
    # RigFlow data is a serialized string of one character's RigFlow rig, "" means no rig.
    # The manager is resolved on every call (never cached), so a DevReload of the plugin
    # never leaves a disposed owner in VNGE.
    def _ResolveRigFlow(self):
        # return (manager, serializer type), or (None, None) if RigFlow is not loaded
        if not self.isDetected:
            return None, None
        from System import AppDomain
        for assembly in reversed(list(AppDomain.CurrentDomain.GetAssemblies())):
            typ = assembly.GetType("PandarinkaToolkit.PandarinkaToolkitPlugin", False)
            if typ is None:
                continue
            try:
                owner = GetPrivateStatic(clr.GetPythonType(typ), "Instance")
            except AttributeError:
                owner = None
            if owner is None:
                continue
            try:
                manager = GetPrivateProperty(owner, "RigFlow")
            except:
                try:
                    manager = GetPrivate(owner, "RigFlow")
                except AttributeError:
                    continue
            if manager is not None:
                serializer = assembly.GetType("PandarinkaToolkit.RigFlowSerialization", False)
                if serializer is not None:
                    return manager, clr.GetPythonType(serializer)
        return None, None

    def GetRigFlowData(self, ociChar):
        if not self.isDetected:
            return None
        if hasattr(ociChar, "objctrl"):
            ociChar = ociChar.objctrl
        manager, serializer = self._ResolveRigFlow()
        if manager is None:
            return None
        CallPrivate(manager, "PrepareExternalLinks", [])
        rig = CallPrivate(manager, "Find", [ociChar])
        if rig is None:
            # explicit empty state, so a status without RigFlow can be restored
            return ""
        data = CallPrivate(rig, "Capture", [])
        # scene object keys are remapped on import, normalize so duplicated actors export equal data
        from System import Int32
        SetPrivate(data, "character", Int32(0))
        return CallPrivateStatic(serializer, "Serialize", [data])

    def BeginRigFlowImport(self, ociChar, payload):
        # start an import transaction, call it BEFORE the native kinematic/FK/IK fields are set,
        # then call finish() after all of them (or rollback() on error)
        if hasattr(ociChar, "objctrl"):
            ociChar = ociChar.objctrl
        tr = PandarinkaRigFlowImport(self, ociChar, payload)
        try:
            tr.begin()
        except:
            tr.rollback()
            raise
        return tr

    def SetRigFlowData(self, ociChar, payload):
        tr = self.BeginRigFlowImport(ociChar, payload)
        try:
            tr.finish()
        except:
            tr.rollback()
            raise


class PandarinkaRigFlowImport(object):
    # RigFlow import transaction, created by PandarinkaToolkit.BeginRigFlowImport
    def __init__(self, plugin, objctrl, payload):
        self.objctrl = objctrl
        self.manager, self.serializer = plugin._ResolveRigFlow()
        if self.manager is None:
            raise Exception("RigFlow is not loaded. Pandarinka Toolkit 3.9.5 with RigFlow is required.")
        self.data = None
        if payload:
            # validate before suspending the current rig or touching native IK/FK
            self.data = CallPrivateStatic(self.serializer, "Deserialize", [payload])
            try:
                points = GetPrivateProperty(self.data, "points")
            except:
                points = GetPrivate(self.data, "points")
            if points is None or len(points) == 0:
                raise Exception("RigFlow state has no controls.")
            from System import Int32
            SetPrivate(self.data, "character", Int32(objctrl.objectInfo.dicKey))
        self.rig = CallPrivate(self.manager, "Find", [objctrl])
        self.before = CallPrivate(self.rig, "Capture", []) if self.rig is not None else None
        self.started = False

    def begin(self):
        self.started = True
        if self.rig is not None:
            # must run before native FK/IK fields, otherwise the FK/IK mode hooks
            # restore the previous RigFlow pose over the loaded one
            CallPrivate(self.rig, "Enable", [False, False, None])
            CallPrivate(self.rig, "BeginNativePoseLoad", [])
            if self.data is None:
                CallPrivate(self.manager, "Deleted", [self.objctrl])

    def finish(self):
        if self.data is not None:
            rig = CallPrivate(self.manager, "Ensure", [self.objctrl])
            CallPrivate(rig, "Apply", [self.data])
        self.started = False
        timeline = self.manager.GetType().Assembly.GetType("PandarinkaToolkit.RigFlowTimeline", False)
        if timeline is not None:
            CallPrivateStatic(clr.GetPythonType(timeline), "Refresh", [])

    def rollback(self):
        if not self.started:
            return
        try:
            if self.before is not None:
                CallPrivate(CallPrivate(self.manager, "Ensure", [self.objctrl]), "Apply", [self.before])
            else:
                CallPrivate(self.manager, "Deleted", [self.objctrl])
        finally:
            self.started = False


# ::::::::::: SculptStudio Plugin Support for VNGE :::::::::::
# Sculpt data is stored by the plugin as scene data (not per character), keyed by
# "<dicKey>|<rendererPath>|S" (skinned) or "...|M" (MeshFilter). All plugin types are
# internal, so everything goes through reflection on SculptController.Instance.
# Per-object data exported here is {"<rendererPath>|S/M": {"str": strength, "layers": ...}},
# the dicKey prefix is dropped so the data follows the object, not the scene key.
_sculpt_nz_cache = {}   # record key -> (Deltas array, list of non-zero delta indices)

class SculptStudio(ExtPlugin):
    _FLAGS = BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic

    def __init__(self):
        if ExtPlugin.exists("SculptStudioPlugin"):
            ExtPlugin.__init__(self, "SculptStudioPlugin")
            self.engine = "HS2"
        else:
            self.isDetected = False
            self.engine = None
        self.ctrlType = None
        if self.isDetected:
            from System import AppDomain
            for loadedAssembly in AppDomain.CurrentDomain.GetAssemblies():
                if str(loadedAssembly.GetName().Name) == "SculptStudioPlugin":
                    self.ctrlType = loadedAssembly.GetType("SculptStudioPlugin.SculptController")
                    break
            if self.ctrlType is None:
                self.isDetected = False

    def _controller(self):
        if self.ctrlType is None:
            return None
        prop = self.ctrlType.GetProperty("Instance", self._FLAGS)
        return prop.GetValue(None, None) if prop is not None else None

    def _get(self, obj, name):
        return obj.GetType().GetField(name, self._FLAGS).GetValue(obj)

    def _set(self, obj, name, value):
        obj.GetType().GetField(name, self._FLAGS).SetValue(obj, value)

    def _method(self, name, argCount):
        for m in self.ctrlType.GetMethods(self._FLAGS):
            if m.Name == name and len(m.GetParameters()) == argCount:
                return m
        return None

    def _dickey(self, ociObj):
        if hasattr(ociObj, "objctrl"):
            ociObj = ociObj.objctrl
        return ociObj, ociObj.objectInfo.dicKey

    def _root(self, ociObj):
        from Studio import OCIChar, OCIItem
        if isinstance(ociObj, OCIItem):
            return ociObj.objectItem
        if isinstance(ociObj, OCIChar):
            return ociObj.charInfo.gameObject
        return None

    def _locked_subkey(self, ctrl, dicKey):
        # subkey "<rendererPath>|S/M" of the target locked in the plugin, if it belongs to dicKey
        if self._get(ctrl, "targetMesh") == None or self._get(ctrl, "originalVertices") == None:
            return None
        if self._get(ctrl, "targetObjectKey") != dicKey:
            return None
        return "%s|%s" % (self._get(ctrl, "targetRendererPath"), "S" if self._get(ctrl, "targetRendererIsSkinned") else "M")

    def _stack_layers(self, stack):
        # SculptLayerStack members are internal properties, read the backing field instead
        return self._get(stack, "layers")

    def _stack_compose(self, stack, strength):
        from System import Single
        return stack.GetType().GetMethod("Compose", self._FLAGS).Invoke(stack, (Single(strength),))

    def _layers_state(self, layers):
        # ordered list, so layers can still be matched by position when their ids change
        return [[str(l.Id), bool(l.Visible), round(float(l.Opacity), 6)] for l in layers]

    def _match_layers(self, layers, ldata):
        # -> [(layer, visible, opacity)]. Match by layer id first. The plugin generates a
        # new id whenever it rebuilds a layer stack (e.g. a single default layer is not
        # saved with the scene), so fall back to the position for the unmatched layers
        # when the layer count is the same.
        if isinstance(ldata, dict):
            # early format {id: [visible, opacity]}, unordered: position only for one layer
            entries = [[lid, lv[0], lv[1]] for lid, lv in ldata.items()]
            ordered = len(entries) == 1
        else:
            entries = list(ldata)
            ordered = True
        layers = list(layers)
        byId = dict((str(l.Id), l) for l in layers)
        savedIds = set(str(e[0]) for e in entries)
        sameCount = ordered and len(entries) == len(layers)
        res = []
        for i, e in enumerate(entries):
            l = byId.get(str(e[0]))
            if l == None and sameCount and not str(layers[i].Id) in savedIds:
                l = layers[i]
            if l != None:
                res.append((l, bool(e[1]), min(max(float(e[2]), 0.0), 1.0)))
        return res

    def _find_mesh(self, ociObj, subkey):
        rend = self._find_renderer(ociObj, subkey)
        if rend == None or rend.sharedMesh == None:
            return None
        return rend.sharedMesh

    def _stack_has_deltas(self, stack):
        for l in self._stack_layers(stack):
            d = l.Deltas
            for i in xrange(d.Length):
                if d[i].sqrMagnitude > 1e-12:
                    return True
        return False

    def _stack_is_default(self, stack):
        # same test as the plugin's CaptureLayerRecordForCurrentTarget: a single plain
        # "Base Sculpt" layer is not saved as a layer record
        layers = self._stack_layers(stack)
        l = layers[0]
        return layers.Count == 1 and self._get(stack, "activeIndex") == 0 and str(l.Name) == "Base Sculpt" and bool(l.Visible) and float(l.Opacity) == 1.0 and l.InfluenceMask == None

    def _new_layer_record(self, ctrl, recKey, rendererPath, isSkinned, stack, v):
        # same fields as the plugin's CaptureLayerRecordForCurrentTarget
        from System import Activator, Single
        recType = self.ctrlType.Assembly.GetType("SculptStudioPlugin.SavedLayerStackRecord")
        lr = Activator.CreateInstance(recType, True)
        lr.ObjectKey = int(recKey.split("|")[0])
        lr.ObjectName = ""
        lr.RendererPath = rendererPath
        lr.IsSkinned = isSkinned
        lr.VertexCount = self._get(stack, "baseVertices").Length
        lr.ActiveIndex = self._get(stack, "activeIndex")
        lr.MasterStrength = Single(v)
        for l in self._stack_layers(stack):
            lr.Layers.Add(l.GetType().GetMethod("Clone").Invoke(l, None))
        return lr

    def _ensure_default_stack(self, ctrl, recKey, rec, mesh):
        # After a scene load the plugin keeps a single default layer only as the sculpt
        # record, the layer stack is created when the target is locked. Create it the same
        # way (InitializeLayerStackForCurrentTarget) so its layer can be read and switched.
        from System import Single
        sessionStacks = self._get(ctrl, "sessionLayerStacks")
        if sessionStacks.ContainsKey(recKey):
            return sessionStacks[recKey]
        n = mesh.vertexCount
        if rec == None or rec.Deltas == None or rec.VertexCount != n or rec.Deltas.Length != n:
            return None
        restoredBase = self._get(ctrl, "restoredBaseVertices")
        if restoredBase.ContainsKey(recKey) and restoredBase[recKey].Length == n:
            base = restoredBase[recKey]
        else:
            base = mesh.vertices
            s = Single(rec.SculptStrength)
            for i in xrange(n):
                base[i] = base[i] - rec.Deltas[i] * s
        stackType = self.ctrlType.Assembly.GetType("SculptStudioPlugin.SculptLayerStack")
        for c in stackType.GetConstructors(self._FLAGS):
            if len(c.GetParameters()) == 2:
                stack = c.Invoke((base, rec.Deltas))   # clones both arrays
                sessionStacks[recKey] = stack
                return stack
        return None

    def _apply_layers_state(self, layers, ldata, stack=None):
        # set visible/opacity of the matched layers, return True if anything changed
        from System import Single
        changed = False
        for l, vis, opa in self._match_layers(layers, ldata):
            if bool(l.Visible) != vis or abs(float(l.Opacity) - opa) > 1e-5:
                l.Visible = vis
                l.Opacity = Single(opa)
                changed = True
        if changed and stack != None:
            # same as the plugin's SetVisible/SetOpacity, lets its UI notice the change
            self._set(stack, "revision", self._get(stack, "revision") + 1)
        return changed

    def GetSculptData(self, ociObj):
        # {"<rendererPath>|S/M": {"str": strength, "layers": [[layerId, visible, opacity], ...]}}
        if not self.isDetected:
            return None
        try:
            ctrl = self._controller()
            if ctrl == None:
                return None
            ociObj, dicKey = self._dickey(ociObj)
            prefix = str(dicKey) + "|"
            saved = self._get(ctrl, "savedSculpts")
            layerRecs = self._get(ctrl, "savedLayerRecords")
            sessionStacks = self._get(ctrl, "sessionLayerStacks")
            strengths = self._get(ctrl, "sculptStrengthByTarget")
            data = {}
            for k in list(saved.Keys) + list(layerRecs.Keys) + list(sessionStacks.Keys):
                if not k.startswith(prefix) or k[len(prefix):] in data:
                    continue
                if saved.ContainsKey(k):
                    entry = {"str": round(float(saved[k].SculptStrength), 6)}
                elif layerRecs.ContainsKey(k):
                    entry = {"str": round(float(layerRecs[k].MasterStrength), 6)}
                elif self._stack_has_deltas(sessionStacks[k]):
                    # all layers hidden: the plugin dropped the sculpt record, only the stack is left
                    entry = {"str": round(float(strengths[k]), 6) if strengths.ContainsKey(k) else 1.0}
                else:
                    # a renderer that was only visited in the plugin, not sculpted
                    continue
                # session stack holds the live layer state, saved layer record is the fallback
                if sessionStacks.ContainsKey(k):
                    entry["layers"] = self._layers_state(self._stack_layers(sessionStacks[k]))
                elif layerRecs.ContainsKey(k):
                    entry["layers"] = self._layers_state(layerRecs[k].Layers)
                else:
                    mesh = self._find_mesh(ociObj, k[len(prefix):])
                    stack = self._ensure_default_stack(ctrl, k, saved[k], mesh) if mesh != None else None
                    if stack != None:
                        entry["layers"] = self._layers_state(self._stack_layers(stack))
                data[k[len(prefix):]] = entry
            # the locked target may hold newer unsaved state than its records
            lk = self._locked_subkey(ctrl, dicKey)
            if lk != None:
                entry = {"str": round(float(self._get(ctrl, "currentSculptStrength")), 6)}
                als = self._get(ctrl, "activeLayerStack")
                if als != None:
                    entry["layers"] = self._layers_state(self._stack_layers(als))
                data[lk] = entry
            if len(data) == 0:
                return None
            return data
        except:
            traceback.print_exc()
            return None

    def SetSculptData(self, ociObj, data):
        if not self.isDetected or not data:
            return
        try:
            ctrl = self._controller()
            if ctrl == None:
                return
            ociObj, dicKey = self._dickey(ociObj)
            lk = self._locked_subkey(ctrl, dicKey)
            for subkey, entry in data.items():
                if not isinstance(entry, dict):
                    entry = {"str": entry}
                v = min(max(float(entry.get("str", 1.0)), 0.0), 1.0)
                ldata = entry.get("layers")
                if subkey == lk:
                    self._set_locked(ctrl, v, ldata)
                else:
                    self._set_unlocked(ctrl, ociObj, dicKey, subkey, v, ldata)
        except:
            traceback.print_exc()

    def _set_locked(self, ctrl, v, ldata):
        # mirror the plugin's RunLayerOperation without pushing undo states
        from System import Single
        changed = False
        als = self._get(ctrl, "activeLayerStack")
        if als != None and ldata:
            changed = self._apply_layers_state(self._stack_layers(als), ldata, als)
        if abs(float(self._get(ctrl, "currentSculptStrength")) - v) > 1e-5:
            # composes the layer stack with the new strength and captures the layer record
            self._method("SetCurrentSculptStrengthSingle", 2).Invoke(ctrl, (Single(v), False))
            if changed:
                self._method("CaptureCurrentSculptRecord", 2).Invoke(ctrl, (False, False))
        elif changed:
            self._method("ReplaceVertices", 3).Invoke(ctrl, (self._stack_compose(als, v), False, True))
            self._method("CaptureCurrentSculptRecord", 2).Invoke(ctrl, (False, False))
            self._method("CaptureLayerRecordForCurrentTarget", 1).Invoke(ctrl, (False,))
        if als != None and ldata:
            # the plugin drops the layer record of a single default layer, keep it so the
            # layer id survives a scene save (see _set_unlocked)
            recKey = "%d|%s|%s" % (self._get(ctrl, "targetObjectKey"), self._get(ctrl, "targetRendererPath"), "S" if self._get(ctrl, "targetRendererIsSkinned") else "M")
            layerRecs = self._get(ctrl, "savedLayerRecords")
            if not layerRecs.ContainsKey(recKey) and self._stack_has_deltas(als):
                layerRecs[recKey] = self._new_layer_record(ctrl, recKey, self._get(ctrl, "targetRendererPath"), self._get(ctrl, "targetRendererIsSkinned"), als, v)

    def _set_unlocked(self, ctrl, ociObj, dicKey, subkey, v, ldata):
        from System import Single, Object, Array
        from UnityEngine import Vector3
        recKey = str(dicKey) + "|" + subkey
        rendererPath = subkey[:-2]
        isSkinned = subkey.endswith("|S")
        saved = self._get(ctrl, "savedSculpts")
        # the plugin drops the sculpt record when the composed delta is zero (e.g. all
        # layers hidden), the layer stack / layer record still holds the layers then
        rec = saved[recKey] if saved.ContainsKey(recKey) else None
        layerRecs = self._get(ctrl, "savedLayerRecords")
        layerRec = layerRecs[recKey] if layerRecs.ContainsKey(recKey) else None
        sessionStacks = self._get(ctrl, "sessionLayerStacks")
        if rec == None and layerRec == None and not sessionStacks.ContainsKey(recKey):
            return
        mesh = self._find_mesh(ociObj, subkey)
        if mesh == None:
            return
        n = mesh.vertexCount
        if rec != None:
            deltas = rec.Deltas
            if deltas == None or rec.VertexCount != n or deltas.Length != n:
                return
            old = float(rec.SculptStrength)
        else:
            deltas = None
            old = float(layerRec.MasterStrength) if layerRec != None else 1.0
        oldSingle = Single(old)   # Vector3 * python float is not supported

        # layer visible/opacity, applied to the live session stack and the saved layer record
        stack = None
        if ldata and rec != None and layerRec == None:
            self._ensure_default_stack(ctrl, recKey, rec, mesh)
        if sessionStacks.ContainsKey(recKey) and self._get(sessionStacks[recKey], "baseVertices").Length == n:
            stack = sessionStacks[recKey]
        if rec == None and stack == None and (layerRec == None or layerRec.VertexCount != n):
            return
        layersChanged = False
        if ldata:
            if stack != None:
                layersChanged = self._apply_layers_state(self._stack_layers(stack), ldata, stack)
                if layerRec == None:
                    # Without a layer record the plugin saves only the composed sculpt record
                    # (nothing at all when every layer is hidden) and rebuilds the stack with
                    # new layer ids on load. Keep one, so the layers and their ids survive a
                    # scene save; the plugin restores the stack from it (FromSaved) on load.
                    layerRec = self._new_layer_record(ctrl, recKey, rendererPath, isSkinned, stack, old)
                    layerRecs[recKey] = layerRec
            if layerRec != None:
                recChanged = self._apply_layers_state(layerRec.Layers, ldata)
                if stack == None and recChanged:
                    # no live stack: rebuild one from the saved layers on top of the current base
                    base = mesh.vertices
                    if deltas != None:
                        for i in xrange(n):
                            base[i] = base[i] - deltas[i] * oldSingle
                    stackType = self.ctrlType.Assembly.GetType("SculptStudioPlugin.SculptLayerStack")
                    stack = stackType.GetMethod("FromSaved", self._FLAGS).Invoke(None, (base, layerRec.Layers, layerRec.ActiveIndex))
                    layersChanged = True
            for ctx in self._get(ctrl, "targetRuntimeContexts").Values:
                if ctx.LayerStack != None and not Object.ReferenceEquals(ctx.LayerStack, stack) and ctx.TargetObjectKey == dicKey and ctx.TargetRendererPath == rendererPath and ctx.TargetRendererIsSkinned == isSkinned:
                    self._apply_layers_state(self._stack_layers(ctx.LayerStack), ldata, ctx.LayerStack)

        if rec == None and not layersChanged:
            # zero composed delta, nothing to move: only keep the strength bookkeeping
            if layerRec != None:
                layerRec.MasterStrength = Single(v)
            self._sync_strength_state(ctrl, dicKey, recKey, rendererPath, isSkinned, v)
            return
        if not layersChanged and abs(old - v) <= 1e-5:
            return

        vSingle = Single(v)
        cur = mesh.vertices
        if layersChanged:
            # new full-strength deltas = composed layers - base
            base = self._get(stack, "baseVertices")
            comp = self._stack_compose(stack, 1.0)
            deltas = Array.CreateInstance(Vector3, n)
            target = Array.CreateInstance(Vector3, n)
            for i in xrange(n):
                deltas[i] = comp[i] - base[i]
                target[i] = base[i] + deltas[i] * vSingle
            if rec == None:
                rec = self._new_sculpt_record(ctrl, recKey, rendererPath, isSkinned, mesh, layerRec)
                rec.ObjectKey = dicKey
                saved[recKey] = rec
            rec.Deltas = deltas
            _sculpt_nz_cache[recKey] = (deltas, [i for i in xrange(n) if deltas[i].sqrMagnitude > 0.0])
            indices = None
        else:
            # target = current + deltas * (new - old), only non-zero deltas move
            cache = _sculpt_nz_cache.get(recKey)
            if cache == None or not Object.ReferenceEquals(cache[0], deltas):
                cache = (deltas, [i for i in xrange(n) if deltas[i].sqrMagnitude > 0.0])
                _sculpt_nz_cache[recKey] = cache
            indices = cache[1]
            target = mesh.vertices
            diff = Single(v - old)
            for i in indices:
                target[i] = target[i] + deltas[i] * diff
        rec.SculptStrength = vSingle
        self._move_mesh(ctrl, mesh, cur, target, indices)
        if layersChanged and len(_sculpt_nz_cache[recKey][1]) == 0:
            # like the plugin's CaptureCurrentSculptRecord: no delta and no mask -> no record
            masks = rec.Masks
            if masks == None or not any(masks[i] > 1e-6 for i in xrange(masks.Length)):
                saved.Remove(recKey)
                del _sculpt_nz_cache[recKey]
        # keep plugin side state consistent
        if layerRec != None:
            layerRec.MasterStrength = Single(v)
        self._sync_strength_state(ctrl, dicKey, recKey, rendererPath, isSkinned, v)

    def _move_mesh(self, ctrl, mesh, cur, target, indices=None):
        # Move the mesh from its current vertices to target with the plugin's
        # ApplySavedRecordToMesh, given as one sculpt step "cur -> target": the plugin
        # rebuilds normals/tangents only for vertices that differ between its base and
        # result (keeping smooth seams), so the base passed in must be the current shape.
        # indices: the only vertices that can differ, None for all.
        from System import Activator, Array, Single
        from UnityEngine import Vector3
        n = cur.Length
        step = Array.CreateInstance(Vector3, n)
        moved = False
        for i in (indices if indices != None else xrange(n)):
            step[i] = target[i] - cur[i]
            if not moved and step[i].sqrMagnitude > 0.0:
                moved = True
        if not moved:
            return
        tmp = Activator.CreateInstance(self.ctrlType.Assembly.GetType("SculptStudioPlugin.SavedSculptRecord"), True)
        tmp.VertexCount = n
        tmp.Deltas = step
        tmp.SculptStrength = Single(1.0)
        self._method("ApplySavedRecordToMesh", 3).Invoke(ctrl, (tmp, mesh, cur))

    def _sync_strength_state(self, ctrl, dicKey, recKey, rendererPath, isSkinned, v):
        from System import Single
        self._get(ctrl, "sculptStrengthByTarget")[recKey] = Single(v)
        for ctx in self._get(ctrl, "targetRuntimeContexts").Values:
            if ctx.TargetObjectKey == dicKey and ctx.TargetRendererPath == rendererPath and ctx.TargetRendererIsSkinned == isSkinned:
                ctx.CurrentSculptStrength = Single(v)
                if v > 1e-6:
                    ctx.LastEnabledSculptStrength = Single(v)

    def _new_sculpt_record(self, ctrl, recKey, rendererPath, isSkinned, mesh, layerRec):
        # same fields as the plugin's CaptureCurrentSculptRecord
        from System import Activator, Array, Single
        recType = self.ctrlType.Assembly.GetType("SculptStudioPlugin.SavedSculptRecord")
        rec = Activator.CreateInstance(recType, True)
        n = mesh.vertexCount
        rec.ObjectName = layerRec.ObjectName if layerRec != None else ""
        rec.RendererPath = rendererPath
        rec.IsSkinned = isSkinned
        rec.MeshName = mesh.name
        rec.VertexCount = n
        masks = None
        restoredMasks = self._get(ctrl, "restoredMasks")
        if restoredMasks.ContainsKey(recKey) and restoredMasks[recKey].Length == n:
            masks = restoredMasks[recKey].Clone()
        rec.Masks = masks if masks != None else Array.CreateInstance(Single, n)
        return rec

    # ---- full scene data (ExportSys_SculptStudioFullData) ----
    # The same data the plugin writes into the scene (gzip binary of its own codecs),
    # stored as base64 text: ["v1", {"payload": ..., "sculptLayers": ..., ...}]
    _FULL_CODECS = (("payload", "SculptSaveCodec", "savedSculpts", True),
                    ("sculptLayers", "SculptLayerCodec", "savedLayerRecords", True),
                    ("sculptSnapshots", "SculptSnapshotCodec", "savedSnapshots", False),
                    ("rendererGroups", "SculptRendererGroupCodec", "savedRendererGroups", False))

    def GetFullSceneData(self):
        if not self.isDetected:
            return None
        try:
            from System import Convert
            ctrl = self._controller()
            if ctrl == None:
                return None
            # same captures as the plugin's scene save, the locked target may hold unsaved edits
            self._method("CaptureCurrentSculptRecord", 2).Invoke(ctrl, (False, True))
            self._method("CaptureLayerRecordForCurrentTarget", 1).Invoke(ctrl, (True,))
            data = {}
            for key, codec, field, isDict in self._FULL_CODECS:
                coll = self._get(ctrl, field)
                if coll.Count == 0:
                    continue
                writer = self.ctrlType.Assembly.GetType("SculptStudioPlugin." + codec).GetMethod("Write", self._FLAGS)
                data[key] = Convert.ToBase64String(writer.Invoke(None, (coll.Values if isDict else coll,)))
            # a list, not a tuple: SSS keeps it as json, and the diff check of
            # import_sys_status_diff_optimized compares with the stored value
            return ["v1", data]
        except:
            traceback.print_exc()
            return None

    def SetFullSceneData(self, fullData):
        if not self.isDetected or fullData == None:
            return
        try:
            from System import Convert, Activator
            from System.Collections import IEnumerator
            from Studio import Studio
            if fullData[0] != "v1":
                print("SculptStudio: unknown full data version " + str(fullData[0]))
                return
            ctrl = self._controller()
            if ctrl == None:
                return
            # PluginData of ExtensibleSaveFormat, as handed to the plugin on scene load
            setLoaded = self._method("SetLoadedScenePluginData", 1)
            pd = Activator.CreateInstance(setLoaded.GetParameters()[0].ParameterType)
            pd.version = 5
            for key, val in fullData[1].items():
                pd.data[key] = Convert.FromBase64String(val)
            loadedItems = Studio.Instance.dicObjectCtrl

            # the plugin re-applies saved sculpts on top of the current mesh, so every
            # sculpted mesh must go back to its original shape first
            oldMeshes = self.ResetAllSculptMeshes(ctrl)

            # the plugin's own scene-load path: clears its state and reads the records,
            # then restores them in coroutines that wait for loading objects
            setLoaded.Invoke(ctrl, (pd,))
            self._method("HandleSceneLoaded", 2).Invoke(ctrl, (False, loadedItems))
            # all objects already exist here: stop the coroutines and run the same
            # restore steps right now, so that per object data (pl_sculpt) applied next
            # works on the restored meshes
            for field in ("pendingSceneRestore", "pendingImportedLayerRestore", "pendingSnapshotRestore"):
                co = self._get(ctrl, field)
                if co != None:
                    ctrl.StopCoroutine(co)
                    self._set(ctrl, field, None)
            records = self._method("ReadScenePluginData", 1).Invoke(ctrl, (pd,))
            layers = self._method("ReadSavedLayers", 1).Invoke(ctrl, (pd,))
            snapshots = self._method("ReadSavedSnapshots", 1).Invoke(ctrl, (pd,))
            for name, items in (("ApplyLoadedSculptsDelayed", records), ("RestoreLayerRecordsDelayed", layers), ("RestoreSnapshotRecordsDelayed", snapshots)):
                if items.Count == 0:
                    continue
                en = self._method(name, 3).Invoke(ctrl, (items, loadedItems, False))
                # step 1 initializes, step 2 is the first restore attempt
                for i in range(3):
                    if not IEnumerator.MoveNext(en):
                        break

            # the plugin restores a skinned renderer on a new mesh instance, drop the
            # previous instances it made
            from UnityEngine import Object
            suffix = " (Sculpt Studio Restored)"
            for comp, mesh in oldMeshes:
                if comp != None and comp.sharedMesh != mesh and mesh != None and "(Sculpt Studio" in mesh.name:
                    Object.Destroy(mesh)
                    # the plugin appends the suffix on every restore, keep only one
                    newMesh = comp.sharedMesh
                    if newMesh != None and newMesh.name.endswith(suffix):
                        newMesh.name = newMesh.name.replace(suffix, "") + suffix
        except:
            traceback.print_exc()

    def _find_renderer(self, ociObj, subkey):
        from UnityEngine import SkinnedMeshRenderer, MeshFilter
        root = self._root(ociObj)
        if root == None:
            return None
        tr = root.transform.Find(subkey[:-2])
        if tr == None:
            return None
        if subkey.endswith("|S"):
            return tr.GetComponent[SkinnedMeshRenderer]()
        return tr.GetComponent[MeshFilter]()

    def ResetAllSculptMeshes(self, ctrl):
        # Put every mesh the plugin knows as sculpted back to its original vertices.
        # Returns [(renderer, mesh)] of the reset renderers.
        from System import Array, Single
        from UnityEngine import Vector3
        from Studio import Studio
        dic = Studio.Instance.dicObjectCtrl
        byRenderer = self._get(ctrl, "restoredBaseVerticesByRenderer")
        histories = self._get(ctrl, "targetHistories")
        sessionBase = self._get(ctrl, "sessionBaseVertices")
        restoredBase = self._get(ctrl, "restoredBaseVertices")
        sessionStacks = self._get(ctrl, "sessionLayerStacks")
        saved = self._get(ctrl, "savedSculpts")
        keys = set()
        for field in ("savedSculpts", "savedLayerRecords", "sessionLayerStacks", "restoredBaseVertices", "sessionBaseVertices", "targetHistories"):
            keys.update(list(self._get(ctrl, field).Keys))
        # the locked target and the other renderers of a locked group carry their own base
        bases = {}
        for ctx in list(self._get(ctrl, "targetRuntimeContexts").Values) + [None]:
            if ctx == None:
                key = "%d|%s|%s" % (self._get(ctrl, "targetObjectKey"), self._get(ctrl, "targetRendererPath"), "S" if self._get(ctrl, "targetRendererIsSkinned") else "M")
                orig = self._get(ctrl, "originalVertices")
            else:
                key = "%d|%s|%s" % (ctx.TargetObjectKey, ctx.TargetRendererPath, "S" if ctx.TargetRendererIsSkinned else "M")
                orig = ctx.OriginalVertices
            if orig != None and not key.startswith("-1|"):
                bases[key] = orig
                keys.add(key)
        done = []
        for key in keys:
            dicKey, subkey = key.split("|", 1)
            dicKey = int(dicKey)
            if not dic.ContainsKey(dicKey):
                continue
            comp = self._find_renderer(dic[dicKey], subkey)
            if comp == None or comp.sharedMesh == None:
                continue
            mesh = comp.sharedMesh
            n = mesh.vertexCount
            # same priority as the plugin uses for the base of a target
            cands = [bases.get(key)]
            if byRenderer.ContainsKey(comp):
                cands.append(byRenderer[comp])
            if histories.ContainsKey(key):
                cands.append(histories[key].BaseVertices)
            for d in (sessionBase, restoredBase):
                if d.ContainsKey(key):
                    cands.append(d[key])
            if sessionStacks.ContainsKey(key):
                cands.append(self._get(sessionStacks[key], "baseVertices"))
            base = None
            for c in cands:
                if c != None and c.Length == n:
                    base = c
                    break
            cur = mesh.vertices
            if base == None and saved.ContainsKey(key):
                rec = saved[key]
                if rec.Deltas != None and rec.Deltas.Length == n:
                    s = Single(rec.SculptStrength)
                    base = Array.CreateInstance(Vector3, n)
                    for i in xrange(n):
                        base[i] = cur[i] - rec.Deltas[i] * s
            if base == None:
                continue
            self._move_mesh(ctrl, mesh, cur, base)
            done.append((comp, mesh))
        return done


# ::::::::::: FaceExpressHS2 Plugin Support for VNGE :::::::::::
class FaceExpress(ExtPlugin):
    def __init__(self):
        ExtPlugin.__init__(self, "Hanamura_FaceExpressHS2")

    def GetController(self, ociChar):
        if not self.isDetected:
            return None
        if hasattr(ociChar, "objctrl"):
            ociChar = ociChar.objctrl
        try:
            from FaceExpressHS2 import FaceExpressController
            return ociChar.charInfo.gameObject.GetComponent[FaceExpressController]()
        except:
            return None

    def GetFaceExpressSettings(self, ociChar):
        """Exports all FaceExpress settings from the character as a dictionary of key-value pairs."""
        fec = self.GetController(ociChar)
        if fec:
            from System import Single
            try:
                # get serialized data and convert to python format
                feData = {}
                sed = fec.SerializeExpressionData()
                for k in sed.Keys:
                    if isinstance(sed[k], Single):
                        feData[k] = float(sed[k])
                    else:
                        feData[k] = str(sed[k])
                return feData
            except:
                traceback.print_exc()                
        return None

    def SetFaceExpressSettings(self, ociChar, settingDict):
        """Imports and applies all FaceExpress settings from a dictionary of key-value pairs."""
        if not self.isDetected or not settingDict:
            return
        fec = self.GetController(ociChar)
        if fec:
            try:
                from System.Collections.Generic import Dictionary
                from System import Single
                feData = Dictionary[str, object]()
                # convert python dict to serialized data format
                # non-float values (bool/int/string) were all exported as str()
                # by GetFaceExpressSettings, so pass them back as-is and let
                # DeserializeExpressionData's per-key Convert.ToBoolean/
                # ToInt32/ToString parse them - do NOT force bool(v) here,
                # since bool() of any non-empty string (e.g. "False") is
                # always True, and it would also corrupt the string fields
                # (Teeth_Edits, Tongue_BoneFK, Tongue_IKTargetPos/Rot)
                for k, v in settingDict.items():
                    if isinstance(v, float):
                        feData[k] = Single(v)
                    else:
                        feData[k] = str(v)
                # apply settings
                fec.DeserializeExpressionData(feData)
            except:
                traceback.print_exc()


# support functions
def has_plugin(pluginname):
    return ExtPlugin.exists(pluginname)

def _find_instance_field(clrType, name):
    # GetField with NonPublic only returns fields declared directly on the
    # given type - FlattenHierarchy does not help for instance fields (it
    # only affects static member lookup), so walk BaseType manually to find
    # fields declared in a base class.
    flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.DeclaredOnly
    t = clrType
    while t is not None:
        f = t.GetField(name, flags)
        if f is not None:
            return f
        t = t.BaseType
    return None

def GetPrivate(self, name):
    type = self.GetType()
    typefield = _find_instance_field(type, name)
    if typefield is None:
        raise AttributeError("No field '%s' found on type '%s' (or its base types)" % (name, type.FullName))
    return typefield.GetValue(self)

def SetPrivate(self, name, value):
    type = self.GetType()
    typefield = _find_instance_field(type, name)
    if typefield is None:
        raise AttributeError("No field '%s' found on type '%s' (or its base types)" % (name, type.FullName))
    return typefield.SetValue(self, value)

def CallPrivate(self, name, p):
    bindflgs = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy
    try:
        method = self.GetType().GetMethod(name, bindflgs)
    except:
        # try fix Ambiguous match, by argument count first: None has no type to match on
        methods = [m for m in self.GetType().GetMethods(bindflgs)
                   if m.Name == name and len(m.GetParameters()) == len(p)]
        if len(methods) == 1:
            method = methods[0]
        else:
            types = tuple((pm.GetType() for pm in p))
            method = self.GetType().GetMethod(name, bindflgs, None, types, None)

    from System import Array
    ar = tuple(p)

    return method.Invoke(self, ar)

def GetPrivateProperty(self, name):
    return CallPrivate(self, "get_" + name, [])

def SetPrivateProperty(self, name, ar):
    CallPrivate(self, "set_" + name, ar)

def GetPrivateStatic(type, name):
    flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy | BindingFlags.Static
    clrType = clr.GetClrType(type)
    typefield = clrType.GetField(name, flags)
    if typefield is not None:
        return typefield.GetValue(None)
    typeprop = clrType.GetProperty(name, flags)
    if typeprop is not None:
        return typeprop.GetValue(None, None)
    raise AttributeError("No field or property '%s' found on type '%s'" % (name, clrType.FullName))

def CallPrivateStatic(type, name, p):
    method = clr.GetClrType(type).GetMethod(name, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy  | BindingFlags.Static)
    
    #from System import Array
    ar = tuple(p)
    return method.Invoke(type, ar)

def GetPrivateNestedType(type, name):
    nestedTypes = clr.GetClrType(type).GetNestedTypes(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy  | BindingFlags.Static)
    for nt in nestedTypes:
        if nt.Name == name:
            return nt
    return None
